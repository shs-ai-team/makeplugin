<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="sfb-wrap">
    <?php if (!empty($success)) : ?>
        <div class="sfb-notice sfb-success" role="status" aria-live="polite">
            <?php echo esc_html__('Thank you! Your feedback has been submitted.', 'simple-feedback-board'); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)) : ?>
        <div class="sfb-notice sfb-error" role="alert">
            <ul>
                <?php foreach ($errors as $err) : ?>
                    <li><?php echo esc_html($err); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="sfb-form" method="post" action="<?php echo esc_url(\wp_unslash($_SERVER['REQUEST_URI'] ?? '')); ?>" novalidate>
        <div class="sfb-field">
            <label for="sfb_name"><?php echo esc_html__('Name', 'simple-feedback-board'); ?> <span class="sfb-required" aria-hidden="true">*</span></label>
            <input type="text" id="sfb_name" name="sfb_name" value="<?php echo isset($values['name']) ? esc_attr($values['name']) : ''; ?>" required maxlength="200" />
        </div>
        <div class="sfb-field">
            <label for="sfb_message"><?php echo esc_html__('Message', 'simple-feedback-board'); ?> <span class="sfb-required" aria-hidden="true">*</span></label>
            <textarea id="sfb_message" name="sfb_message" rows="5" required aria-describedby="sfb_counter"><?php echo isset($values['message']) ? esc_html($values['message']) : ''; ?></textarea>
            <div id="sfb_counter" class="sfb-counter" aria-live="polite"></div>
            <div class="sfb-help"><?php /* translators: %d: word limit */ printf(esc_html__('Up to %d words.', 'simple-feedback-board'), (int) $word_limit); ?></div>
        </div>
        <div class="sfb-actions">
            <?php wp_nonce_field('sfb_submit', 'sfb_nonce'); ?>
            <input type="hidden" name="sfb_action" value="submit_feedback" />
            <button type="submit" class="sfb-button"><?php echo esc_html__('Send Feedback', 'simple-feedback-board'); ?></button>
        </div>
    </form>

    <div class="sfb-list">
        <h3 class="sfb-list-title"><?php echo esc_html__('All Feedback', 'simple-feedback-board'); ?></h3>
        <?php if (!empty($feedback_items)) : ?>
            <ul class="sfb-items">
                <?php foreach ($feedback_items as $item) : ?>
                    <?php
                    $item_name = get_the_title($item);
                    $item_message_raw = $item->post_content;
                    $item_message = wpautop(esc_html($item_message_raw));
                    ?>
                    <li class="sfb-item">
                        <div class="sfb-item-name"><?php echo esc_html($item_name); ?></div>
                        <div class="sfb-item-message"><?php echo wp_kses_post($item_message); ?></div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="sfb-empty"><?php echo esc_html__('No feedback has been submitted yet.', 'simple-feedback-board'); ?></p>
        <?php endif; ?>
    </div>
</div>
