<?php
if (!defined('ABSPATH')) {
    exit;
}

class SFB_Plugin {
    /**
     * Singleton instance
     *
     * @var SFB_Plugin
     */
    private static $instance;

    /**
     * Word limit for message
     *
     * @var int
     */
    private $word_limit = 150;

    /**
     * Get instance
     *
     * @return SFB_Plugin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->register_hooks();
    }

    /**
     * Register WordPress hooks
     */
    private function register_hooks() {
        add_action('init', array($this, 'register_post_type'));
        add_shortcode('simple_feedback_board', array($this, 'shortcode'));
    }

    /**
     * Register custom post type to store feedback
     */
    public function register_post_type() {
        $labels = array(
            'name' => esc_html__('Feedback', 'simple-feedback-board'),
            'singular_name' => esc_html__('Feedback Item', 'simple-feedback-board')
        );

        $args = array(
            'labels' => $labels,
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'supports' => array('title', 'editor'),
            'capability_type' => 'post',
            'rewrite' => false,
            'query_var' => false
        );

        register_post_type('sfb_feedback', $args);
    }

    /**
     * Handle form processing
     *
     * @param array $state
     * @return array
     */
    private function maybe_handle_submission($state) {
        if (!isset($_POST['sfb_action']) || 'submit_feedback' !== sanitize_text_field(wp_unslash($_POST['sfb_action'] ?? ''))) {
            return $state;
        }

        // Verify nonce
        $nonce = isset($_POST['sfb_nonce']) ? sanitize_text_field(wp_unslash($_POST['sfb_nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'sfb_submit')) {
            $state['errors'][] = esc_html__('Security check failed. Please try again.', 'simple-feedback-board');
            return $state;
        }

        // Sanitize inputs
        $name_raw = isset($_POST['sfb_name']) ? wp_unslash($_POST['sfb_name']) : '';
        $message_raw = isset($_POST['sfb_message']) ? wp_unslash($_POST['sfb_message']) : '';

        $name = sanitize_text_field($name_raw);
        // Allow plain text only; trim extra whitespace
        $message = trim(wp_strip_all_tags($message_raw));

        // Validate
        if ('' === $name) {
            $state['errors'][] = esc_html__('Please enter your name.', 'simple-feedback-board');
        }

        if ('' === $message) {
            $state['errors'][] = esc_html__('Please enter a message.', 'simple-feedback-board');
        }

        $word_count = $this->count_words($message);
        if ($word_count > $this->word_limit) {
            /* translators: %1$d: current word count, %2$d: word limit */
            $state['errors'][] = sprintf(esc_html__('%1$d words entered. The message limit is %2$d words.', 'simple-feedback-board'), (int) $word_count, (int) $this->word_limit);
        }

        // Preserve form values on error
        $state['values'] = array(
            'name' => $name,
            'message' => $message,
        );

        if (!empty($state['errors'])) {
            return $state;
        }

        // Insert feedback post
        $postarr = array(
            'post_type' => 'sfb_feedback',
            'post_title' => $name,
            'post_content' => $message,
            'post_status' => 'publish',
        );

        $insert_id = wp_insert_post($postarr, true);

        if (is_wp_error($insert_id)) {
            $state['errors'][] = esc_html__('An error occurred while saving your feedback. Please try again.', 'simple-feedback-board');
            return $state;
        }

        // Redirect to avoid resubmission
        $redirect_url = add_query_arg(array('sfb_submitted' => 1), remove_query_arg(array('sfb_submitted')));
        wp_safe_redirect($redirect_url);
        exit;
    }

    /**
     * Shortcode callback to render form and list
     *
     * @return string
     */
    public function shortcode() {
        // Enqueue assets
        $this->enqueue_assets();

        $state = array(
            'errors' => array(),
            'values' => array(
                'name' => '',
                'message' => ''
            ),
            'success' => false,
        );

        // Process submission if present
        $state = $this->maybe_handle_submission($state);

        // Success notice
        if (isset($_GET['sfb_submitted']) && '1' === sanitize_text_field(wp_unslash($_GET['sfb_submitted']))) {
            $state['success'] = true;
        }

        // Fetch all feedback items (newest first)
        $feedback_items = $this->get_feedback_items();

        ob_start();
        $values = $state['values'];
        $errors = $state['errors'];
        $success = $state['success'];
        $word_limit = (int) $this->word_limit;
        $template = plugin_dir_path(dirname(__FILE__)) . 'templates/form-list.php';
        if (file_exists($template)) {
            include $template;
        }
        return ob_get_clean();
    }

    /**
     * Enqueue styles and scripts
     */
    private function enqueue_assets() {
        $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '';
        $ver = '1.0.0';

        wp_enqueue_style(
            'sfb-style',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/style.css',
            array(),
            $ver
        );

        wp_enqueue_script(
            'sfb-script',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/script.js',
            array('jquery'),
            $ver,
            true
        );

        wp_localize_script('sfb-script', 'SFB', array(
            'wordLimit' => (int) $this->word_limit,
            'i18n' => array(
                /* translators: %d: maximum number of words allowed */
                'maxWords' => sprintf(esc_html__('Maximum %d words.', 'simple-feedback-board'), (int) $this->word_limit),
                /* translators: 1: current word count, 2: max words */
                'wordCount' => esc_html__('%1$d / %2$d words', 'simple-feedback-board'),
                'tooLong' => esc_html__('Your message is too long.', 'simple-feedback-board')
            )
        ));
    }

    /**
     * Get all feedback posts
     *
     * @return WP_Post[]
     */
    private function get_feedback_items() {
        $args = array(
            'post_type' => 'sfb_feedback',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'ignore_sticky_posts' => true,
        );
        $q = new WP_Query($args);
        return $q->posts;
    }

    /**
     * Count words in a string
     *
     * @param string $text
     * @return int
     */
    private function count_words($text) {
        $text = trim((string) $text);
        if ($text === '') {
            return 0;
        }
        // Normalize whitespace and count words
        $text = preg_replace('/\s+/u', ' ', $text);
        $words = explode(' ', $text);
        return count($words);
    }
}
