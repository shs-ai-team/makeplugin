=== Simple Feedback Board ===
Contributors: makeplugin
Tags: feedback, form, guestbook, testimonials, comments, frontend, contact, public, submissions
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Public feedback form with a live list of all submissions.

== Description ==
Provide a minimal, user-friendly public feedback form with two fields: Name and Message. Both fields are required. Message is limited to 150 words with a live word counter and clear validation messages. Submissions are saved and persist. Below the form, display all feedback ever submitted in a clean list (newest first), showing the Name and Message. No login required; anyone can submit. Show a simple success notice after submission and handle errors gracefully. Include light, modern styling to keep the layout clean and readable. Offer a simple way for the site owner to place this form-and-list on a page.

Use the shortcode: [simple_feedback_board]

== Installation ==
1. Upload the plugin to the /wp-content/plugins/ directory or install via the Plugins screen.
2. Activate the plugin through the Plugins screen in WordPress.
3. Add the shortcode [simple_feedback_board] to any page or post.

== Frequently Asked Questions ==
= How do I display the feedback form and list? =
Use the shortcode [simple_feedback_board] on any page or post.

= Do users need to be logged in to submit feedback? =
No. Anyone can submit feedback.

== Changelog ==
= 1.0.0 =
- Initial release.
