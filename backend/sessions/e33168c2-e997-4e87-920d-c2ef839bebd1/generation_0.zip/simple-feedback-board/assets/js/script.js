(function($){
  function countWords(str){
    if(!str){ return 0; }
    var cleaned = String(str).trim().replace(/\s+/g, ' ');
    if(cleaned === ''){ return 0; }
    return cleaned.split(' ').length;
  }

  function updateCounter($textarea, $counter, limit){
    var text = $textarea.val();
    var words = countWords(text);
    var display = (SFB && SFB.i18n && SFB.i18n.wordCount) ? SFB.i18n.wordCount : '%1$d / %2$d words';
    // Replace placeholders
    display = display.replace('%1$d', words).replace('%2$d', limit);
    $counter.text(display);
    if(words > limit){
      $counter.addClass('sfb-over');
    } else {
      $counter.removeClass('sfb-over');
    }
  }

  $(document).on('input', '#sfb_message', function(){
    var $t = $(this);
    var limit = parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10);
    var words = countWords($t.val());

    // If over the limit, trim to limit
    if(words > limit){
      var parts = String($t.val()).trim().replace(/\s+/g, ' ').split(' ');
      var trimmed = parts.slice(0, limit).join(' ');
      $t.val(trimmed + ' ');
    }
    updateCounter($t, $('#sfb_counter'), limit);
  });

  $(document).ready(function(){
    var $ta = $('#sfb_message');
    if($ta.length){
      updateCounter($ta, $('#sfb_counter'), parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10));
    }

    $('.sfb-form').on('submit', function(e){
      var $name = $('#sfb_name');
      var $msg = $('#sfb_message');
      var limit = parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10);
      var errs = [];
      if($.trim($name.val()) === ''){
        errs.push('name');
      }
      if($.trim($msg.val()) === ''){
        errs.push('message');
      }
      if(countWords($msg.val()) > limit){
        errs.push('tooLong');
      }
      if(errs.length){
        // Prevent submit and update counter state
        e.preventDefault();
        updateCounter($msg, $('#sfb_counter'), limit);
      }
    });
  });
})(jQuery);
