<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete all feedback posts
$posts = get_posts(array(
    'post_type'   => 'sfb_feedback',
    'numberposts' => -1,
    'post_status' => 'any',
    'fields'      => 'ids',
));

if (!empty($posts) && is_array($posts)) {
    foreach ($posts as $post_id) {
        wp_delete_post($post_id, true);
    }
}
