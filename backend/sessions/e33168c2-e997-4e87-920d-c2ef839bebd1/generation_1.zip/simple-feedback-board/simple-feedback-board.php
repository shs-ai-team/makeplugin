<?php
/**
 * Plugin Name: Simple Feedback Board
 * Description: Public feedback form with styled list and smooth submission.
 * Version: 1.1.0
 * Author: makeplugin
 * Text Domain: simple-feedback-board
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load text domain
add_action('plugins_loaded', function () {
    load_plugin_textdomain('simple-feedback-board', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

require_once plugin_dir_path(__FILE__) . 'includes/class-sfb.php';

// Initialize plugin
add_action('init', function () {
    \SFB_Plugin::get_instance();
});
