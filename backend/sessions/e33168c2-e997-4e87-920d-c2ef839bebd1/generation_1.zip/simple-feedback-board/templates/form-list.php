<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="sfb-wrap" data-sfb>
    <div class="sfb-header">
        <h2 class="sfb-title"><?php echo esc_html__('Share Your Feedback', 'simple-feedback-board'); ?></h2>
        <p class="sfb-subtitle"><?php echo esc_html__('We value your thoughts. Please keep it friendly and concise.', 'simple-feedback-board'); ?></p>
    </div>

    <div class="sfb-notice sfb-success" role="status" aria-live="polite" style="display:none"></div>
    <div class="sfb-notice sfb-error" role="alert" style="display:none"></div>

    <form class="sfb-form" method="post" action="<?php echo esc_url( home_url( add_query_arg( null, null ) ) ); ?>" novalidate>
        <div class="sfb-field" data-field="name">
            <label for="sfb_name" class="sfb-label"><?php echo esc_html__('Name', 'simple-feedback-board'); ?> <span class="sfb-required" aria-hidden="true">*</span></label>
            <input type="text" id="sfb_name" name="sfb_name" class="sfb-input" value="" required maxlength="200" />
            <p class="sfb-error-text" data-error-for="name" aria-live="polite"></p>
        </div>
        <div class="sfb-field" data-field="message">
            <label for="sfb_message" class="sfb-label"><?php echo esc_html__('Message', 'simple-feedback-board'); ?> <span class="sfb-required" aria-hidden="true">*</span></label>
            <textarea id="sfb_message" name="sfb_message" class="sfb-textarea" rows="5" required aria-describedby="sfb_counter"></textarea>
            <div id="sfb_counter" class="sfb-counter" aria-live="polite"></div>
            <div class="sfb-help"><?php /* translators: %d: word limit */ printf(esc_html__('Up to %d words.', 'simple-feedback-board'), (int) $word_limit); ?></div>
            <p class="sfb-error-text" data-error-for="message" aria-live="polite"></p>
        </div>
        <div class="sfb-actions">
            <button type="submit" class="sfb-button">
                <span class="sfb-button-text"><?php echo esc_html__('Send Feedback', 'simple-feedback-board'); ?></span>
                <span class="sfb-spinner" aria-hidden="true"></span>
            </button>
        </div>
    </form>

    <div class="sfb-list">
        <h3 class="sfb-list-title"><?php echo esc_html__('All Feedback', 'simple-feedback-board'); ?></h3>
        <?php if (!empty($feedback_items)) : ?>
            <ul class="sfb-items">
                <?php foreach ($feedback_items as $item) : ?>
                    <?php
                    $item_name = get_the_title($item);
                    $item_message_raw = $item->post_content;
                    $item_message = wpautop(esc_html($item_message_raw));
                    ?>
                    <li class="sfb-item">
                        <div class="sfb-item-name"><?php echo esc_html($item_name); ?></div>
                        <div class="sfb-item-message"><?php echo wp_kses_post($item_message); ?></div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="sfb-empty"><?php echo esc_html__('No feedback has been submitted yet.', 'simple-feedback-board'); ?></p>
            <ul class="sfb-items" style="display:none"></ul>
        <?php endif; ?>
    </div>
</div>
