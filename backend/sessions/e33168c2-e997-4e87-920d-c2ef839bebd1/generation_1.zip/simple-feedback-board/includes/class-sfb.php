<?php
if (!defined('ABSPATH')) {
    exit;
}

class SFB_Plugin {
    /**
     * Singleton instance
     *
     * @var SFB_Plugin
     */
    private static $instance;

    /**
     * Word limit for message
     *
     * @var int
     */
    private $word_limit = 150;

    /**
     * Get instance
     *
     * @return SFB_Plugin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->register_hooks();
    }

    /**
     * Register WordPress hooks
     */
    private function register_hooks() {
        add_action('init', array($this, 'register_post_type'));
        add_shortcode('simple_feedback_board', array($this, 'shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));

        // AJAX submission (both logged-in and public)
        add_action('wp_ajax_sfb_submit', array($this, 'ajax_submit'));
        add_action('wp_ajax_nopriv_sfb_submit', array($this, 'ajax_submit'));
    }

    /**
     * Register custom post type to store feedback
     */
    public function register_post_type() {
        $labels = array(
            'name' => esc_html__('Feedback', 'simple-feedback-board'),
            'singular_name' => esc_html__('Feedback Item', 'simple-feedback-board')
        );

        $args = array(
            'labels' => $labels,
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'supports' => array('title', 'editor'),
            'capability_type' => 'post',
            'rewrite' => false,
            'query_var' => false
        );

        register_post_type('sfb_feedback', $args);
    }

    /**
     * Shortcode callback to render form and list
     *
     * @return string
     */
    public function shortcode() {
        // Fetch all feedback items (newest first)
        $feedback_items = $this->get_feedback_items();

        ob_start();
        $word_limit = (int) $this->word_limit;
        $template = plugin_dir_path(dirname(__FILE__)) . 'templates/form-list.php';
        if (file_exists($template)) {
            include $template;
        }
        return ob_get_clean();
    }

    /**
     * Enqueue styles and scripts
     */
    public function enqueue_assets() {
        $ver = '1.1.0';

        wp_enqueue_style(
            'sfb-style',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/style.css',
            array(),
            $ver
        );

        wp_enqueue_script(
            'sfb-script',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/script.js',
            array('jquery'),
            $ver,
            true
        );

        wp_localize_script('sfb-script', 'SFB', array(
            'ajaxUrl'   => esc_url(admin_url('admin-ajax.php')),
            'nonce'     => wp_create_nonce('sfb_submit_ajax'),
            'wordLimit' => (int) $this->word_limit,
            'i18n' => array(
                /* translators: %d: maximum number of words allowed */
                'maxWords'  => sprintf(esc_html__('Maximum %d words.', 'simple-feedback-board'), (int) $this->word_limit),
                /* translators: 1: current word count, 2: max words */
                'wordCount' => esc_html__('%1$d / %2$d words', 'simple-feedback-board'),
                'tooLong'   => esc_html__('Your message is too long.', 'simple-feedback-board'),
                'required'  => esc_html__('This field is required.', 'simple-feedback-board'),
                'success'   => esc_html__('Thank you! Your feedback has been submitted.', 'simple-feedback-board'),
                'error'     => esc_html__('An error occurred. Please try again.', 'simple-feedback-board')
            )
        ));
    }

    /**
     * AJAX handler for feedback submission
     */
    public function ajax_submit() {
        if (!defined('DOING_AJAX') || !DOING_AJAX) {
            wp_send_json_error(array('message' => esc_html__('Invalid request.', 'simple-feedback-board')));
        }

        check_ajax_referer('sfb_submit_ajax', 'nonce');

        $name_raw    = isset($_POST['name']) ? wp_unslash($_POST['name']) : '';
        $message_raw = isset($_POST['message']) ? wp_unslash($_POST['message']) : '';

        $name = sanitize_text_field($name_raw);
        $message = trim(wp_strip_all_tags($message_raw));

        $errors = array();

        if ($name === '') {
            $errors['name'] = esc_html__('Please enter your name.', 'simple-feedback-board');
        }
        if ($message === '') {
            $errors['message'] = esc_html__('Please enter a message.', 'simple-feedback-board');
        }

        $word_count = $this->count_words($message);
        if ($word_count > $this->word_limit) {
            /* translators: %d: word limit */
            $errors['message'] = sprintf(esc_html__('Please keep your message under %d words.', 'simple-feedback-board'), (int) $this->word_limit);
        }

        if (!empty($errors)) {
            wp_send_json_error(array(
                'errors' => $errors
            ), 400);
        }

        $postarr = array(
            'post_type'    => 'sfb_feedback',
            'post_title'   => $name,
            'post_content' => $message,
            'post_status'  => 'publish',
        );

        $insert_id = wp_insert_post($postarr, true);

        if (is_wp_error($insert_id)) {
            wp_send_json_error(array(
                'message' => esc_html__('An error occurred while saving your feedback. Please try again.', 'simple-feedback-board')
            ), 500);
        }

        $post = get_post($insert_id);
        $item_html = $this->render_item($post);

        wp_send_json_success(array(
            'message'  => esc_html__('Thank you! Your feedback has been submitted.', 'simple-feedback-board'),
            'itemHtml' => $item_html
        ));
    }

    /**
     * Get all feedback posts
     *
     * @return WP_Post[]
     */
    private function get_feedback_items() {
        $args = array(
            'post_type'           => 'sfb_feedback',
            'posts_per_page'      => -1,
            'post_status'         => 'publish',
            'orderby'             => 'date',
            'order'               => 'DESC',
            'no_found_rows'       => true,
            'ignore_sticky_posts' => true,
        );
        $q = new WP_Query($args);
        return $q->posts;
    }

    /**
     * Render a single feedback item list HTML safely
     *
     * @param WP_Post $item
     * @return string
     */
    private function render_item($item) {
        if (!$item instanceof WP_Post) {
            return '';
        }
        $item_name = get_the_title($item);
        $item_message_raw = $item->post_content;
        $item_message = wpautop(esc_html($item_message_raw));

        ob_start();
        ?>
        <li class="sfb-item">
            <div class="sfb-item-name"><?php echo esc_html($item_name); ?></div>
            <div class="sfb-item-message"><?php echo wp_kses_post($item_message); ?></div>
        </li>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * Count words in a string
     *
     * @param string $text
     * @return int
     */
    private function count_words($text) {
        $text = trim((string) $text);
        if ('' === $text) {
            return 0;
        }
        $text = preg_replace('/\s+/u', ' ', $text);
        $words = explode(' ', $text);
        return count($words);
    }
}
