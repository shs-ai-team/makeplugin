=== Simple Feedback Board ===
Contributors: makeplugin
Tags: feedback, form, guestbook, testimonials, comments, frontend, contact, public, submissions
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.1.0
Requires PHP: 7.4
License: GPLv2 or later

Public feedback form with styled list and smooth submission.

== Description ==
Provide a minimal, user-friendly public feedback form with two required fields: Name and Message (limit 150 words with a live counter). Submissions save and persist. Below the form, display all feedback (newest first) showing Name and Message. Improve visuals with a clean, modern style: card-like container, clear labels, roomy inputs, subtle borders/shadows, accessible focus states, and a prominent button. Make the form submit in-place without reloading the page; on success, show a brief success message, clear the form, and immediately add the new feedback to the top of the list. Handle validation and errors inline. No login required. Provide a simple way for the site owner to place the combined form-and-list on a page.

Use the shortcode: [simple_feedback_board]

== Installation ==
1. Upload the plugin to the /wp-content/plugins/ directory or install via the Plugins screen.
2. Activate the plugin through the Plugins screen in WordPress.
3. Add the shortcode [simple_feedback_board] to any page or post.

== Frequently Asked Questions ==
= How do I display the feedback form and list? =
Use the shortcode [simple_feedback_board] on any page or post.

= Do users need to be logged in to submit feedback? =
No. Anyone can submit feedback.

== Changelog ==
= 1.1.0 =
- Added AJAX (in-place) submission with inline validation and instant list update.
- Added modern, accessible styling and focus states.

= 1.0.0 =
- Initial release.
