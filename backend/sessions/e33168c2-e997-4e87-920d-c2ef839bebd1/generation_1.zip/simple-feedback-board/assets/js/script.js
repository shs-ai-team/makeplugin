(function($){
  'use strict';

  function countWords(str){
    if(!str){ return 0; }
    var cleaned = String(str).trim().replace(/\s+/g, ' ');
    if(cleaned === ''){ return 0; }
    return cleaned.split(' ').length;
  }

  function updateCounter($textarea, $counter, limit){
    var text = $textarea.val();
    var words = countWords(text);
    var display = (SFB && SFB.i18n && SFB.i18n.wordCount) ? SFB.i18n.wordCount : '%1$d / %2$d words';
    display = display.replace('%1$d', words).replace('%2$d', limit);
    $counter.text(display);
    if(words > limit){
      $counter.addClass('sfb-over');
    } else {
      $counter.removeClass('sfb-over');
    }
  }

  function setLoading($btn, loading){
    if(loading){
      $btn.addClass('loading').prop('disabled', true);
    } else {
      $btn.removeClass('loading').prop('disabled', false);
    }
  }

  function clearErrors($wrap){
    $wrap.find('.sfb-error-text').text('');
    $wrap.find('.sfb-notice.sfb-error').hide().text('');
  }

  function showSuccess($wrap, message){
    var $notice = $wrap.find('.sfb-notice.sfb-success');
    $notice.text(message || (SFB && SFB.i18n && SFB.i18n.success ? SFB.i18n.success : 'Success')).fadeIn(150);
    setTimeout(function(){ $notice.fadeOut(250); }, 3000);
  }

  $(document).on('input', '#sfb_message', function(){
    var $t = $(this);
    var limit = parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10);
    var words = countWords($t.val());

    if(words > limit){
      var parts = String($t.val()).trim().replace(/\s+/g, ' ').split(' ');
      var trimmed = parts.slice(0, limit).join(' ');
      $t.val(trimmed + ' ');
    }
    updateCounter($t, $('#sfb_counter'), limit);
  });

  $(document).ready(function(){
    var $wrap = $('[data-sfb]');
    if(!$wrap.length){ return; }

    var $form = $wrap.find('.sfb-form');
    var $name = $wrap.find('#sfb_name');
    var $msg  = $wrap.find('#sfb_message');
    var $btn  = $wrap.find('.sfb-button');
    var $items = $wrap.find('.sfb-items');
    var $empty = $wrap.find('.sfb-empty');

    updateCounter($msg, $('#sfb_counter'), parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10));

    $form.on('submit', function(e){
      e.preventDefault();
      clearErrors($wrap);

      var limit = parseInt((SFB && SFB.wordLimit) ? SFB.wordLimit : 150, 10);
      var errs = {};
      if($.trim($name.val()) === ''){ errs.name = (SFB && SFB.i18n && SFB.i18n.required) ? SFB.i18n.required : 'Required'; }
      if($.trim($msg.val()) === ''){ errs.message = (SFB && SFB.i18n && SFB.i18n.required) ? SFB.i18n.required : 'Required'; }
      if(countWords($msg.val()) > limit){ errs.message = (SFB && SFB.i18n && SFB.i18n.tooLong) ? SFB.i18n.tooLong : 'Too long'; }

      if(Object.keys(errs).length){
        if(errs.name){ $wrap.find('[data-error-for="name"]').text(errs.name); }
        if(errs.message){ $wrap.find('[data-error-for="message"]').text(errs.message); }
        updateCounter($msg, $('#sfb_counter'), limit);
        return;
      }

      setLoading($btn, true);

      $.ajax({
        url: (SFB && SFB.ajaxUrl) ? SFB.ajaxUrl : '',
        method: 'POST',
        dataType: 'json',
        data: {
          action: 'sfb_submit',
          nonce: (SFB && SFB.nonce) ? SFB.nonce : '',
          name: $name.val(),
          message: $msg.val()
        }
      }).done(function(resp){
        if(resp && resp.success){
          showSuccess($wrap, resp.data && resp.data.message ? resp.data.message : null);
          // Clear form
          $name.val('');
          $msg.val('');
          updateCounter($msg, $('#sfb_counter'), parseInt(SFB.wordLimit, 10));
          $wrap.find('[data-error-for="name"]').text('');
          $wrap.find('[data-error-for="message"]').text('');

          if($empty.length){ $empty.remove(); }
          if($items.is(':hidden')){ $items.show(); }
          if(resp.data && resp.data.itemHtml){
            // Prepend new item
            $items.prepend(resp.data.itemHtml);
          }
        } else {
          var msg = (SFB && SFB.i18n && SFB.i18n.error) ? SFB.i18n.error : 'Error';
          $wrap.find('.sfb-notice.sfb-error').text(msg).show();
        }
      }).fail(function(xhr){
        var data = xhr && xhr.responseJSON ? xhr.responseJSON : null;
        if(data && data.data && data.data.errors){
          if(data.data.errors.name){ $wrap.find('[data-error-for="name"]').text(data.data.errors.name); }
          if(data.data.errors.message){ $wrap.find('[data-error-for="message"]').text(data.data.errors.message); }
        } else {
          var msg = (SFB && SFB.i18n && SFB.i18n.error) ? SFB.i18n.error : 'Error';
          $wrap.find('.sfb-notice.sfb-error').text(msg).show();
        }
      }).always(function(){
        setLoading($btn, false);
      });
    });
  });
})(jQuery);
