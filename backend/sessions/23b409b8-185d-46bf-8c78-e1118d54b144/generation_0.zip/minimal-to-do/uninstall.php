<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data: remove user meta storing tasks for all users.
$users = get_users(array(
    'fields' => array('ID'),
));
if (!empty($users)) {
    foreach ($users as $user) {
        delete_user_meta((int) $user->ID, 'mtd_tasks');
    }
}
