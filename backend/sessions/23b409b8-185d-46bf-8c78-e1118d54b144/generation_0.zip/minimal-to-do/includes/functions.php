<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get tasks for a user.
 *
 * @param int $user_id
 * @return array
 */
function mtd_get_tasks($user_id) {
    $tasks = get_user_meta((int) $user_id, 'mtd_tasks', true);
    if (!is_array($tasks)) {
        $tasks = array();
    }
    return $tasks;
}

/**
 * Save tasks for a user.
 *
 * @param int   $user_id
 * @param array $tasks
 * @return bool
 */
function mtd_save_tasks($user_id, $tasks) {
    if (!is_array($tasks)) {
        $tasks = array();
    }
    return (bool) update_user_meta((int) $user_id, 'mtd_tasks', array_values($tasks));
}

/**
 * Sanitize a task's text.
 *
 * @param string $text
 * @return string
 */
function mtd_sanitize_task_text($text) {
    $text = sanitize_text_field($text);
    $text = mb_substr($text, 0, 200);
    return $text;
}

/**
 * Find task index by ID.
 *
 * @param array  $tasks
 * @param string $id
 * @return int Index or -1 if not found.
 */
function mtd_find_task_index($tasks, $id) {
    if (!is_array($tasks)) {
        return -1;
    }
    foreach ($tasks as $index => $task) {
        if (isset($task['id']) && (string) $task['id'] === (string) $id) {
            return (int) $index;
        }
    }
    return -1;
}
