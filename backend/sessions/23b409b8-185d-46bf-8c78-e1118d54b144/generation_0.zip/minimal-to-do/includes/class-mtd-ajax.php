<?php
if (!defined('ABSPATH')) {
    exit;
}

class MTD_Ajax {
    public function __construct() {
        add_action('wp_ajax_mtd_add', array($this, 'add'));
        add_action('wp_ajax_mtd_toggle', array($this, 'toggle'));
        add_action('wp_ajax_mtd_delete', array($this, 'delete'));
    }

    private function check_security() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => esc_html__('You must be logged in.', 'minimal-to-do')), 403);
        }
        check_ajax_referer('mtd_nonce', 'nonce');
    }

    public function add() {
        $this->check_security();
        $task_text = isset($_POST['task']) ? mtd_sanitize_task_text(wp_unslash($_POST['task'])) : '';
        if ($task_text === '') {
            wp_send_json_error(array('message' => esc_html__('Task cannot be empty.', 'minimal-to-do')), 400);
        }

        $user_id = get_current_user_id();
        $tasks   = mtd_get_tasks($user_id);

        $new = array(
            'id'      => function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('mtd_', true),
            'text'    => $task_text,
            'done'    => false,
            'created' => time(),
        );

        // Prepend to keep newest on top.
        array_unshift($tasks, $new);
        mtd_save_tasks($user_id, $tasks);

        wp_send_json_success(array('task' => $new));
    }

    public function toggle() {
        $this->check_security();
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        if ($id === '') {
            wp_send_json_error(array('message' => esc_html__('Invalid task ID.', 'minimal-to-do')), 400);
        }

        $user_id = get_current_user_id();
        $tasks   = mtd_get_tasks($user_id);
        $index   = mtd_find_task_index($tasks, $id);

        if (-1 === $index) {
            wp_send_json_error(array('message' => esc_html__('Task not found.', 'minimal-to-do')), 404);
        }

        $tasks[$index]['done'] = !empty($tasks[$index]['done']) ? false : true;
        mtd_save_tasks($user_id, $tasks);

        wp_send_json_success(array('task' => $tasks[$index]));
    }

    public function delete() {
        $this->check_security();
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        if ($id === '') {
            wp_send_json_error(array('message' => esc_html__('Invalid task ID.', 'minimal-to-do')), 400);
        }

        $user_id = get_current_user_id();
        $tasks   = mtd_get_tasks($user_id);
        $index   = mtd_find_task_index($tasks, $id);

        if (-1 === $index) {
            wp_send_json_error(array('message' => esc_html__('Task not found.', 'minimal-to-do')), 404);
        }

        array_splice($tasks, $index, 1);
        mtd_save_tasks($user_id, $tasks);

        wp_send_json_success(array('id' => $id));
    }
}

new MTD_Ajax();
