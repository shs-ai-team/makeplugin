(function($){
    'use strict';

    function renderItem(task){
        var li = $('<li/>', {
            'class': 'mtd-item' + (task.done ? ' is-done' : ''),
            'data-id': task.id
        });
        var toggle = $('<button/>', {'type':'button','class':'mtd-toggle','aria-pressed': task.done ? 'true':'false'}).append($('<span/>',{'class':'screen-reader-text',text: 'Toggle done'}));
        var text = $('<span/>', {'class':'mtd-text', text: task.text});
        var del = $('<button/>', {'type':'button','class':'mtd-delete','aria-label':'Delete task'}).append($('<span/>',{'class':'screen-reader-text',text: 'Delete'}));
        li.append(toggle, text, del);
        return li;
    }

    function onAdd(e){
        e.preventDefault();
        var $wrap = $(e.delegateTarget).closest('.mtd-wrapper');
        var $input = $(e.delegateTarget).find('input[name="task"]');
        var val = ($input.val() || '').trim();
        if(!val){ return; }
        $.post(MTD.ajax_url, {
            action: 'mtd_add',
            nonce: MTD.nonce,
            task: val
        }).done(function(resp){
            if(resp && resp.success && resp.data && resp.data.task){
                var $list = $wrap.find('.mtd-list');
                $list.prepend(renderItem(resp.data.task));
                $input.val('');
            }
        });
    }

    function onToggle(e){
        var $btn = $(e.currentTarget);
        var $li = $btn.closest('.mtd-item');
        var id = $li.data('id');
        if(!id){ return; }
        $.post(MTD.ajax_url, {
            action: 'mtd_toggle',
            nonce: MTD.nonce,
            id: id
        }).done(function(resp){
            if(resp && resp.success && resp.data && resp.data.task){
                var done = !!resp.data.task.done;
                $li.toggleClass('is-done', done);
                $btn.attr('aria-pressed', done ? 'true' : 'false');
            }
        });
    }

    function onDelete(e){
        var $btn = $(e.currentTarget);
        var $li = $btn.closest('.mtd-item');
        var id = $li.data('id');
        if(!id){ return; }
        $.post(MTD.ajax_url, {
            action: 'mtd_delete',
            nonce: MTD.nonce,
            id: id
        }).done(function(resp){
            if(resp && resp.success){
                $li.remove();
            }
        });
    }

    $(document).on('submit', '.mtd-form', onAdd);
    $(document).on('click', '.mtd-toggle', onToggle);
    $(document).on('click', '.mtd-delete', onDelete);
})(jQuery);
