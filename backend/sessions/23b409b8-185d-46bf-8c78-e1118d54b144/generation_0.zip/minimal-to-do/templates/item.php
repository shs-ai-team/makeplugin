<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render a single task item as HTML list element.
 *
 * @param array $task
 * @return string
 */
function mtd_render_item($task) {
    $id      = isset($task['id']) ? (string) $task['id'] : '';
    $text    = isset($task['text']) ? (string) $task['text'] : '';
    $done    = !empty($task['done']);
    $classes = 'mtd-item' . ($done ? ' is-done' : '');

    ob_start();
    echo '<li class="' . esc_attr($classes) . '" data-id="' . esc_attr($id) . '">';
    echo '  <button type="button" class="mtd-toggle" aria-pressed="' . esc_attr($done ? 'true' : 'false') . '">';
    echo '    <span class="screen-reader-text">' . esc_html__('Toggle done', 'minimal-to-do') . '</span>';
    echo '  </button>';
    echo '  <span class="mtd-text">' . esc_html($text) . '</span>';
    echo '  <button type="button" class="mtd-delete" aria-label="' . esc_attr__('Delete task', 'minimal-to-do') . '">';
    echo '    <span class="screen-reader-text">' . esc_html__('Delete', 'minimal-to-do') . '</span>';
    echo '  </button>';
    echo '</li>';
    return ob_get_clean();
}
