<?php
/**
 * Plugin Name: Minimal To‑Do
 * Description: A small, per‑user to‑do list that can be placed on public pages.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: minimal-to-do
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('MTD_VERSION')) {
    define('MTD_VERSION', '1.0.0');
}
if (!defined('MTD_PLUGIN_FILE')) {
    define('MTD_PLUGIN_FILE', __FILE__);
}
if (!defined('MTD_PLUGIN_DIR')) {
    define('MTD_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('MTD_PLUGIN_URL')) {
    define('MTD_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Load text domain.
function mtd_load_textdomain() {
    load_plugin_textdomain('minimal-to-do', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'mtd_load_textdomain');

// Includes.
require_once MTD_PLUGIN_DIR . 'includes/functions.php';
require_once MTD_PLUGIN_DIR . 'templates/item.php';
require_once MTD_PLUGIN_DIR . 'includes/class-mtd-ajax.php';

// Shortcode renderer and assets.
function mtd_enqueue_assets() {
    wp_enqueue_style(
        'mtd-style',
        MTD_PLUGIN_URL . 'assets/css/style.css',
        array(),
        MTD_VERSION
    );

    wp_enqueue_script(
        'mtd-script',
        MTD_PLUGIN_URL . 'assets/js/main.js',
        array('jquery'),
        MTD_VERSION,
        true
    );

    $data = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('mtd_nonce'),
        'i18n'     => array(
            /* translators: Button label to delete a task */
            'delete' => esc_html__('Delete', 'minimal-to-do'),
            /* translators: Checkbox label to mark task done */
            'done'   => esc_html__('Done', 'minimal-to-do'),
            /* translators: Placeholder for task input */
            'placeholder' => esc_html__('Add a task…', 'minimal-to-do'),
            /* translators: Button label to add task */
            'add' => esc_html__('Add', 'minimal-to-do')
        )
    );
    wp_localize_script('mtd-script', 'MTD', $data);
}

function mtd_shortcode($atts = array(), $content = null) {
    $atts = shortcode_atts(array(), $atts, 'minimal_todo');

    // Enqueue assets only when shortcode is used.
    mtd_enqueue_assets();

    ob_start();

    echo '<div class="mtd-wrapper" data-nonce="' . esc_attr(wp_create_nonce('mtd_nonce')) . '">';

    if (!is_user_logged_in()) {
        $login_url = wp_login_url(get_permalink());
        echo '<p class="mtd-login-prompt">' . wp_kses_post(sprintf(
            /* translators: %s: login URL */
            __("Please <a href=\"%s\">sign in</a> to manage your to‑do list.", 'minimal-to-do'),
            esc_url($login_url)
        )) . '</p>';
        echo '</div>';
        return ob_get_clean();
    }

    echo '<form class="mtd-form" action="#" method="post" novalidate>\n';
    echo '  <label class="screen-reader-text" for="mtd-new-task">' . esc_html__('Add a task', 'minimal-to-do') . '</label>\n';
    echo '  <input type="text" id="mtd-new-task" name="task" maxlength="200" placeholder="' . esc_attr__('Add a task…', 'minimal-to-do') . '" />\n';
    echo '  <button type="submit" class="mtd-add-btn">' . esc_html__('Add', 'minimal-to-do') . '</button>\n';
    echo '</form>';

    $tasks = mtd_get_tasks(get_current_user_id());

    echo '<ul class="mtd-list" aria-live="polite">';
    if (!empty($tasks) && is_array($tasks)) {
        foreach ($tasks as $task) {
            // Render each task item using template.
            echo mtd_render_item($task);
        }
    }
    echo '</ul>';

    echo '</div>';

    return ob_get_clean();
}
add_shortcode('minimal_todo', 'mtd_shortcode');
