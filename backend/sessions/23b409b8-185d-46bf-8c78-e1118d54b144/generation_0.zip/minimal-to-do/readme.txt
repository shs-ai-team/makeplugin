=== Minimal To‑Do ===
Contributors: makeplugin
Tags: to-do, todo, tasks, minimal, user, list
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

A small, per‑user to‑do list that can be placed on public pages.

== Description ==
Provide a clean, distraction‑free to‑do list where logged‑in users can add a task (text only), mark it done/undone, and delete it. Lists are personal per user (login‑based) and persist across sessions. The to‑do can be placed on any public page; when viewed by a logged‑in user it shows their own list, and guests see a simple sign‑in prompt instead of controls. Keep the interface minimal with a single input and a simple list; default order is newest on top. No extra fields (no dates, priorities, categories) and no bulk actions or editing beyond toggle and delete. Use unobtrusive styling that blends with the site.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/minimal-to-do` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the shortcode `[minimal_todo]` to any page or post.

== Frequently Asked Questions ==
= Who can see the tasks? =
Only the logged‑in user can see and manage their own tasks when viewing the page. Guests will see a sign‑in prompt.

= Can I add due dates or priorities? =
No. This plugin is intentionally minimal: text‑only tasks with toggle and delete actions.

== Screenshots ==
1. Minimal to‑do list on a page.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
