<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}
// No options to delete. Reserved for future cleanup if options are added.
