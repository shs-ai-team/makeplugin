(function(){
    'use strict';

    // Ensure data exists
    if (typeof window.RQBData === 'undefined' || !Array.isArray(window.RQBData.quotes)) {
        return;
    }

    function getRandomQuote(excludeText) {
        var quotes = window.RQBData.quotes;
        if (!quotes.length) return null;
        var tries = 0;
        var picked = null;
        do {
            picked = quotes[Math.floor(Math.random() * quotes.length)];
            tries++;
        } while (picked && picked.text === excludeText && tries < 10);
        return picked;
    }

    function initInstance(container) {
        var textEl = container.querySelector('.rqb-quote-text');
        var authorEl = container.querySelector('.rqb-quote-author');
        var btn = container.querySelector('.rqb-button');
        if (!textEl || !btn) return;

        var label = (window.RQBData.strings && window.RQBData.strings.newQuote) ? window.RQBData.strings.newQuote : 'New quote';
        btn.textContent = label;

        btn.addEventListener('click', function(){
            var currentText = textEl.textContent || '';
            var q = getRandomQuote(currentText);
            if (!q) return;
            textEl.textContent = q.text;
            if (authorEl) {
                if (q.author) {
                    authorEl.textContent = '\u2014 ' + q.author;
                } else {
                    authorEl.textContent = '';
                }
            }
        });
    }

    function initAll(){
        var nodes = document.querySelectorAll('.rqb-container');
        if (!nodes.length) return;
        for (var i=0; i<nodes.length; i++) {
            initInstance(nodes[i]);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAll);
    } else {
        initAll();
    }
})();
