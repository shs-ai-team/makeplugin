<?php
/**
 * Shortcode class for Random Quote Button
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('RQB_Shortcode')) {
    class RQB_Shortcode {
        /**
         * Register shortcode.
         */
        public function register() {
            add_shortcode('random_quote_button', array($this, 'render_shortcode'));
        }

        /**
         * Enqueue assets when shortcode is used.
         */
        private function enqueue_assets() {
            wp_enqueue_style(
                'rqb-style',
                RQB_PLUGIN_URL . 'assets/css/style.css',
                array(),
                RQB_PLUGIN_VERSION
            );

            wp_register_script(
                'rqb-frontend',
                RQB_PLUGIN_URL . 'assets/js/frontend.js',
                array('wp-i18n'),
                RQB_PLUGIN_VERSION,
                true
            );

            $data = array(
                'quotes' => $this->get_quotes(),
                'strings' => array(
                    // translators: Button label to get a new quote
                    'newQuote' => esc_html__('New quote', 'random-quote-button')
                )
            );

            wp_localize_script('rqb-frontend', 'RQBData', $data);
            wp_enqueue_script('rqb-frontend');
        }

        /**
         * Render the shortcode output.
         *
         * @param array $atts Shortcode attributes (unused).
         * @return string HTML output for the quote box.
         */
        public function render_shortcode($atts) {
            $this->enqueue_assets();

            $quotes = $this->get_quotes();
            if (empty($quotes) || !is_array($quotes)) {
                return '';
            }

            // Pick a random initial quote
            $initial = $quotes[array_rand($quotes)];
            $quote_text = isset($initial['text']) ? $initial['text'] : '';
            $quote_author = isset($initial['author']) ? $initial['author'] : '';

            ob_start();
            $template = RQB_PLUGIN_DIR . 'templates/quote-box.php';
            if (file_exists($template)) {
                // Safe variables extracted for template
                $initial_text = $quote_text;
                $initial_author = $quote_author;
                include $template;
            }
            return ob_get_clean();
        }

        /**
         * Get the list of quotes.
         *
         * @return array[] Array of [ 'text' => string, 'author' => string ]
         */
        private function get_quotes() {
            // Curated selection of short, well-known quotes
            $quotes = array(
                array('text' => __('The only limit to our realization of tomorrow is our doubts of today.', 'random-quote-button'), 'author' => __('Franklin D. Roosevelt', 'random-quote-button')),
                array('text' => __('In the middle of difficulty lies opportunity.', 'random-quote-button'), 'author' => __('Albert Einstein', 'random-quote-button')),
                array('text' => __('Life is what happens when you’re busy making other plans.', 'random-quote-button'), 'author' => __('John Lennon', 'random-quote-button')),
                array('text' => __('The journey of a thousand miles begins with one step.', 'random-quote-button'), 'author' => __('Lao Tzu', 'random-quote-button')),
                array('text' => __('Success is not final, failure is not fatal: it is the courage to continue that counts.', 'random-quote-button'), 'author' => __('Winston Churchill', 'random-quote-button')),
                array('text' => __('What we think, we become.', 'random-quote-button'), 'author' => __('Buddha', 'random-quote-button')),
                array('text' => __('You miss 100% of the shots you don’t take.', 'random-quote-button'), 'author' => __('Wayne Gretzky', 'random-quote-button')),
                array('text' => __('Whether you think you can or you think you can’t, you’re right.', 'random-quote-button'), 'author' => __('Henry Ford', 'random-quote-button')),
                array('text' => __('If you can dream it, you can do it.', 'random-quote-button'), 'author' => __('Walt Disney', 'random-quote-button')),
                array('text' => __('Act as if what you do makes a difference. It does.', 'random-quote-button'), 'author' => __('William James', 'random-quote-button')),
                array('text' => __('Keep going. Be all in.', 'random-quote-button'), 'author' => __('Bryan Hutchinson', 'random-quote-button')),
                array('text' => __('Well begun is half done.', 'random-quote-button'), 'author' => __('Aristotle', 'random-quote-button')),
                array('text' => __('Turn your wounds into wisdom.', 'random-quote-button'), 'author' => __('Oprah Winfrey', 'random-quote-button')),
                array('text' => __('Stay hungry, stay foolish.', 'random-quote-button'), 'author' => __('Steve Jobs', 'random-quote-button')),
                array('text' => __('The best way out is always through.', 'random-quote-button'), 'author' => __('Robert Frost', 'random-quote-button')),
                array('text' => __('Dream big and dare to fail.', 'random-quote-button'), 'author' => __('Norman Vaughan', 'random-quote-button')),
                array('text' => __('Everything you can imagine is real.', 'random-quote-button'), 'author' => __('Pablo Picasso', 'random-quote-button')),
                array('text' => __('Don’t wait. The time will never be just right.', 'random-quote-button'), 'author' => __('Napoleon Hill', 'random-quote-button')),
                array('text' => __('Keep your face always toward the sunshine—and shadows will fall behind you.', 'random-quote-button'), 'author' => __('Walt Whitman', 'random-quote-button')),
                array('text' => __('It always seems impossible until it’s done.', 'random-quote-button'), 'author' => __('Nelson Mandela', 'random-quote-button')),
                array('text' => __('Do what you can, with what you have, where you are.', 'random-quote-button'), 'author' => __('Theodore Roosevelt', 'random-quote-button')),
                array('text' => __('Quality is not an act, it is a habit.', 'random-quote-button'), 'author' => __('Aristotle', 'random-quote-button')),
                array('text' => __('Believe you can and you’re halfway there.', 'random-quote-button'), 'author' => __('Theodore Roosevelt', 'random-quote-button')),
                array('text' => __('Simplicity is the ultimate sophistication.', 'random-quote-button'), 'author' => __('Leonardo da Vinci', 'random-quote-button')),
                array('text' => __('Action is the foundational key to all success.', 'random-quote-button'), 'author' => __('Pablo Picasso', 'random-quote-button'))
            );

            $sanitized = array();
            foreach ($quotes as $q) {
                $text = isset($q['text']) ? wp_strip_all_tags($q['text']) : '';
                $author = isset($q['author']) ? wp_strip_all_tags($q['author']) : '';
                if ($text !== '') {
                    $sanitized[] = array(
                        'text' => $text,
                        'author' => $author,
                    );
                }
            }

            return $sanitized;
        }
    }
}
