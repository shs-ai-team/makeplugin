<?php
/**
 * Plugin Name: Random Quote Button
 * Description: Shows a random quote with a button to change it
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: random-quote-button
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load text domain
function rqb_load_textdomain() {
    load_plugin_textdomain('random-quote-button', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'rqb_load_textdomain');

// Define constants
if (!defined('RQB_PLUGIN_VERSION')) {
    define('RQB_PLUGIN_VERSION', '1.0.0');
}
if (!defined('RQB_PLUGIN_DIR')) {
    define('RQB_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('RQB_PLUGIN_URL')) {
    define('RQB_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Include shortcode class
require_once RQB_PLUGIN_DIR . 'includes/class-rqb-shortcode.php';

// Initialize
function rqb_init() {
    $shortcode = new RQB_Shortcode();
    $shortcode->register();
}
add_action('plugins_loaded', 'rqb_init');
