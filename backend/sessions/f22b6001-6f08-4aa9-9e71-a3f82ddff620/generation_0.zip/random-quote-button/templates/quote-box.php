<?php
if (!defined('ABSPATH')) {
    exit;
}
/** @var string $initial_text */
/** @var string $initial_author */
?>
<div class="rqb-container" data-rqb-instance>
    <div class="rqb-box" role="region" aria-live="polite">
        <div class="rqb-quote-text"><?php echo esc_html($initial_text); ?></div>
        <?php if (!empty($initial_author)) : ?>
            <div class="rqb-quote-author">&mdash; <?php echo esc_html($initial_author); ?></div>
        <?php endif; ?>
    </div>
    <button type="button" class="rqb-button" aria-label="<?php echo esc_attr(esc_html__('Get a new quote', 'random-quote-button')); ?>">
        <?php echo esc_html__('New quote', 'random-quote-button'); ?>
    </button>
</div>
