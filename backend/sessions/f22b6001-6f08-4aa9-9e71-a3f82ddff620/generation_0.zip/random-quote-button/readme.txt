=== Random Quote Button ===
Contributors: makeplugin
Tags: quotes, shortcode, button, random, widget, content
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Shows a random quote with a button to change it. Simple, clean, and responsive.

== Description ==
Display a simple quote box that shows one random quote from a built-in list on page load, with a button labeled "New quote" that switches to another random quote instantly without reloading the page. Includes a preloaded selection of short, well-known quotes with author names. Minimal, theme-friendly styling (centered text, subtle container, responsive). Place the quote box anywhere using the [random_quote_button] shortcode.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/random-quote-button` directory or install via the Plugins screen in WordPress.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the shortcode `[random_quote_button]` in any post or page.

== Usage ==
- Insert `[random_quote_button]` into your content.
- The quote will change instantly on button click via JavaScript, no page reloads.

== Frequently Asked Questions ==
= Can I add my own quotes? =
Not yet. This version uses a curated built-in list.

= Does it work with any theme? =
Yes. Styling is minimal and clean to blend with most themes.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
