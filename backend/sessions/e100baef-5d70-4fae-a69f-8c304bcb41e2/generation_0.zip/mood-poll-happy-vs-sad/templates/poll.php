<?php
if (!defined('ABSPATH')) {
    exit;
}

$happy     = isset($data['happy']) ? (int) $data['happy'] : 0;
$sad       = isset($data['sad']) ? (int) $data['sad'] : 0;
$total     = isset($data['total']) ? (int) $data['total'] : 0;
happy_pct: $happy_pct = isset($data['happy_pct']) ? (int) $data['happy_pct'] : 0;
$sad_pct   = isset($data['sad_pct']) ? (int) $data['sad_pct'] : 0;
?>
<div class="mphvs-container" data-nonce="<?php echo esc_attr( wp_create_nonce('mphvs_nonce') ); ?>">
    <div class="mphvs-buttons" role="group" aria-label="<?php echo esc_attr( esc_html__('Mood selection', 'mood-poll-happy-vs-sad') ); ?>">
        <button type="button" class="mphvs-btn mphvs-happy" data-choice="happy" aria-label="<?php echo esc_attr( esc_html__('Vote Happy', 'mood-poll-happy-vs-sad') ); ?>">
            <?php echo esc_html__('Happy', 'mood-poll-happy-vs-sad'); ?>
        </button>
        <button type="button" class="mphvs-btn mphvs-sad" data-choice="sad" aria-label="<?php echo esc_attr( esc_html__('Vote Sad', 'mood-poll-happy-vs-sad') ); ?>">
            <?php echo esc_html__('Sad', 'mood-poll-happy-vs-sad'); ?>
        </button>
    </div>

    <div class="mphvs-stats" aria-live="polite">
        <div class="mphvs-counts">
            <span class="mphvs-count mphvs-count-happy" aria-label="<?php echo esc_attr( esc_html__('Happy votes', 'mood-poll-happy-vs-sad') ); ?>">
                <?php echo esc_html__('Happy', 'mood-poll-happy-vs-sad'); ?>:
                <strong class="mphvs-happy-count"><?php echo esc_html( (string) $happy ); ?></strong>
                <span class="mphvs-happy-pct">(<?php echo esc_html( (string) $happy_pct ); ?>%)</span>
            </span>
            <span class="mphvs-count mphvs-count-sad" aria-label="<?php echo esc_attr( esc_html__('Sad votes', 'mood-poll-happy-vs-sad') ); ?>">
                <?php echo esc_html__('Sad', 'mood-poll-happy-vs-sad'); ?>:
                <strong class="mphvs-sad-count"><?php echo esc_html( (string) $sad ); ?></strong>
                <span class="mphvs-sad-pct">(<?php echo esc_html( (string) $sad_pct ); ?>%)</span>
            </span>
            <span class="mphvs-count mphvs-count-total">
                <?php echo esc_html__('Total', 'mood-poll-happy-vs-sad'); ?>:
                <strong class="mphvs-total-count"><?php echo esc_html( (string) $total ); ?></strong>
            </span>
        </div>

        <div class="mphvs-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( (string) $happy_pct ); ?>" aria-label="<?php echo esc_attr( esc_html__('Happy percent', 'mood-poll-happy-vs-sad') ); ?>">
            <div class="mphvs-progress-happy" style="width: <?php echo esc_attr( (string) $happy_pct ); ?>%"></div>
            <div class="mphvs-progress-sad" style="width: <?php echo esc_attr( (string) $sad_pct ); ?>%"></div>
        </div>
    </div>
</div>
