<?php
if (!defined('ABSPATH')) {
    exit;
}

class MPHVS_Plugin {
    public function init() {
        add_action('init', array($this, 'load_textdomain'));
        add_shortcode('mood_poll', array($this, 'render_shortcode'));

        add_action('wp_ajax_mphvs_vote', array($this, 'ajax_vote'));
        add_action('wp_ajax_nopriv_mphvs_vote', array($this, 'ajax_vote'));

        add_action('wp_ajax_mphvs_get', array($this, 'ajax_get'));
        add_action('wp_ajax_nopriv_mphvs_get', array($this, 'ajax_get'));
    }

    public function load_textdomain() {
        load_plugin_textdomain('mood-poll-happy-vs-sad', false, dirname(plugin_basename(MPHVS_PLUGIN_FILE)) . '/languages');
    }

    private function register_assets() {
        $suffix = '';
        wp_register_style(
            'mphvs-style',
            plugin_dir_url(MPHVS_PLUGIN_FILE) . 'assets/css/style.css',
            array(),
            MPHVS_VERSION
        );

        wp_register_script(
            'mphvs-script',
            plugin_dir_url(MPHVS_PLUGIN_FILE) . 'assets/js/script.js',
            array('wp-i18n'),
            MPHVS_VERSION,
            true
        );

        $data = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('mphvs_nonce'),
            'i18n'     => array(
                'happy'        => esc_html__('Happy', 'mood-poll-happy-vs-sad'),
                'sad'          => esc_html__('Sad', 'mood-poll-happy-vs-sad'),
                'total'        => esc_html__('Total', 'mood-poll-happy-vs-sad'),
                'votes'        => esc_html__('votes', 'mood-poll-happy-vs-sad'),
                'happyVotes'   => esc_html__('Happy votes', 'mood-poll-happy-vs-sad'),
                'sadVotes'     => esc_html__('Sad votes', 'mood-poll-happy-vs-sad'),
                'happyPercent' => esc_html__('Happy percent', 'mood-poll-happy-vs-sad'),
                'sadPercent'   => esc_html__('Sad percent', 'mood-poll-happy-vs-sad'),
            ),
        );
        wp_localize_script('mphvs-script', 'mphvsData', $data);
    }

    private function enqueue_assets() {
        $this->register_assets();
        wp_enqueue_style('mphvs-style');
        wp_enqueue_script('mphvs-script');
    }

    public function render_shortcode($atts) {
        $this->enqueue_assets();

        $counts = get_option('mphvs_counts');
        if (!is_array($counts)) {
            $counts = array('happy' => 0, 'sad' => 0);
        }
        $happy = isset($counts['happy']) ? (int) $counts['happy'] : 0;
        $sad   = isset($counts['sad']) ? (int) $counts['sad'] : 0;
        $total = $happy + $sad;
        $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
        $sad_pct   = $total > 0 ? 100 - $happy_pct : 0;

        ob_start();
        $data = array(
            'happy'      => $happy,
            'sad'        => $sad,
            'total'      => $total,
            'happy_pct'  => $happy_pct,
            'sad_pct'    => $sad_pct,
        );
        include plugin_dir_path(MPHVS_PLUGIN_FILE) . 'templates/poll.php';
        return ob_get_clean();
    }

    public function ajax_vote() {
        if (!isset($_POST['nonce'])) {
            wp_send_json_error(array('message' => esc_html__('Invalid request.', 'mood-poll-happy-vs-sad')));
        }
        $nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
        if (!wp_verify_nonce($nonce, 'mphvs_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed.', 'mood-poll-happy-vs-sad')));
        }

        $choice = isset($_POST['choice']) ? sanitize_text_field(wp_unslash($_POST['choice'])) : '';
        $choice = in_array($choice, array('happy', 'sad'), true) ? $choice : '';
        if ('' === $choice) {
            wp_send_json_error(array('message' => esc_html__('Invalid choice.', 'mood-poll-happy-vs-sad')));
        }

        $counts = get_option('mphvs_counts');
        if (!is_array($counts)) {
            $counts = array('happy' => 0, 'sad' => 0);
        }
        $counts[$choice] = isset($counts[$choice]) ? (int) $counts[$choice] + 1 : 1;
        update_option('mphvs_counts', array(
            'happy' => isset($counts['happy']) ? (int) $counts['happy'] : 0,
            'sad'   => isset($counts['sad']) ? (int) $counts['sad'] : 0,
        ));

        $happy = isset($counts['happy']) ? (int) $counts['happy'] : 0;
        $sad   = isset($counts['sad']) ? (int) $counts['sad'] : 0;
        $total = $happy + $sad;
        $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
        $sad_pct   = $total > 0 ? 100 - $happy_pct : 0;

        wp_send_json_success(array(
            'happy'     => $happy,
            'sad'       => $sad,
            'total'     => $total,
            'happy_pct' => $happy_pct,
            'sad_pct'   => $sad_pct,
        ));
    }

    public function ajax_get() {
        if (!isset($_POST['nonce'])) {
            wp_send_json_error(array('message' => esc_html__('Invalid request.', 'mood-poll-happy-vs-sad')));
        }
        $nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
        if (!wp_verify_nonce($nonce, 'mphvs_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed.', 'mood-poll-happy-vs-sad')));
        }

        $counts = get_option('mphvs_counts');
        if (!is_array($counts)) {
            $counts = array('happy' => 0, 'sad' => 0);
        }

        $happy = isset($counts['happy']) ? (int) $counts['happy'] : 0;
        $sad   = isset($counts['sad']) ? (int) $counts['sad'] : 0;
        $total = $happy + $sad;
        $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
        $sad_pct   = $total > 0 ? 100 - $happy_pct : 0;

        wp_send_json_success(array(
            'happy'     => $happy,
            'sad'       => $sad,
            'total'     => $total,
            'happy_pct' => $happy_pct,
            'sad_pct'   => $sad_pct,
        ));
    }
}
