=== Mood Poll (Happy vs Sad) ===
Contributors: makeplugin
Tags: poll, mood, voting, feedback, buttons, progress bar, lightweight, ajax
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Two-button mood poll with live counts, percentages, and a progress bar.

== Description ==
Provide a lightweight, site-placeable mood poll with two buttons: Happy (light green) and Sad (light red). Anyone visiting can click either button repeatedly; each click increments the respective global count. Below the buttons, always show stats: total votes for Happy and Sad, percentage breakdown for each, and a horizontal progress bar visualizing the proportions. Counts start at 0 and persist. The poll is responsive, fast, and accessible (clear labels, readable contrast). Site owners can place the poll anywhere via the [mood_poll] shortcode. No login required and no per-user limits or tracking.

== Installation ==
1. Upload the plugin folder to /wp-content/plugins/.
2. Activate the plugin from the Plugins screen.
3. Add the shortcode [mood_poll] to any post, page, or widget.

== Frequently Asked Questions ==
= Can visitors vote multiple times? =
Yes. There are no per-user limits or tracking.

= How do I display the poll? =
Use the [mood_poll] shortcode in your content.

== Changelog ==
= 1.0.0 =
- Initial release with live voting, percentages, and progress bar.
