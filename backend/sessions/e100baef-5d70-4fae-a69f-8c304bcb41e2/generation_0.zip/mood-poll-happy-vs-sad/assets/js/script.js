(function(){
    'use strict';

    function updateUI(container, data){
        if(!container || !data){return;}
        var happyCount = container.querySelector('.mphvs-happy-count');
        var sadCount = container.querySelector('.mphvs-sad-count');
        var totalCount = container.querySelector('.mphvs-total-count');
        var happyPct = container.querySelector('.mphvs-happy-pct');
        var sadPct = container.querySelector('.mphvs-sad-pct');
        var progress = container.querySelector('.mphvs-progress');
        var barHappy = container.querySelector('.mphvs-progress-happy');
        var barSad = container.querySelector('.mphvs-progress-sad');

        if(happyCount){ happyCount.textContent = String(data.happy); }
        if(sadCount){ sadCount.textContent = String(data.sad); }
        if(totalCount){ totalCount.textContent = String(data.total); }
        if(happyPct){ happyPct.textContent = '(' + String(data.happy_pct) + '%)'; }
        if(sadPct){ sadPct.textContent = '(' + String(data.sad_pct) + '%)'; }
        if(progress){ progress.setAttribute('aria-valuenow', String(data.happy_pct)); }
        if(barHappy){ barHappy.style.width = String(data.happy_pct) + '%'; }
        if(barSad){ barSad.style.width = String(data.sad_pct) + '%'; }
    }

    function sendRequest(action, payload){
        if(!window.mphvsData){ return Promise.reject('no-data'); }
        var ajaxUrl = String(window.mphvsData.ajax_url || '');
        var nonce = String(window.mphvsData.nonce || '');
        var fd = new FormData();
        fd.append('action', action);
        fd.append('nonce', nonce);
        if(payload && payload.choice){ fd.append('choice', payload.choice); }
        return fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
            .then(function(r){ return r.json(); });
    }

    function handleClick(e){
        var btn = e.target.closest('.mphvs-btn');
        if(!btn){ return; }
        var container = btn.closest('.mphvs-container');
        if(!container){ return; }
        var choice = btn.getAttribute('data-choice');
        if(!choice){ return; }
        btn.disabled = true;
        sendRequest('mphvs_vote', { choice: choice })
            .then(function(res){
                if(res && res.success && res.data){ updateUI(container, res.data); }
            })
            .catch(function(){ /* swallow */ })
            .finally(function(){ btn.disabled = false; });
    }

    function init(container){
        if(!container){ return; }
        container.addEventListener('click', handleClick);
        // Optional: refresh on load to ensure live values if cached
        sendRequest('mphvs_get', {})
            .then(function(res){ if(res && res.success && res.data){ updateUI(container, res.data); } });
    }

    function ready(fn){
        if(document.readyState === 'complete' || document.readyState === 'interactive'){
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function(){
        var containers = document.querySelectorAll('.mphvs-container');
        for(var i=0;i<containers.length;i++){
            init(containers[i]);
        }
    });
})();
