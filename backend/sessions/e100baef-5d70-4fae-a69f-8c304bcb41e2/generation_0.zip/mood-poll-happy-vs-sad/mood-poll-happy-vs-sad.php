<?php
/**
 * Plugin Name: Mood Poll (Happy vs Sad)
 * Description: Two-button mood poll with live counts, percentages, and a progress bar.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: mood-poll-happy-vs-sad
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('MPHVS_VERSION')) {
    define('MPHVS_VERSION', '1.0.0');
}

if (!defined('MPHVS_PLUGIN_FILE')) {
    define('MPHVS_PLUGIN_FILE', __FILE__);
}

require_once plugin_dir_path(__FILE__) . 'includes/class-mphvs-plugin.php';

function mphvs_run_plugin() {
    $plugin = new MPHVS_Plugin();
    $plugin->init();
}
add_action('plugins_loaded', 'mphvs_run_plugin');

function mphvs_activate_plugin() {
    if (!get_option('mphvs_counts')) {
        $defaults = array(
            'happy' => 0,
            'sad'   => 0,
        );
        add_option('mphvs_counts', $defaults);
    }
}
register_activation_hook(__FILE__, 'mphvs_activate_plugin');
