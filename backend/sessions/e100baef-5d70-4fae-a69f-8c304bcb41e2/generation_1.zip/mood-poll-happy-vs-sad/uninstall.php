<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data
delete_option('mphvs_happy');
delete_option('mphvs_sad');
