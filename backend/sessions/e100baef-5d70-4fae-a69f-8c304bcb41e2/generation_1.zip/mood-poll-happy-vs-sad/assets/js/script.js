(function(){
  if (typeof window.mphvsPoll === 'undefined') { return; }

  function qs(scope, sel){ return (scope || document).querySelector(sel); }
  function qsa(scope, sel){ return Array.prototype.slice.call((scope || document).querySelectorAll(sel)); }

  function updateUI(container, counts){
    var happy = counts.happy || 0;
    var sad = counts.sad || 0;
    var total = happy + sad;
    var happyPct = total > 0 ? Math.round((happy/total)*100) : 0;
    var sadPct = total > 0 ? Math.round((sad/total)*100) : 0;

    var happyEl = qs(container, '.mphvs-count-happy');
    var sadEl = qs(container, '.mphvs-count-sad');
    var barHappy = qs(container, '.mphvs-bar-happy');
    var barSad = qs(container, '.mphvs-bar-sad');
    var pctHappyEl = qs(container, '.mphvs-pct-happy');
    var pctSadEl = qs(container, '.mphvs-pct-sad');
    var progress = qs(container, '.mphvs-progress');

    if (happyEl) {
      happyEl.textContent = (mphvsPoll.i18n && mphvsPoll.i18n.happy_votes ? mphvsPoll.i18n.happy_votes.replace('%d', happy) : (happy + ' Happy'));
      happyEl.setAttribute('data-count-happy', String(happy));
    }
    if (sadEl) {
      sadEl.textContent = (mphvsPoll.i18n && mphvsPoll.i18n.sad_votes ? mphvsPoll.i18n.sad_votes.replace('%d', sad) : (sad + ' Sad'));
      sadEl.setAttribute('data-count-sad', String(sad));
    }
    if (barHappy) { barHappy.style.width = happyPct + '%'; }
    if (barSad) { barSad.style.width = sadPct + '%'; }
    if (pctHappyEl) { pctHappyEl.textContent = happyPct + '% ' + (mphvsPoll.i18n && mphvsPoll.i18n.happy ? mphvsPoll.i18n.happy : 'Happy'); pctHappyEl.setAttribute('data-pct-happy', String(happyPct)); }
    if (pctSadEl) { pctSadEl.textContent = sadPct + '% ' + (mphvsPoll.i18n && mphvsPoll.i18n.sad ? mphvsPoll.i18n.sad : 'Sad'); pctSadEl.setAttribute('data-pct-sad', String(sadPct)); }
    if (progress) { progress.setAttribute('aria-valuenow', String(happyPct)); }
  }

  function init(container){
    // Initialize with localized counts
    if (window.mphvsPoll && window.mphvsPoll.counts) {
      updateUI(container, window.mphvsPoll.counts);
    }

    qsa(container, '.mphvs-btn').forEach(function(btn){
      btn.addEventListener('click', function(){
        var mood = btn.getAttribute('data-mood');
        if (!mood) { return; }
        btn.setAttribute('aria-pressed', 'true');

        var formData = new FormData();
        formData.append('action', 'mphvs_vote');
        formData.append('mood', mood);
        formData.append('nonce', window.mphvsPoll.nonce || '');

        fetch(window.mphvsPoll.ajax_url, {
          method: 'POST',
          credentials: 'same-origin',
          body: formData
        })
        .then(function(resp){ return resp.json(); })
        .then(function(data){
          if (data && data.success && data.data && data.data.counts) {
            updateUI(container, data.data.counts);
            var live = qs(container, '.mphvs-stats');
            if (live && window.mphvsPoll.i18n && window.mphvsPoll.i18n.aria_updated) {
              live.setAttribute('aria-label', window.mphvsPoll.i18n.aria_updated);
            }
          }
        })
        .catch(function(){ /* silent fail */ });
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    qsa(document, '.mphvs-poll').forEach(function(container){ init(container); });
  });
})();
