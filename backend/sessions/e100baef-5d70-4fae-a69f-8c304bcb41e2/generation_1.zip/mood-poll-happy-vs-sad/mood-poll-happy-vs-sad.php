<?php
/**
 * Plugin Name: Mood Poll (Happy vs Sad)
 * Description: Two-button mood poll with live counts, percentages, and a progress bar.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: mood-poll-happy-vs-sad
 * License: GPLv2 or later
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load text domain
function mphvs_load_textdomain() {
    load_plugin_textdomain('mood-poll-happy-vs-sad', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'mphvs_load_textdomain');

// Define plugin constants
if (!defined('MPHVS_PLUGIN_FILE')) {
    define('MPHVS_PLUGIN_FILE', __FILE__);
}
if (!defined('MPHVS_PLUGIN_DIR')) {
    define('MPHVS_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('MPHVS_PLUGIN_URL')) {
    define('MPHVS_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Include main class
require_once MPHVS_PLUGIN_DIR . 'includes/class-mphvs.php';

// Activation: ensure options exist
function mphvs_activate() {
    if (false === get_option('mphvs_happy')) {
        add_option('mphvs_happy', 0, '', false);
    }
    if (false === get_option('mphvs_sad')) {
        add_option('mphvs_sad', 0, '', false);
    }
}
register_activation_hook(__FILE__, 'mphvs_activate');

// Initialize plugin
function mphvs_init_plugin() {
    \MPHVS_Poll::get_instance();
}
add_action('init', 'mphvs_init_plugin');
