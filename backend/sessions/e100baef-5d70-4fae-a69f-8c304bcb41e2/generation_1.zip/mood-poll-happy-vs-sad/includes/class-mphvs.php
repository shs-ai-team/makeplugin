<?php
/**
 * Main plugin class for Mood Poll (Happy vs Sad)
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('MPHVS_Poll')) {
    class MPHVS_Poll {
        private static $instance = null;

        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            add_shortcode('mood_poll', array($this, 'render_shortcode'));
            add_action('wp_ajax_mphvs_vote', array($this, 'handle_vote'));
            add_action('wp_ajax_nopriv_mphvs_vote', array($this, 'handle_vote'));
        }

        public function enqueue_assets() {
            $version = '1.0.0';
            wp_enqueue_style(
                'mphvs-style',
                MPHVS_PLUGIN_URL . 'assets/css/style.css',
                array(),
                $version
            );
            wp_enqueue_script(
                'mphvs-script',
                MPHVS_PLUGIN_URL . 'assets/js/script.js',
                array(),
                $version,
                true
            );

            $happy = (int) get_option('mphvs_happy', 0);
            $sad   = (int) get_option('mphvs_sad', 0);
            $total = $happy + $sad;
            $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
            $sad_pct   = $total > 0 ? round(($sad / $total) * 100) : 0;

            wp_localize_script(
                'mphvs-script',
                'mphvsPoll',
                array(
                    'ajax_url' => esc_url(admin_url('admin-ajax.php')),
                    'nonce'    => wp_create_nonce('mphvs_vote'),
                    'counts'   => array(
                        'happy' => $happy,
                        'sad'   => $sad,
                        'total' => $total,
                        'happy_pct' => $happy_pct,
                        'sad_pct'   => $sad_pct,
                    ),
                    'i18n' => array(
                        /* translators: Button text for Happy */
                        'happy' => esc_html__('Happy', 'mood-poll-happy-vs-sad'),
                        /* translators: Button text for Sad */
                        'sad'   => esc_html__('Sad', 'mood-poll-happy-vs-sad'),
                        /* translators: %d: number of votes */
                        'happy_votes' => esc_html__('%d Happy', 'mood-poll-happy-vs-sad'),
                        /* translators: %d: number of votes */
                        'sad_votes'   => esc_html__('%d Sad', 'mood-poll-happy-vs-sad'),
                        /* translators: %d: percent */
                        'percent_s'   => esc_html__('%d%%', 'mood-poll-happy-vs-sad'),
                        'aria_updated' => esc_html__('Results updated', 'mood-poll-happy-vs-sad'),
                    ),
                )
            );
        }

        public function render_shortcode($atts = array(), $content = '') {
            $this->enqueue_assets();

            $happy = (int) get_option('mphvs_happy', 0);
            $sad   = (int) get_option('mphvs_sad', 0);
            $total = $happy + $sad;
            $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
            $sad_pct   = $total > 0 ? round(($sad / $total) * 100) : 0;

            ob_start();
            ?>
            <div class="mphvs-poll" role="region" aria-label="<?php echo esc_attr__('Mood poll: Happy vs Sad', 'mood-poll-happy-vs-sad'); ?>">
                <div class="mphvs-buttons">
                    <button type="button" class="mphvs-btn mphvs-happy" data-mood="happy" aria-pressed="false">
                        <?php echo esc_html__('Happy', 'mood-poll-happy-vs-sad'); ?>
                    </button>
                    <button type="button" class="mphvs-btn mphvs-sad" data-mood="sad" aria-pressed="false">
                        <?php echo esc_html__('Sad', 'mood-poll-happy-vs-sad'); ?>
                    </button>
                </div>
                <div class="mphvs-stats" aria-live="polite">
                    <div class="mphvs-counts">
                        <span class="mphvs-count mphvs-count-happy" data-count-happy="<?php echo esc_attr((string) $happy); ?>">
                            <?php
                            /* translators: %d: number of Happy votes */
                            echo esc_html(sprintf(esc_html__('%d Happy', 'mood-poll-happy-vs-sad'), $happy));
                            ?>
                        </span>
                        <span class="mphvs-count mphvs-count-sad" data-count-sad="<?php echo esc_attr((string) $sad); ?>">
                            <?php
                            /* translators: %d: number of Sad votes */
                            echo esc_html(sprintf(esc_html__('%d Sad', 'mood-poll-happy-vs-sad'), $sad));
                            ?>
                        </span>
                    </div>
                    <div class="mphvs-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr((string) $happy_pct); ?>" aria-label="<?php echo esc_attr__('Happy percentage', 'mood-poll-happy-vs-sad'); ?>">
                        <span class="mphvs-bar mphvs-bar-happy" style="width: <?php echo esc_attr((string) $happy_pct); ?>%"></span>
                        <span class="mphvs-bar mphvs-bar-sad" style="width: <?php echo esc_attr((string) $sad_pct); ?>%"></span>
                    </div>
                    <div class="mphvs-percents">
                        <span class="mphvs-pct mphvs-pct-happy" data-pct-happy="<?php echo esc_attr((string) $happy_pct); ?>">
                            <?php
                            /* translators: %d: Happy percent */
                            echo esc_html(sprintf(esc_html__('%d%% Happy', 'mood-poll-happy-vs-sad'), $happy_pct));
                            ?>
                        </span>
                        <span class="mphvs-pct mphvs-pct-sad" data-pct-sad="<?php echo esc_attr((string) $sad_pct); ?>">
                            <?php
                            /* translators: %d: Sad percent */
                            echo esc_html(sprintf(esc_html__('%d%% Sad', 'mood-poll-happy-vs-sad'), $sad_pct));
                            ?>
                        </span>
                    </div>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return wp_kses_post($html);
        }

        public function handle_vote() {
            check_ajax_referer('mphvs_vote', 'nonce');

            $mood = isset($_POST['mood']) ? sanitize_key(wp_unslash($_POST['mood'])) : '';
            if (!in_array($mood, array('happy', 'sad'), true)) {
                wp_send_json_error(array(
                    'message' => esc_html__('Invalid mood.', 'mood-poll-happy-vs-sad'),
                ));
            }

            if ('happy' === $mood) {
                $happy = (int) get_option('mphvs_happy', 0);
                $happy++;
                update_option('mphvs_happy', $happy, false);
            } else {
                $sad = (int) get_option('mphvs_sad', 0);
                $sad++;
                update_option('mphvs_sad', $sad, false);
            }

            $happy = (int) get_option('mphvs_happy', 0);
            $sad   = (int) get_option('mphvs_sad', 0);
            $total = $happy + $sad;
            $happy_pct = $total > 0 ? round(($happy / $total) * 100) : 0;
            $sad_pct   = $total > 0 ? round(($sad / $total) * 100) : 0;

            wp_send_json_success(array(
                'counts' => array(
                    'happy' => $happy,
                    'sad'   => $sad,
                    'total' => $total,
                    'happy_pct' => $happy_pct,
                    'sad_pct'   => $sad_pct,
                ),
                'message' => esc_html__('Vote recorded.', 'mood-poll-happy-vs-sad'),
            ));
        }
    }
}
