=== Mood Poll (Happy vs Sad) ===
Contributors: makeplugin
Tags: poll, feedback, votes, mood, simple, ajax, progress bar, happy, sad, lightweight, responsive, accessibility
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Two-button mood poll with live counts, percentages, and a progress bar.

== Description ==
Provide a lightweight mood poll with two buttons: Happy (light green) and Sad (light red). Anyone can click repeatedly; each click increments the global counts. Always show stats: total votes for Happy and Sad, percentage breakdown for each, and a horizontal progress bar visualizing proportions (green vs red). Styled with a light brown background, a light theme, and a compact layout that is not overly wide; visual elements are comfortably thick, including a clearly thicker progress bar. Counts persist across visits, it’s responsive and accessible, and site owners can place the poll where needed using the shortcode.

== Usage ==
- Add the shortcode [mood_poll] to any post, page, or widget to display the poll.

== Features ==
- Two-button poll: Happy and Sad
- Live AJAX updates after each click
- Global counts persist as WordPress options
- Percentages with a thick, colorful progress bar
- Responsive, accessible markup with aria attributes
- Lightweight CSS and vanilla JS

== Installation ==
1. Upload the plugin folder to /wp-content/plugins/.
2. Activate the plugin through the Plugins screen in WordPress.
3. Place the shortcode [mood_poll] where you want the poll to appear.

== Changelog ==
= 1.0.0 =
* Initial release.

== Frequently Asked Questions ==
= Can visitors vote multiple times? =
Yes. Each click increments the global counts.

= How do I display the poll? =
Use the shortcode [mood_poll].
