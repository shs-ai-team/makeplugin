<?php
/**
 * Plugin Name: Four Quadrant Clicker
 * Description: 4-color global click counter with live stats
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: four-quadrant-clicker
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Autoload or manual include
require_once plugin_dir_path(__FILE__) . 'includes/class-four-quadrant-clicker.php';

/**
 * Bootstrap the plugin.
 */
function four_quadrant_clicker_bootstrap() {
    $instance = \Four_Quadrant_Clicker::get_instance();
    $instance->init();
}
add_action('plugins_loaded', 'four_quadrant_clicker_bootstrap');
