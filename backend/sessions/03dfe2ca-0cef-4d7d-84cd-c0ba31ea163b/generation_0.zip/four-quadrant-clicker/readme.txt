=== Four Quadrant Clicker ===
Contributors: makeplugin
Tags: clicker, counter, fun, interactive, game, colors, shortcode, stats
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

4-color global click counter with live stats.

== Description ==
Build a fun, poppy 4-quadrant clicker (equal squares) with distinct vibrant colors. A click on any quadrant increases that quadrant’s global count instantly. Below the grid, show live stats: each quadrant’s count, total clicks, and each quadrant’s percentage, color-matched. Counts persist globally across visitors and sessions. No names/labels needed—just color-coded quadrants. Includes a light debounce to avoid accidental double-clicks, smooth micro-animations on click, and a clean, responsive layout that works well on mobile and desktop. Accessible via mouse, touch, and keyboard. Add it to any page via the shortcode: [four_quadrant_clicker]. No per-user tracking, no money, and no admin settings.

== Installation ==
1. Upload the plugin folder to the /wp-content/plugins/ directory or install via the Plugins screen in WordPress.
2. Activate the plugin through the Plugins screen.
3. Add the shortcode [four_quadrant_clicker] to any page or post.

== Frequently Asked Questions ==
= How do I display the clicker? =
Use the shortcode [four_quadrant_clicker] in any post or page.

= Does it track users? =
No. It stores only global counts with no personal data.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
