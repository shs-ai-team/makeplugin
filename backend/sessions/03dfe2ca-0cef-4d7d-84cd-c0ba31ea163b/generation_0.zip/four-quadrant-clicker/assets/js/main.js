(function(){
  'use strict';

  function debounce(fn, wait){
    var t; return function(){
      var ctx=this, args=arguments; clearTimeout(t);
      t=setTimeout(function(){ fn.apply(ctx,args); }, wait);
    };
  }

  function $(sel, ctx){ return (ctx||document).querySelector(sel); }
  function $all(sel, ctx){ return (ctx||document).querySelectorAll(sel); }

  function updateStats(root, data){
    if(!root || !data) return;
    var counts = data.counts || {};
    var total = typeof data.total === 'number' ? data.total : (counts.q1+counts.q2+counts.q3+counts.q4);
    var percent = data.percent || {
      q1: total>0? +( (counts.q1/total)*100 ).toFixed(1):0,
      q2: total>0? +( (counts.q2/total)*100 ).toFixed(1):0,
      q3: total>0? +( (counts.q3/total)*100 ).toFixed(1):0,
      q4: total>0? +( (counts.q4/total)*100 ).toFixed(1):0
    };

    ['q1','q2','q3','q4'].forEach(function(k){
      var c = root.querySelector('[data-count="'+k+'"]');
      var p = root.querySelector('[data-percent="'+k+'"]');
      if(c){ c.textContent = String(counts[k]||0); }
      if(p){ p.textContent = String(percent[k]||0) + '%'; }
    });
    var totalEl = root.querySelector('[data-total]');
    if(totalEl){ totalEl.textContent = String(total||0); }
  }

  function bind(root){
    if(!root) return;
    var grid = root.querySelector('.fqc-grid');
    var cells = $all('.fqc-cell', root);
    var busy = false;

    function sendClick(quadrant){
      if(busy) return; // extra protection
      busy = true;
      var form = new FormData();
      form.append('action', 'fqc_click');
      form.append('nonce', (window.FQC_DATA && FQC_DATA.nonce) || '');
      form.append('quadrant', quadrant);

      fetch((window.FQC_DATA && FQC_DATA.ajaxUrl) || '', {
        method: 'POST',
        credentials: 'same-origin',
        body: form
      }).then(function(res){ return res.json(); })
      .then(function(json){
        if(json && json.success){
          updateStats(root, json.data);
        }
      }).catch(function(){ /* swallow errors silently */ })
      .finally(function(){ busy = false; });
    }

    var debouncedSend = debounce(sendClick, (window.FQC_DATA && FQC_DATA.debounceMs) || 250);

    cells.forEach(function(btn){
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var q = btn.getAttribute('data-quadrant');
        btn.classList.add('fqc-pressed');
        setTimeout(function(){ btn.classList.remove('fqc-pressed'); }, 180);
        debouncedSend(q);
      });
      btn.addEventListener('keydown', function(e){
        if(e.key === 'Enter' || e.key === ' '){
          e.preventDefault();
          btn.click();
        }
      });
      // Touch ripple-like micro animation via quick class toggle handled in click
    });

    // Initialize UI with localized counts
    if(window.FQC_DATA && FQC_DATA.counts){
      var c = FQC_DATA.counts; var t = (c.q1||0)+(c.q2||0)+(c.q3||0)+(c.q4||0);
      updateStats(root, { counts: c, total: t });
    }
  }

  document.addEventListener('DOMContentLoaded', function(){
    var root = document.querySelector('[data-fqc]');
    if(root){ bind(root); }
  });
})();
