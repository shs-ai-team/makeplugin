<?php
if (!defined('ABSPATH')) {
    exit;
}
// Expected: $fqc_counts (int array), $fqc_palette (hex color array)
$total = (int) $fqc_counts['q1'] + (int) $fqc_counts['q2'] + (int) $fqc_counts['q3'] + (int) $fqc_counts['q4'];
$perc = array(
    'q1' => $total > 0 ? round(((int) $fqc_counts['q1'] / $total) * 100, 1) : 0,
    'q2' => $total > 0 ? round(((int) $fqc_counts['q2'] / $total) * 100, 1) : 0,
    'q3' => $total > 0 ? round(((int) $fqc_counts['q3'] / $total) * 100, 1) : 0,
    'q4' => $total > 0 ? round(((int) $fqc_counts['q4'] / $total) * 100, 1) : 0,
);
?>
<div class="fqc" data-fqc>
    <div class="fqc-grid" role="group" aria-label="<?php echo esc_attr(esc_html__('Four quadrant clicker', 'four-quadrant-clicker')); ?>">
        <button class="fqc-cell fqc-q1" data-quadrant="q1" style="--fqc-color: <?php echo esc_attr($fqc_palette['q1']); ?>" aria-label="<?php /* translators: %s: quadrant number (1-4) */ printf(esc_attr__('Quadrant %s', 'four-quadrant-clicker'), '1'); ?>"></button>
        <button class="fqc-cell fqc-q2" data-quadrant="q2" style="--fqc-color: <?php echo esc_attr($fqc_palette['q2']); ?>" aria-label="<?php /* translators: %s: quadrant number (1-4) */ printf(esc_attr__('Quadrant %s', 'four-quadrant-clicker'), '2'); ?>"></button>
        <button class="fqc-cell fqc-q3" data-quadrant="q3" style="--fqc-color: <?php echo esc_attr($fqc_palette['q3']); ?>" aria-label="<?php /* translators: %s: quadrant number (1-4) */ printf(esc_attr__('Quadrant %s', 'four-quadrant-clicker'), '3'); ?>"></button>
        <button class="fqc-cell fqc-q4" data-quadrant="q4" style="--fqc-color: <?php echo esc_attr($fqc_palette['q4']); ?>" aria-label="<?php /* translators: %s: quadrant number (1-4) */ printf(esc_attr__('Quadrant %s', 'four-quadrant-clicker'), '4'); ?>"></button>
    </div>
    <div class="fqc-stats" aria-live="polite">
        <div class="fqc-stat">
            <span class="fqc-dot" style="--fqc-color: <?php echo esc_attr($fqc_palette['q1']); ?>" aria-hidden="true"></span>
            <span class="screen-reader-text"><?php echo esc_html__('Quadrant 1', 'four-quadrant-clicker'); ?>:</span>
            <span class="fqc-count" data-count="q1"><?php echo esc_html((string) (int) $fqc_counts['q1']); ?></span>
            <span class="fqc-percent" data-percent="q1"><?php echo esc_html((string) $perc['q1']); ?>%</span>
        </div>
        <div class="fqc-stat">
            <span class="fqc-dot" style="--fqc-color: <?php echo esc_attr($fqc_palette['q2']); ?>" aria-hidden="true"></span>
            <span class="screen-reader-text"><?php echo esc_html__('Quadrant 2', 'four-quadrant-clicker'); ?>:</span>
            <span class="fqc-count" data-count="q2"><?php echo esc_html((string) (int) $fqc_counts['q2']); ?></span>
            <span class="fqc-percent" data-percent="q2"><?php echo esc_html((string) $perc['q2']); ?>%</span>
        </div>
        <div class="fqc-stat">
            <span class="fqc-dot" style="--fqc-color: <?php echo esc_attr($fqc_palette['q3']); ?>" aria-hidden="true"></span>
            <span class="screen-reader-text"><?php echo esc_html__('Quadrant 3', 'four-quadrant-clicker'); ?>:</span>
            <span class="fqc-count" data-count="q3"><?php echo esc_html((string) (int) $fqc_counts['q3']); ?></span>
            <span class="fqc-percent" data-percent="q3"><?php echo esc_html((string) $perc['q3']); ?>%</span>
        </div>
        <div class="fqc-stat">
            <span class="fqc-dot" style="--fqc-color: <?php echo esc_attr($fqc_palette['q4']); ?>" aria-hidden="true"></span>
            <span class="screen-reader-text"><?php echo esc_html__('Quadrant 4', 'four-quadrant-clicker'); ?>:</span>
            <span class="fqc-count" data-count="q4"><?php echo esc_html((string) (int) $fqc_counts['q4']); ?></span>
            <span class="fqc-percent" data-percent="q4"><?php echo esc_html((string) $perc['q4']); ?>%</span>
        </div>
        <div class="fqc-total">
            <span class="fqc-total-label screen-reader-text"><?php echo esc_html__('Total clicks', 'four-quadrant-clicker'); ?>:</span>
            <span class="fqc-total-value" data-total><?php echo esc_html((string) $total); ?></span>
        </div>
    </div>
</div>
