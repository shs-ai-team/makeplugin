<?php
/**
 * Main plugin class for Four Quadrant Clicker
 *
 * @package Four_Quadrant_Clicker
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Four_Quadrant_Clicker')) {
    class Four_Quadrant_Clicker {
        /**
         * Singleton instance
         *
         * @var Four_Quadrant_Clicker|null
         */
        private static $instance = null;

        /**
         * Option name for storing counts
         *
         * @var string
         */
        private $option_name = 'fqc_counts';

        /**
         * Colors palette
         *
         * @var array
         */
        private $palette = array(
            // Keys reference logical quadrants; values are hex colors.
            'q1' => '#ff4d4f', // Vibrant Red
            'q2' => '#2f54eb', // Royal Blue
            'q3' => '#36cfc9', // Teal/Aqua
            'q4' => '#fadb14', // Gold Yellow
        );

        /**
         * Get singleton instance.
         *
         * @return Four_Quadrant_Clicker
         */
        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Initialize hooks.
         */
        public function init() {
            // Ensure counts option exists.
            $this->ensure_counts_exist();

            // Register shortcode.
            add_shortcode('four_quadrant_clicker', array($this, 'render_shortcode'));

            // Register assets.
            add_action('wp_enqueue_scripts', array($this, 'register_assets'));

            // AJAX endpoints for both logged-in and guests.
            add_action('wp_ajax_fqc_click', array($this, 'handle_click'));
            add_action('wp_ajax_nopriv_fqc_click', array($this, 'handle_click'));
        }

        /**
         * Ensure the counts option exists with initial zero values.
         */
        private function ensure_counts_exist() {
            $counts = get_option($this->option_name);
            if (!is_array($counts)) {
                $counts = array(
                    'q1' => 0,
                    'q2' => 0,
                    'q3' => 0,
                    'q4' => 0,
                );
                add_option($this->option_name, $counts, '', true);
            } else {
                // Normalize keys if needed.
                $defaults = array('q1' => 0, 'q2' => 0, 'q3' => 0, 'q4' => 0);
                $counts = wp_parse_args($counts, $defaults);
                update_option($this->option_name, $counts, true);
            }
        }

        /**
         * Register styles and scripts (enqueued on demand in shortcode).
         */
        public function register_assets() {
            $ver = '1.0.0';
            $base = plugin_dir_url(dirname(__FILE__));

            wp_register_style(
                'four-quadrant-clicker-style',
                $base . 'assets/css/style.css',
                array(),
                $ver
            );

            wp_register_script(
                'four-quadrant-clicker-script',
                $base . 'assets/js/main.js',
                array('wp-i18n'),
                $ver,
                true
            );
        }

        /**
         * Shortcode renderer.
         *
         * @return string
         */
        public function render_shortcode() {
            // Enqueue assets only when shortcode is used.
            wp_enqueue_style('four-quadrant-clicker-style');
            wp_enqueue_script('four-quadrant-clicker-script');

            $counts = get_option($this->option_name);
            if (!is_array($counts)) {
                $counts = array('q1' => 0, 'q2' => 0, 'q3' => 0, 'q4' => 0);
            }

            // Localize script with dynamic data.
            $localized = array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('fqc_nonce'),
                'counts'  => array(
                    'q1' => (int) $counts['q1'],
                    'q2' => (int) $counts['q2'],
                    'q3' => (int) $counts['q3'],
                    'q4' => (int) $counts['q4'],
                ),
                'palette' => $this->palette,
                'i18n'    => array(
                    /* translators: %s: quadrant number (1-4) */
                    'quadrantLabel' => esc_html__('Quadrant %s', 'four-quadrant-clicker'),
                    'totalLabel'    => esc_html__('Total clicks', 'four-quadrant-clicker'),
                    'countLabel'    => esc_html__('Count', 'four-quadrant-clicker'),
                    'percentLabel'  => esc_html__('Percent', 'four-quadrant-clicker'),
                ),
                'debounceMs' => 250,
            );
            wp_localize_script('four-quadrant-clicker-script', 'FQC_DATA', $localized);

            // Capture template output safely.
            ob_start();
            $palette = $this->palette; // local var for template
            $safe_counts = array(
                'q1' => isset($counts['q1']) ? (int) $counts['q1'] : 0,
                'q2' => isset($counts['q2']) ? (int) $counts['q2'] : 0,
                'q3' => isset($counts['q3']) ? (int) $counts['q3'] : 0,
                'q4' => isset($counts['q4']) ? (int) $counts['q4'] : 0,
            );
            $template_path = plugin_dir_path(dirname(__FILE__)) . 'templates/render.php';
            if (file_exists($template_path)) {
                // Provide variables to template scope
                $fqc_counts = $safe_counts; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.VariableConstantNameFound
                $fqc_palette = $palette;    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.VariableConstantNameFound
                include $template_path;
            }
            $html = ob_get_clean();

            return wp_kses_post($html);
        }

        /**
         * Handle a click increment via AJAX.
         */
        public function handle_click() {
            // Validate nonce
            $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
            if (!wp_verify_nonce($nonce, 'fqc_nonce')) {
                wp_send_json_error(array(
                    'message' => esc_html__('Security check failed.', 'four-quadrant-clicker'),
                ), 403);
            }

            // Sanitize quadrant key
            $quadrant = isset($_POST['quadrant']) ? sanitize_text_field(wp_unslash($_POST['quadrant'])) : '';
            $allowed = array('q1', 'q2', 'q3', 'q4');
            if (!in_array($quadrant, $allowed, true)) {
                wp_send_json_error(array(
                    'message' => esc_html__('Invalid quadrant.', 'four-quadrant-clicker'),
                ), 400);
            }

            // Get and update counts atomically as possible
            $counts = get_option($this->option_name);
            if (!is_array($counts)) {
                $counts = array('q1' => 0, 'q2' => 0, 'q3' => 0, 'q4' => 0);
            }

            $counts[$quadrant] = isset($counts[$quadrant]) ? (int) $counts[$quadrant] + 1 : 1;
            update_option($this->option_name, $counts, true);

            // Prepare response with totals and percentages
            $total = (int) $counts['q1'] + (int) $counts['q2'] + (int) $counts['q3'] + (int) $counts['q4'];
            $perc = array(
                'q1' => $total > 0 ? round(((int) $counts['q1'] / $total) * 100, 1) : 0,
                'q2' => $total > 0 ? round(((int) $counts['q2'] / $total) * 100, 1) : 0,
                'q3' => $total > 0 ? round(((int) $counts['q3'] / $total) * 100, 1) : 0,
                'q4' => $total > 0 ? round(((int) $counts['q4'] / $total) * 100, 1) : 0,
            );

            wp_send_json_success(array(
                'counts' => array(
                    'q1' => (int) $counts['q1'],
                    'q2' => (int) $counts['q2'],
                    'q3' => (int) $counts['q3'],
                    'q4' => (int) $counts['q4'],
                ),
                'total' => (int) $total,
                'percent' => $perc,
            ));
        }
    }
}
