<?php
/**
 * Frontend features for Social Share Buttons.
 */

if (!defined('ABSPATH')) {
    exit;
}

class SSB_Frontend {
    /**
     * Register hooks for content filter and shortcode.
     */
    public function register_hooks() {
        add_filter('the_content', array($this, 'append_buttons_to_content'));
        add_shortcode('social_share', array($this, 'shortcode_output'));
    }

    /**
     * Append share buttons to single post content.
     *
     * @param string $content The post content.
     * @return string Filtered content.
     */
    public function append_buttons_to_content($content) {
        if (!is_singular('post')) {
            return $content;
        }

        if (!in_the_loop() || !is_main_query()) {
            return $content;
        }

        $buttons = $this->get_buttons_markup();
        if (!empty($buttons)) {
            $content .= $buttons; // $buttons is already escaped via wp_kses_post in get_buttons_markup().
        }

        return $content;
    }

    /**
     * Shortcode callback to render share buttons.
     *
     * @return string Markup for buttons.
     */
    public function shortcode_output() {
        return $this->get_buttons_markup();
    }

    /**
     * Build the buttons markup.
     *
     * @return string Safe HTML.
     */
    private function get_buttons_markup() {
        $data = $this->get_share_data();
        $url   = $data['url'];
        $title = $data['title'];

        $fb_share = add_query_arg(
            array(
                'u' => rawurlencode($url),
            ),
            'https://www.facebook.com/sharer/sharer.php'
        );

        $x_share = add_query_arg(
            array(
                'url'  => rawurlencode($url),
                'text' => rawurlencode($title),
            ),
            'https://twitter.com/intent/tweet'
        );

        $li_share = add_query_arg(
            array(
                'url' => rawurlencode($url),
            ),
            'https://www.linkedin.com/sharing/share-offsite/'
        );

        /* translators: 1: Social network name, 2: Post title */
        $label_fb = sprintf(esc_html__('%1$s: Share "%2$s"', 'social-share-buttons'), 'Facebook', $title);
        /* translators: 1: Social network name, 2: Post title */
        $label_x  = sprintf(esc_html__('%1$s: Share "%2$s"', 'social-share-buttons'), 'X', $title);
        /* translators: 1: Social network name, 2: Post title */
        $label_li = sprintf(esc_html__('%1$s: Share "%2$s"', 'social-share-buttons'), 'LinkedIn', $title);

        $html  = '<div class="ssb-container" role="group" aria-label="' . esc_attr__('Share buttons', 'social-share-buttons') . '">';
        $html .= '<ul class="ssb-buttons">';
        $html .= '<li class="ssb-item ssb-facebook">'
              . '<a class="ssb-link" href="' . esc_url($fb_share) . '" target="_blank" rel="noopener nofollow" aria-label="' . esc_attr($label_fb) . '">' 
              . '<span class="ssb-text">' . esc_html__('Share on Facebook', 'social-share-buttons') . '</span>'
              . '</a>'
              . '</li>';

        $html .= '<li class="ssb-item ssb-x">'
              . '<a class="ssb-link" href="' . esc_url($x_share) . '" target="_blank" rel="noopener nofollow" aria-label="' . esc_attr($label_x) . '">' 
              . '<span class="ssb-text">' . esc_html__('Share on X', 'social-share-buttons') . '</span>'
              . '</a>'
              . '</li>';

        $html .= '<li class="ssb-item ssb-linkedin">'
              . '<a class="ssb-link" href="' . esc_url($li_share) . '" target="_blank" rel="noopener nofollow" aria-label="' . esc_attr($label_li) . '">' 
              . '<span class="ssb-text">' . esc_html__('Share on LinkedIn', 'social-share-buttons') . '</span>'
              . '</a>'
              . '</li>';

        $html .= '</ul>';
        $html .= '</div>';

        return wp_kses_post($html);
    }

    /**
     * Get share data (URL and title) for current context.
     *
     * @return array{url:string,title:string}
     */
    private function get_share_data() {
        $post_id = 0;
        if (is_singular() && get_queried_object_id()) {
            $post_id = (int) get_queried_object_id();
        } elseif (is_admin()) {
            $post_id = 0;
        }

        if ($post_id > 0) {
            $url   = get_permalink($post_id);
            $title = get_the_title($post_id);
        } else {
            $url   = home_url('/');
            $blogname = get_bloginfo('name');
            $title = is_string($blogname) ? $blogname : '';
        }

        $url   = is_string($url) ? $url : home_url('/');
        $title = is_string($title) ? $title : '';

        // Ensure plain text title for attributes.
        $title = wp_strip_all_tags($title);

        return array(
            'url'   => $url,
            'title' => $title,
        );
    }
}
