<?php
/**
 * Uninstall handler for Social Share Buttons.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// No options or custom tables to remove. This plugin stores no data.
