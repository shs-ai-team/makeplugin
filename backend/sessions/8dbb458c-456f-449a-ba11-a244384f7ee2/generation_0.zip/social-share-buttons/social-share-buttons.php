<?php
/**
 * Plugin Name: Social Share Buttons
 * Description: Adds Facebook, X, and LinkedIn share buttons at the end of posts and via a [social_share] tag.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: social-share-buttons
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('SSB_PLUGIN_VERSION')) {
    define('SSB_PLUGIN_VERSION', '1.0.0');
}

if (!defined('SSB_PLUGIN_DIR')) {
    define('SSB_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('SSB_PLUGIN_URL')) {
    define('SSB_PLUGIN_URL', plugin_dir_url(__FILE__));
}

/**
 * Load plugin textdomain for translations.
 */
function ssb_load_textdomain() {
    load_plugin_textdomain('social-share-buttons', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'ssb_load_textdomain');

/**
 * Enqueue frontend styles.
 */
function ssb_enqueue_assets() {
    wp_enqueue_style(
        'ssb-style',
        SSB_PLUGIN_URL . 'assets/style.css',
        array(),
        SSB_PLUGIN_VERSION
    );
}
add_action('wp_enqueue_scripts', 'ssb_enqueue_assets');

// Include frontend class.
require_once SSB_PLUGIN_DIR . 'includes/class-ssb-frontend.php';

/**
 * Initialize frontend features.
 */
function ssb_init_frontend() {
    $frontend = new SSB_Frontend();
    $frontend->register_hooks();
}
add_action('init', 'ssb_init_frontend');
