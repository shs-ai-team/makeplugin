=== Social Share Buttons ===
Contributors: makeplugin
Tags: sharing, social, facebook, twitter, x, linkedin, buttons
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Adds Facebook, X, and LinkedIn share buttons at the end of posts and via a [social_share] tag.

== Description ==
This lightweight plugin automatically appends share buttons for Facebook, X (Twitter), and LinkedIn to the end of single blog posts. It also provides a [social_share] shortcode that renders the same buttons wherever it’s placed. Buttons share the current page’s URL and title, open in a new tab, and include accessible labels. Styling is minimal, horizontal, and theme-friendly. No settings, no tracking — just simple social sharing.

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/social-share-buttons directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the \"Plugins\" screen in WordPress.

== Frequently Asked Questions ==
= How do I display the buttons manually? =
Use the shortcode: [social_share]

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
