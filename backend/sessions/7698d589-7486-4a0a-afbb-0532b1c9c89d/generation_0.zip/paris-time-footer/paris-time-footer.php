<?php
/**
 * Plugin Name: Paris Time Footer
 * Description: Show current Paris time in the homepage footer.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: paris-time-footer
 * License: GPLv2 or later
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('PTF_VERSION')) {
    define('PTF_VERSION', '1.0.0');
}

/**
 * Load plugin textdomain for translations.
 */
function ptf_load_textdomain() {
    load_plugin_textdomain('paris-time-footer', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'ptf_load_textdomain');

/**
 * Enqueue frontend assets only on the site homepage (front page).
 */
function ptf_enqueue_assets() {
    if (!is_front_page()) {
        return;
    }

    $handle = 'paris-time-footer';
    $src    = plugin_dir_url(__FILE__) . 'assets/js/paris-time-footer.js';

    wp_enqueue_script(
        $handle,
        $src,
        array(),
        PTF_VERSION,
        true
    );

    $label = esc_html__( 'Paris time:', 'paris-time-footer' );

    wp_localize_script(
        $handle,
        'parisTimeFooterL10n',
        array(
            'label'    => $label,
            'timeZone' => 'Europe/Paris',
            'containerId' => 'ptf-container'
        )
    );
}
add_action('wp_enqueue_scripts', 'ptf_enqueue_assets');

/**
 * Output the footer container for the Paris time display on the homepage only.
 */
function ptf_render_footer_time_container() {
    if (!is_front_page()) {
        return;
    }

    // Container where JS will render the time. Keep minimal to inherit theme styles.
    echo '<div id="' . esc_attr('ptf-container') . '" class="' . esc_attr('ptf-container') . '" aria-live="polite"></div>';
}
add_action('wp_footer', 'ptf_render_footer_time_container', 100);
