(function(){
    if (typeof window === 'undefined') { return; }

    function getEl(id){ return document.getElementById(id); }

    function formatParisTime() {
        try {
            var now = new Date();
            var fmt = new Intl.DateTimeFormat(undefined, {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false,
                timeZone: (window.parisTimeFooterL10n && window.parisTimeFooterL10n.timeZone) ? window.parisTimeFooterL10n.timeZone : 'Europe/Paris'
            });
            return fmt.format(now);
        } catch (e) {
            // Fallback to local time if Intl or timezone unsupported
            var d = new Date();
            var hh = String(d.getHours()).padStart(2, '0');
            var mm = String(d.getMinutes()).padStart(2, '0');
            return hh + ':' + mm;
        }
    }

    function render() {
        var l10n = window.parisTimeFooterL10n || {};
        var label = (typeof l10n.label === 'string') ? l10n.label : 'Paris time:';
        var containerId = (typeof l10n.containerId === 'string') ? l10n.containerId : 'ptf-container';
        var el = getEl(containerId);
        if (!el) { return; }
        var time = formatParisTime();
        el.textContent = label + ' ' + time;
    }

    function start() {
        render();
        // Update roughly once per minute
        setInterval(render, 60000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();
