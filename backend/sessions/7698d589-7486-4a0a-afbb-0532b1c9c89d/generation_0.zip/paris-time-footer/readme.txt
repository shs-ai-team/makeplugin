=== Paris Time Footer ===
Contributors: makeplugin
Tags: time, footer, timezone, paris, europe, homepage
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Show current Paris time in the homepage footer.

== Description ==
Adds a small text line at the bottom of the homepage footer displaying the current time in Paris, labeled as "Paris time:" followed by the time in 24-hour format (HH:mm). The time adjusts for daylight savings (Europe/Paris) and updates in real time about once per minute without reloading. No settings screen is included; styling is minimal and inherits theme styles. The display is strictly limited to the site’s homepage and uses the browser to render the live time without external services.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/paris-time-footer` directory or install through the Plugins screen in WordPress.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Visit your site homepage to see the Paris time in the footer.

== Changelog ==
= 1.0.0 =
* Initial release.

== Frequently Asked Questions ==
= Does it work on every page? =
No, it only displays on the site homepage (front page).

= Does it use external services? =
No. It uses the browser’s built-in Internationalization API to render the time in the Europe/Paris timezone.
