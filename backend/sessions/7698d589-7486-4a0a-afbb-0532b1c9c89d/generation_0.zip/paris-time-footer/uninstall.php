<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// No options or custom tables to clean up for this plugin.
// This file exists to comply with WordPress plugin standards.
