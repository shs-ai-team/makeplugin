<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Calendar renderer class.
 */
class TMC_Calendar {
    /**
     * Render current month calendar with today highlighted.
     *
     * @return string HTML markup.
     */
    public static function render_calendar() {
        // Get current timestamp based on site timezone.
        $now              = current_time( 'timestamp' );
        $start_of_week    = (int) get_option( 'start_of_week', 0 ); // 0 = Sunday.
        $year             = (int) wp_date( 'Y', $now );
        $month            = (int) wp_date( 'n', $now ); // 1-12
        $today_day        = (int) wp_date( 'j', $now ); // 1-31

        // First day of the month timestamp.
        $first_of_month_ts = gmmktime( 0, 0, 0, $month, 1, $year );
        // Adjust to site timezone by using strtotime on formatted date in site tz.
        $first_of_month_ts = strtotime( wp_date( 'Y-m-01 00:00:00', $now ) );

        // Last day number of the month.
        $days_in_month = (int) wp_date( 't', $first_of_month_ts );

        // Determine the weekday index (0=Sunday...6=Saturday) for first day.
        $first_wday = (int) wp_date( 'w', $first_of_month_ts );

        // Calculate leading empty cells according to start_of_week.
        $leading_empty = ( $first_wday - $start_of_week );
        if ( $leading_empty < 0 ) {
            $leading_empty += 7;
        }

        // Build localized weekday headers starting at start_of_week.
        $weekday_headers = array();
        for ( $i = 0; $i < 7; $i++ ) {
            $w = ( $start_of_week + $i ) % 7; // 0..6
            // Create a date for each weekday to fetch localized short names.
            $weekday_headers[] = array(
                'short' => wp_date( 'D', strtotime( 'next Sunday +' . $w . ' day', 0 ) ),
                'full'  => wp_date( 'l', strtotime( 'next Sunday +' . $w . ' day', 0 ) ),
            );
        }

        // Localized month name and year for caption.
        /* translators: %1$s: month name, %2$s: 4-digit year */
        $caption_text = sprintf( esc_html__( '%1$s %2$s', 'todays-month-calendar' ), wp_date( 'F', $first_of_month_ts ), wp_date( 'Y', $first_of_month_ts ) );

        // Start building table HTML.
        $html  = '';
        $html .= '<div class="tmc-calendar-wrapper" role="region" aria-label="' . esc_attr( $caption_text ) . '">';
        $html .= '<table class="tmc-calendar" role="grid">';
        $html .= '<caption class="tmc-calendar__caption">' . esc_html( $caption_text ) . '</caption>';
        $html .= '<thead><tr role="row">';
        foreach ( $weekday_headers as $wh ) {
            $html .= '<th role="columnheader" scope="col" aria-label="' . esc_attr( $wh['full'] ) . '"><span aria-hidden="true">' . esc_html( $wh['short'] ) . '</span></th>';
        }
        $html .= '</tr></thead>';
        $html .= '<tbody>';

        $day = 1;
        $cell = 0;
        // Generate up to 6 weeks rows.
        for ( $row = 0; $row < 6; $row++ ) {
            $html .= '<tr role="row">';
            for ( $col = 0; $col < 7; $col++ ) {
                $is_empty = ( $cell < $leading_empty ) || ( $day > $days_in_month );
                if ( $is_empty ) {
                    $html .= '<td role="gridcell" class="tmc-calendar__day tmc-calendar__day--empty" aria-disabled="true">&nbsp;</td>';
                } else {
                    // Compute whether this cell is today.
                    $is_today = ( $day === $today_day );
                    $classes  = 'tmc-calendar__day';
                    $aria     = '';
                    if ( $is_today ) {
                        $classes .= ' tmc-calendar__day--today';
                        /* translators: %s: localized date */
                        $aria = ' aria-current="date" aria-label="' . esc_attr( sprintf( __( 'Today: %s', 'todays-month-calendar' ), wp_date( 'F j, Y', strtotime( wp_date( 'Y-m-', $first_of_month_ts ) . $day . ' 00:00:00' ) ) ) ) . '"';
                    }
                    $html .= '<td role="gridcell" class="' . esc_attr( $classes ) . '"' . $aria . '><span class="tmc-calendar__date" aria-hidden="false">' . esc_html( (string) $day ) . '</span></td>';
                    $day++;
                }
                $cell++;
            }
            $html .= '</tr>';
            // Stop if we filled all days.
            if ( $day > $days_in_month ) {
                break;
            }
        }

        $html .= '</tbody>';
        $html .= '</table>';
        $html .= '</div>';

        return $html;
    }
}
