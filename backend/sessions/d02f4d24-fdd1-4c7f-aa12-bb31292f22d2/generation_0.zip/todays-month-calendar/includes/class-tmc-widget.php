<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Widget to display today's month calendar.
 */
class TMC_Widget extends WP_Widget {
    /**
     * Sets up the widget name etc.
     */
    public function __construct() {
        parent::__construct(
            'tmc_widget',
            esc_html__( 'Today’s Month Calendar', 'todays-month-calendar' ),
            array(
                'description' => esc_html__( 'Displays the current month calendar with today highlighted.', 'todays-month-calendar' ),
            )
        );
    }

    /**
     * Outputs the content of the widget.
     *
     * @param array $args
     * @param array $instance
     */
    public function widget( $args, $instance ) {
        echo wp_kses_post( $args['before_widget'] );

        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        if ( ! empty( $title ) ) {
            echo wp_kses_post( $args['before_title'] );
            echo esc_html( apply_filters( 'widget_title', $title ) );
            echo wp_kses_post( $args['after_title'] );
        }

        echo TMC_Calendar::render_calendar(); // Safe, markup created with escaping.

        echo wp_kses_post( $args['after_widget'] );
    }

    /**
     * Outputs the options form on admin.
     *
     * @param array $instance The widget options
     */
    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $field_id   = $this->get_field_id( 'title' );
        $field_name = $this->get_field_name( 'title' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $field_id ); ?>">
                <?php esc_html_e( 'Title:', 'todays-month-calendar' ); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $field_name ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <?php
    }

    /**
     * Processing widget options on save.
     *
     * @param array $new_instance The new options
     * @param array $old_instance The previous options
     *
     * @return array
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = isset( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        return $instance;
    }
}
