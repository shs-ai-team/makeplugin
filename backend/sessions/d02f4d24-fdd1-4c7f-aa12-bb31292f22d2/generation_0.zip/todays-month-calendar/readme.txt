=== Today’s Month Calendar ===
Contributors: makeplugin
Tags: calendar, dates, widget, shortcode, accessibility, responsive, simple
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Displays the current month calendar with today highlighted.

== Description ==
Provide a simple monthly calendar that always shows the current month and clearly highlights today’s date. No events, bookings, or navigation—just a clean, typical month grid with day names. It automatically follows the site’s language, timezone, and week-start preference. The calendar is responsive, accessible, and inherits your theme’s styles with a subtle highlight for today. Place it anywhere using the shortcode or widget.

== Usage ==
- Shortcode: [todays_month_calendar]
- Widget: Today’s Month Calendar (Appearance → Widgets)

== Accessibility ==
Uses semantic table markup with caption, headers, and aria attributes. Today is indicated with aria-current="date".

== Installation ==
1. Upload the plugin folder to /wp-content/plugins/
2. Activate the plugin through the Plugins screen
3. Add the shortcode or widget where you want the calendar to appear

== Changelog ==
= 1.0.0 =
* Initial release.

== Frequently Asked Questions ==
= Can I change months? =
No. It always shows the current month as designed.

= Does it support translations? =
Yes. It uses WordPress localization functions and your site language.
