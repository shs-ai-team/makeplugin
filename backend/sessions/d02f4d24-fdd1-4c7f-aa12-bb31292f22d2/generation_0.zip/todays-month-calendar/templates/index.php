<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// Intentionally left blank.
