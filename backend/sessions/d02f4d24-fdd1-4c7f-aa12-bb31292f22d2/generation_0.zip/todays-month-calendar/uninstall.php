<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// No persistent options are stored by this plugin. This file exists to comply with WordPress standards.
