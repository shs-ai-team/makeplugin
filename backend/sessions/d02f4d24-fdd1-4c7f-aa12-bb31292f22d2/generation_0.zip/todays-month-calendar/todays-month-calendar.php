<?php
/**
 * Plugin Name: Today’s Month Calendar
 * Description: Displays the current month calendar with today highlighted.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: todays-month-calendar
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Tested up to: 6.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define constants.
if ( ! defined( 'TMC_VERSION' ) ) {
    define( 'TMC_VERSION', '1.0.0' );
}
if ( ! defined( 'TMC_PLUGIN_FILE' ) ) {
    define( 'TMC_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'TMC_PLUGIN_DIR' ) ) {
    define( 'TMC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'TMC_PLUGIN_URL' ) ) {
    define( 'TMC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

// Includes.
require_once TMC_PLUGIN_DIR . 'includes/class-tmc-calendar.php';
require_once TMC_PLUGIN_DIR . 'includes/class-tmc-widget.php';

/**
 * Load text domain for translations.
 */
function tmc_load_textdomain() {
    load_plugin_textdomain( 'todays-month-calendar', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'tmc_load_textdomain' );

/**
 * Enqueue frontend styles.
 */
function tmc_enqueue_styles() {
    wp_enqueue_style(
        'tmc-calendar',
        TMC_PLUGIN_URL . 'assets/css/calendar.css',
        array(),
        TMC_VERSION
    );
}
add_action( 'wp_enqueue_scripts', 'tmc_enqueue_styles' );

/**
 * Register shortcode to display the calendar.
 */
function tmc_register_shortcode() {
    add_shortcode( 'todays_month_calendar', 'tmc_shortcode_callback' );
}
add_action( 'init', 'tmc_register_shortcode' );

/**
 * Shortcode callback.
 *
 * @return string
 */
function tmc_shortcode_callback() {
    return TMC_Calendar::render_calendar();
}

/**
 * Register widget.
 */
function tmc_register_widget() {
    register_widget( 'TMC_Widget' );
}
add_action( 'widgets_init', 'tmc_register_widget' );
