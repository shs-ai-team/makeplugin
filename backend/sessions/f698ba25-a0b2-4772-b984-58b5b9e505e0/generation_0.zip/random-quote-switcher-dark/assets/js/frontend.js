(function () {
  'use strict';

  /**
   * Initialize a container instance.
   * @param {HTMLElement} container
   */
  function initContainer(container) {
    try {
      var quotesAttr = container.getAttribute('data-rqsdd-quotes') || '[]';
      var quotes = JSON.parse(quotesAttr);
      if (!Array.isArray(quotes) || quotes.length === 0) {
        return;
      }

      var quoteEl = container.querySelector('.rqsdd-quote');
      var btn = container.querySelector('.rqsdd-button');
      if (!quoteEl || !btn) {
        return;
      }

      var lastIndex = -1;

      function renderRandom(initial) {
        var idx;
        if (quotes.length === 1) {
          idx = 0;
        } else {
          do {
            idx = Math.floor(Math.random() * quotes.length);
          } while (idx === lastIndex);
        }
        lastIndex = idx;

        var setText = function () {
          // Use textContent to avoid injecting HTML.
          quoteEl.textContent = quotes[idx];
        };

        if (initial) {
          setText();
          return;
        }

        quoteEl.classList.add('is-fading');
        // After fade-out, switch text and fade back in.
        setTimeout(function () {
          setText();
          quoteEl.classList.remove('is-fading');
        }, 200);
      }

      // Initial render
      renderRandom(true);

      // Click handler
      btn.addEventListener('click', function () {
        renderRandom(false);
      });
    } catch (e) {
      // Silently fail to avoid breaking the page.
    }
  }

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  onReady(function () {
    var containers = document.querySelectorAll('.rqsdd-container[data-rqsdd-quotes]');
    containers.forEach(initContainer);
  });
})();
