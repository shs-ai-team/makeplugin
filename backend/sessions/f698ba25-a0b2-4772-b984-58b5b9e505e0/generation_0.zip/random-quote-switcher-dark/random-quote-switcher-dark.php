<?php
/**
 * Plugin Name: Random Quote Switcher (Dark)
 * Description: Dark-themed quote display with a button to show a random quote from 5 preloaded entries.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: random-quote-switcher-dark
 * Domain Path: /languages
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('RQSD_VERSION')) {
    define('RQSD_VERSION', '1.0.0');
}
if (!defined('RQSD_PLUGIN_FILE')) {
    define('RQSD_PLUGIN_FILE', __FILE__);
}
if (!defined('RQSD_PLUGIN_DIR')) {
    define('RQSD_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('RQSD_PLUGIN_URL')) {
    define('RQSD_PLUGIN_URL', plugin_dir_url(__FILE__));
}

/**
 * Load plugin textdomain.
 */
function rqsdd_load_textdomain() {
    load_plugin_textdomain('random-quote-switcher-dark', false, dirname(plugin_basename(RQSD_PLUGIN_FILE)) . '/languages');
}
add_action('plugins_loaded', 'rqsdd_load_textdomain');

/**
 * Get preloaded quotes.
 *
 * @return array
 */
function rqsdd_get_quotes() {
    return array(
        /* translators: Steve Jobs quote */
        __('“The only way to do great work is to love what you do.” — Steve Jobs', 'random-quote-switcher-dark'),
        /* translators: Henry Ford quote */
        __('“Whether you think you can or you can’t, you’re right.” — Henry Ford', 'random-quote-switcher-dark'),
        /* translators: Winston Churchill quote */
        __('“Success is not final, failure is not fatal: it is the courage to continue that counts.” — Winston Churchill', 'random-quote-switcher-dark'),
        /* translators: Buddha quote */
        __('“What we think, we become.” — Buddha', 'random-quote-switcher-dark'),
        /* translators: Wayne Gretzky quote */
        __('“You miss 100% of the shots you don’t take.” — Wayne Gretzky', 'random-quote-switcher-dark'),
    );
}

/**
 * Register frontend assets.
 */
function rqsdd_register_assets() {
    wp_register_style(
        'rqsdd-style',
        RQSD_PLUGIN_URL . 'assets/css/style.css',
        array(),
        RQSD_VERSION
    );

    wp_register_script(
        'rqsdd-frontend',
        RQSD_PLUGIN_URL . 'assets/js/frontend.js',
        array('wp-i18n'),
        RQSD_VERSION,
        true
    );
}
add_action('init', 'rqsdd_register_assets');

/**
 * Render the quote switcher markup.
 *
 * @return string
 */
function rqsdd_render_quote_switcher() {
    // Enqueue assets only when rendering.
    wp_enqueue_style('rqsdd-style');
    wp_enqueue_script('rqsdd-frontend');

    $quotes = rqsdd_get_quotes();

    $data_attr = esc_attr(wp_json_encode($quotes));

    ob_start();
    ?>
    <div class="rqsdd-container" data-rqsdd-quotes="<?php echo $data_attr; ?>">
        <div class="rqsdd-quote" aria-live="polite"></div>
        <button type="button" class="rqsdd-button" aria-label="<?php echo esc_attr(__('Get a new quote', 'random-quote-switcher-dark')); ?>">
            <?php echo esc_html__('New Quote', 'random-quote-switcher-dark'); ?>
        </button>
    </div>
    <?php
    $output = ob_get_clean();

    return $output;
}

/**
 * Shortcode handler.
 *
 * @return string
 */
function rqsdd_shortcode_handler() {
    return rqsdd_render_quote_switcher();
}
add_shortcode('random_quote_switcher_dark', 'rqsdd_shortcode_handler');

/**
 * Register widget.
 */
function rqsdd_register_widget() {
    require_once RQSD_PLUGIN_DIR . 'includes/class-rqsd-widget.php';
    register_widget('RQSD_Widget');
}
add_action('widgets_init', 'rqsdd_register_widget');
