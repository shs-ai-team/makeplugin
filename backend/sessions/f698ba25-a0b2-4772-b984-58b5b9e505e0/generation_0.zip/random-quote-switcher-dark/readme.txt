=== Random Quote Switcher (Dark) ===
Contributors: makeplugin
Tags: quotes, widget, shortcode, random, dark, accessibility, responsive
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Dark-themed quote display with a button to show a random quote from 5 preloaded entries.

== Description ==
Create a simple dark-themed quote widget that shows one quote and a “New Quote” button. A random quote appears on page load; each button click replaces it with another random one. Uses a readable, high-contrast style, responsive layout, and a subtle fade when changing quotes. No settings needed.

Use as a shortcode or widget:

- Shortcode: [random_quote_switcher_dark]
- Widget: Random Quote Switcher (Dark)

== Installation ==
1. Upload the plugin folder to the /wp-content/plugins/ directory or install via the WordPress Plugins screen.
2. Activate the plugin through the Plugins screen in WordPress.
3. Add the widget to a sidebar or use the [random_quote_switcher_dark] shortcode in a post or page.

== Changelog ==
= 1.0.0 =
* Initial release.

== Frequently Asked Questions ==
= Can I change the quotes? =
Currently, the plugin ships with 5 preloaded quotes and no settings. You can filter or extend the plugin in code in future updates.
