<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// No persistent data stored by this plugin. This file exists to comply with WordPress standards.
