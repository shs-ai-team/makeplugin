<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Random Quote Switcher Dark Widget
 */
class RQSD_Widget extends WP_Widget {
    /**
     * Sets up the widget name etc.
     */
    public function __construct() {
        parent::__construct(
            'rqsdd_widget',
            esc_html__('Random Quote Switcher (Dark)', 'random-quote-switcher-dark'),
            array(
                'description' => esc_html__('Displays a dark-themed random quote with a button to switch.', 'random-quote-switcher-dark')
            )
        );
    }

    /**
     * Outputs the content of the widget.
     *
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance) {
        echo isset($args['before_widget']) ? wp_kses_post($args['before_widget']) : '';

        // Optional title support (hidden from settings, use default).
        $title = isset($instance['title']) ? $instance['title'] : '';
        if (!empty($title)) {
            echo isset($args['before_title']) ? wp_kses_post($args['before_title']) : '';
            echo esc_html($title);
            echo isset($args['after_title']) ? wp_kses_post($args['after_title']) : '';
        }

        // Render the switcher.
        echo rqsdd_render_quote_switcher(); // Safe: function returns escaped markup and enqueues assets.

        echo isset($args['after_widget']) ? wp_kses_post($args['after_widget']) : '';
    }

    /**
     * Outputs the options form on admin (no settings required).
     *
     * @param array $instance
     */
    public function form($instance) {
        // No settings needed as per requirements. Provide an informative note.
        echo '<p>' . esc_html__('This widget has no settings.', 'random-quote-switcher-dark') . '</p>';
    }

    /**
     * Processing widget options on save (none used).
     *
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance) {
        // No settings to save.
        return array();
    }
}
