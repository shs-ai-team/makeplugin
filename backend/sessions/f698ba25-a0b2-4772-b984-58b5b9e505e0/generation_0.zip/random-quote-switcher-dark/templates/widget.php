<?php
if (!defined('ABSPATH')) {
    exit;
}

// This template is not directly used but provided for potential overrides in the future.
?>
<div class="rqsdd-container" data-rqsdd-quotes="<?php echo esc_attr(wp_json_encode(rqsdd_get_quotes())); ?>">
    <div class="rqsdd-quote" aria-live="polite"></div>
    <button type="button" class="rqsdd-button" aria-label="<?php echo esc_attr(__('Get a new quote', 'random-quote-switcher-dark')); ?>">
        <?php echo esc_html__('New Quote', 'random-quote-switcher-dark'); ?>
    </button>
</div>
