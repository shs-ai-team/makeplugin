<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// No options or custom tables are created by this plugin.
// This file exists to comply with WordPress.org guidelines.
