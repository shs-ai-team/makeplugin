<?php
if (!defined('ABSPATH')) {
    exit;
}

class Z5DW_Plugin {
    const OPTION_API_KEY = 'z5dw_api_key';
    const TRANSIENT_PREFIX = 'z5dw_forecast_';

    public function __construct() {
        add_action('admin_menu', array($this, 'register_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_filter('the_content', array($this, 'inject_forecast_into_content'));
    }

    public function register_settings_page() {
        add_options_page(
            esc_html__('Zurich Weather', 'zurich-5-day-weather'),
            esc_html__('Zurich Weather', 'zurich-5-day-weather'),
            'manage_options',
            'z5dw-settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            'z5dw_settings_group',
            self::OPTION_API_KEY,
            array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default' => ''
            )
        );

        add_settings_section(
            'z5dw_main_section',
            esc_html__('API Settings', 'zurich-5-day-weather'),
            '__return_false',
            'z5dw-settings'
        );

        add_settings_field(
            'z5dw_api_key_field',
            esc_html__('OpenWeatherMap API Key', 'zurich-5-day-weather'),
            array($this, 'render_api_key_field'),
            'z5dw-settings',
            'z5dw_main_section'
        );
    }

    public function render_api_key_field() {
        $api_key = get_option(self::OPTION_API_KEY, '');
        echo '<input type="text" id="z5dw_api_key_field" name="' . esc_attr(self::OPTION_API_KEY) . '" value="' . esc_attr($api_key) . '" class="regular-text" />';
        echo '<p class="description">' . esc_html__('Enter your OpenWeatherMap API key. The forecast is fixed to Zurich, Switzerland.', 'zurich-5-day-weather') . '</p>';
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'zurich-5-day-weather'));
        }
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Zurich 5-Day Weather Settings', 'zurich-5-day-weather') . '</h1>';
        echo '<form method="post" action="' . esc_url(admin_url('options.php')) . '">';
        settings_fields('z5dw_settings_group');
        do_settings_sections('z5dw-settings');
        submit_button(esc_html__('Save Settings', 'zurich-5-day-weather'));
        echo '</form>';
        echo '</div>';
    }

    public function inject_forecast_into_content($content) {
        if (!is_admin() && is_front_page() && in_the_loop() && is_main_query()) {
            $html = $this->get_forecast_html();
            if (!empty($html)) {
                // Prepend forecast to main content
                $content = $html . $content;
            }
        }
        return $content;
    }

    private function get_transient_key($api_key) {
        $suffix = !empty($api_key) ? md5($api_key) : 'no_key';
        return self::TRANSIENT_PREFIX . $suffix;
    }

    public function get_forecast_html() {
        $api_key = get_option(self::OPTION_API_KEY, '');
        $transient_key = $this->get_transient_key($api_key);

        $cached = get_transient($transient_key);
        if ($cached && is_array($cached)) {
            return $this->render_template($cached);
        }

        $forecast = $this->fetch_forecast($api_key);
        if (is_wp_error($forecast)) {
            $message = esc_html__('Weather data is currently unavailable. Please check back later.', 'zurich-5-day-weather');
            return '<div class="z5dw-forecast z5dw-error" role="status">' . $message . '</div>';
        }

        // Cache for 30 minutes
        set_transient($transient_key, $forecast, 30 * MINUTE_IN_SECONDS);

        return $this->render_template($forecast);
    }

    private function fetch_forecast($api_key) {
        if (empty($api_key)) {
            return new WP_Error('z5dw_no_api_key', esc_html__('API key is missing.', 'zurich-5-day-weather'));
        }

        $url = add_query_arg(
            array(
                'lat'   => '47.3769',
                'lon'   => '8.5417',
                'units' => 'metric',
                'appid' => $api_key
            ),
            'https://api.openweathermap.org/data/2.5/forecast'
        );

        $response = wp_remote_get(esc_url_raw($url), array(
            'timeout' => 15,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200 || empty($body)) {
            return new WP_Error('z5dw_bad_response', esc_html__('Failed to retrieve weather data.', 'zurich-5-day-weather'));
        }

        $data = json_decode($body, true);
        if (!is_array($data) || empty($data['list'])) {
            return new WP_Error('z5dw_invalid_data', esc_html__('Invalid weather data received.', 'zurich-5-day-weather'));
        }

        // Aggregate into 5 days
        $days = array();
        foreach ($data['list'] as $entry) {
            if (empty($entry['dt']) || empty($entry['main']) || empty($entry['weather'][0])) {
                continue;
            }
            $timestamp = intval($entry['dt']);
            // Convert to Zurich local date (Europe/Zurich)
            $dt = new DateTime('@' . $timestamp);
            try {
                $dt->setTimezone(new DateTimeZone('Europe/Zurich'));
            } catch (Exception $e) {
                // Fallback to site timezone
                $dt->setTimezone(wp_timezone());
            }
            $date_key = $dt->format('Y-m-d');

            $temp_min = isset($entry['main']['temp_min']) ? floatval($entry['main']['temp_min']) : null;
            $temp_max = isset($entry['main']['temp_max']) ? floatval($entry['main']['temp_max']) : null;
            $weather = $entry['weather'][0];
            $desc = isset($weather['main']) ? sanitize_text_field($weather['main']) : '';
            $icon = isset($weather['icon']) ? sanitize_text_field($weather['icon']) : '';

            if (!isset($days[$date_key])) {
                $days[$date_key] = array(
                    'date' => $date_key,
                    'min' => $temp_min,
                    'max' => $temp_max,
                    'descs' => array(),
                    'icons' => array()
                );
            } else {
                if ($temp_min !== null) {
                    $days[$date_key]['min'] = min($days[$date_key]['min'], $temp_min);
                }
                if ($temp_max !== null) {
                    $days[$date_key]['max'] = max($days[$date_key]['max'], $temp_max);
                }
            }

            if ($desc !== '') {
                if (!isset($days[$date_key]['descs'][$desc])) {
                    $days[$date_key]['descs'][$desc] = 0;
                }
                $days[$date_key]['descs'][$desc]++;
            }
            if ($icon !== '') {
                if (!isset($days[$date_key]['icons'][$icon])) {
                    $days[$date_key]['icons'][$icon] = 0;
                }
                $days[$date_key]['icons'][$icon]++;
            }
        }

        if (empty($days)) {
            return new WP_Error('z5dw_no_days', esc_html__('No forecast data available.', 'zurich-5-day-weather'));
        }

        // Sort by date and take first 5 days starting today
        ksort($days);
        $final = array();
        foreach ($days as $d) {
            $desc = '';
            $icon = '';
            if (!empty($d['descs'])) {
                arsort($d['descs']);
                $desc = sanitize_text_field(key($d['descs']));
            }
            if (!empty($d['icons'])) {
                arsort($d['icons']);
                $icon = sanitize_text_field(key($d['icons']));
            }
            $final[] = array(
                'date' => sanitize_text_field($d['date']),
                'min' => round(floatval($d['min'])),
                'max' => round(floatval($d['max'])),
                'desc' => $desc,
                'icon' => $icon
            );
            if (count($final) >= 5) {
                break;
            }
        }

        // Human readable title
        $title = esc_html__('Zurich 5-Day Forecast', 'zurich-5-day-weather');

        return array(
            'title' => $title,
            'city' => 'Zurich',
            'country' => 'CH',
            'days' => $final
        );
    }

    private function render_template($forecast) {
        if (empty($forecast['days']) || !is_array($forecast['days'])) {
            return '<div class="z5dw-forecast z5dw-error" role="status">' . esc_html__('Weather data is currently unavailable. Please check back later.', 'zurich-5-day-weather') . '</div>';
        }

        ob_start();
        $data = $forecast; // array with title, days
        $template = plugin_dir_path(__FILE__) . '../templates/forecast.php';
        if (file_exists($template)) {
            include $template;
        }
        $html = ob_get_clean();
        return $html;
    }
}
