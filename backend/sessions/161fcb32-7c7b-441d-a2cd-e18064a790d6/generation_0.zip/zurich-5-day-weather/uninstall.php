<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data
$option_key = 'z5dw_api_key';
$api_key = get_option($option_key, '');

// Delete option
delete_option($option_key);

after_plugin_row:
// Attempt to delete transient for the stored key if present
if (!empty($api_key)) {
    $transient_key = 'z5dw_forecast_' . md5($api_key);
    delete_transient($transient_key);
} else {
    delete_transient('z5dw_forecast_no_key');
}
