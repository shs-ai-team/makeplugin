<?php
/**
 * Plugin Name: Zurich 5-Day Weather
 * Description: Displays a 5-day weather forecast for Zurich, Switzerland in Celsius.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: zurich-5-day-weather
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load text domain
function z5dw_load_textdomain() {
    load_plugin_textdomain('zurich-5-day-weather', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'z5dw_load_textdomain');

// Include main class
require_once plugin_dir_path(__FILE__) . 'includes/class-z5dw-plugin.php';

// Initialize plugin
function z5dw_init_plugin() {
    static $instance = null;
    if (null === $instance) {
        $instance = new Z5DW_Plugin();
    }
    return $instance;
}
add_action('init', 'z5dw_init_plugin');

// Enqueue styles
function z5dw_enqueue_assets() {
    wp_enqueue_style(
        'z5dw-style',
        plugin_dir_url(__FILE__) . 'assets/style.css',
        array(),
        '1.0.0'
    );
}
add_action('wp_enqueue_scripts', 'z5dw_enqueue_assets');
