<?php
if (!defined('ABSPATH')) {
    exit;
}

/* @var array $data */
$days = isset($data['days']) && is_array($data['days']) ? $data['days'] : array();
$title = isset($data['title']) ? $data['title'] : esc_html__('Zurich 5-Day Forecast', 'zurich-5-day-weather');
?>
<div class="z5dw-forecast" aria-live="polite">
    <h2 class="z5dw-title"><?php echo esc_html($title); ?></h2>
    <div class="z5dw-grid">
        <?php foreach ($days as $day) :
            $date_str = isset($day['date']) ? sanitize_text_field($day['date']) : '';
            $dt_display = '';
            if ($date_str) {
                try {
                    $dt = new DateTime($date_str, new DateTimeZone('Europe/Zurich'));
                    /* translators: 1: localized month/day, 2: year */
                    $dt_display = $dt->format(esc_html_x('M j, Y', 'Date format for forecast items', 'zurich-5-day-weather'));
                } catch (Exception $e) {
                    $dt_display = esc_html($date_str);
                }
            }
            $desc = isset($day['desc']) ? $day['desc'] : '';
            $icon = isset($day['icon']) ? $day['icon'] : '';
            $min = isset($day['min']) ? intval($day['min']) : '';
            $max = isset($day['max']) ? intval($day['max']) : '';
            $icon_url = '';
            if ($icon !== '') {
                // OpenWeatherMap icon URL
                $icon_url = 'https://openweathermap.org/img/wn/' . rawurlencode($icon) . '@2x.png';
            }
        ?>
        <div class="z5dw-day" role="group" aria-label="<?php /* translators: %s: date */ printf(esc_attr__('Forecast for %s', 'zurich-5-day-weather'), esc_attr($dt_display)); ?>">
            <div class="z5dw-date"><?php echo esc_html($dt_display); ?></div>
            <div class="z5dw-icon-wrap">
                <?php if ($icon_url) : ?>
                    <img class="z5dw-icon" src="<?php echo esc_url($icon_url); ?>" alt="<?php echo esc_attr($desc); ?>" width="64" height="64" loading="lazy" />
                <?php endif; ?>
            </div>
            <div class="z5dw-desc"><?php echo esc_html($desc); ?></div>
            <div class="z5dw-temps">
                <span class="z5dw-temp-max" aria-label="<?php echo esc_attr__('High', 'zurich-5-day-weather'); ?>"><?php echo esc_html($max); ?>°C</span>
                <span class="z5dw-sep">/</span>
                <span class="z5dw-temp-min" aria-label="<?php echo esc_attr__('Low', 'zurich-5-day-weather'); ?>"><?php echo esc_html($min); ?>°C</span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
