=== Zurich 5-Day Weather ===
Contributors: makeplugin
Tags: weather, forecast, zurich, celsius, homepage, openweathermap
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Displays a 5-day weather forecast for Zurich, Switzerland in Celsius.

== Description ==
Zurich 5-Day Weather displays a clean, compact 5-day forecast for Zurich, Switzerland (fixed location) in Celsius. It shows the local date, a brief condition with icon, and high/low temperatures. The forecast is automatically centered on the homepage within the main content area.

Features:
- Fixed to Zurich, Switzerland
- Celsius units only
- 5-day forecast with icons
- Caches results for 30 minutes
- Settings page to enter your OpenWeatherMap API key
- Friendly message if data is unavailable

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/zurich-5-day-weather` directory, or install via the Plugins screen in WordPress.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to Settings → Zurich Weather and enter your OpenWeatherMap API key.

== Frequently Asked Questions ==
= Where does the data come from? =
Data is fetched from the OpenWeatherMap 5-day forecast API.

= Can I change the location or units? =
No. The location is fixed to Zurich, Switzerland and units are Celsius only.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
