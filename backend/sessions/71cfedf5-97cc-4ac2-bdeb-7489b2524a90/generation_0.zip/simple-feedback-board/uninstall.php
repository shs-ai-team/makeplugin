<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete all feedback posts created by the plugin
$posts = get_posts(array(
    'post_type'      => 'sfb_feedback',
    'post_status'    => 'any',
    'numberposts'    => -1,
    'fields'         => 'ids',
    'suppress_filters' => true,
));

if (!empty($posts) && is_array($posts)) {
    foreach ($posts as $pid) {
        wp_delete_post($pid, true);
    }
}
