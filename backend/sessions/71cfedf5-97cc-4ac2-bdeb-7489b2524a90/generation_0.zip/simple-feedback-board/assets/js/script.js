(function($){
    function setAlert(message, type){
        var $alert = $('#sfb-alert');
        $alert.removeClass('sfb-success sfb-error');
        if(type === 'success'){
            $alert.addClass('sfb-success');
        } else {
            $alert.addClass('sfb-error');
        }
        $alert.text(message).show();
    }

    $(document).on('submit', '#sfb-form', function(e){
        e.preventDefault();
        var $form = $(this);
        var name = $.trim($('#sfb-name').val());
        var message = $.trim($('#sfb-message').val());
        var nonce = $('input[name="_sfb_nonce"]', $form).val();

        // Client-side word limit check for quick feedback
        var words = message.replace(/<[^>]*>/g, '').split(/\s+/).filter(function(w){return w.length;});
        if(words.length > 150){
            setAlert(SFBData && SFBData.strings ? (SFBData.strings.tooLong || 'Your message is too long.') : 'Your message is too long.', 'error');
            return;
        }

        $.ajax({
            url: SFBData.ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'sfb_submit',
                name: name,
                message: message,
                _sfb_nonce: nonce
            }
        }).done(function(resp){
            if(resp && resp.success){
                setAlert(resp.data && resp.data.message ? resp.data.message : 'Success', 'success');
                // Prepend new item to list
                if(resp.data && resp.data.item){
                    var $list = $('#sfb-list ul.sfb-items');
                    if($list.length){
                        $list.prepend(resp.data.item);
                    } else {
                        $('#sfb-list').html('<ul class="sfb-items">' + resp.data.item + '</ul>');
                    }
                }
                // Reset form
                $('#sfb-name').val('');
                $('#sfb-message').val('');
            } else {
                var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Error';
                setAlert(msg, 'error');
            }
        }).fail(function(){
            setAlert('An unexpected error occurred. Please try again.', 'error');
        });
    });
})(jQuery);
