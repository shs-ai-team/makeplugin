<?php
if (!defined('ABSPATH')) {
    exit;
}

class SFB_Plugin {
    const POST_TYPE = 'sfb_feedback';

    public function __construct() {
        add_action('init', array($this, 'register_post_type'));
        add_shortcode('simple_feedback_board', array($this, 'shortcode_render'));
        add_action('wp_ajax_sfb_submit', array($this, 'handle_submit'));
        add_action('wp_ajax_nopriv_sfb_submit', array($this, 'handle_submit'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
    }

    public function register_post_type() {
        $labels = array(
            'name'                  => esc_html__('Feedback', 'simple-feedback-board'),
            'singular_name'         => esc_html__('Feedback', 'simple-feedback-board'),
            'add_new'               => esc_html__('Add New', 'simple-feedback-board'),
            'add_new_item'          => esc_html__('Add New Feedback', 'simple-feedback-board'),
            'edit_item'             => esc_html__('Edit Feedback', 'simple-feedback-board'),
            'new_item'              => esc_html__('New Feedback', 'simple-feedback-board'),
            'view_item'             => esc_html__('View Feedback', 'simple-feedback-board'),
            'search_items'          => esc_html__('Search Feedback', 'simple-feedback-board'),
            'not_found'             => esc_html__('No feedback found', 'simple-feedback-board'),
            'not_found_in_trash'    => esc_html__('No feedback found in Trash', 'simple-feedback-board'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'exclude_from_search'=> true,
            'publicly_queryable' => false,
            'has_archive'        => false,
            'rewrite'            => false,
            'supports'           => array('title', 'editor'),
            'capability_type'    => 'post',
        );

        register_post_type(self::POST_TYPE, $args);
    }

    public function register_assets() {
        wp_register_style(
            'sfb-style',
            SFB_PLUGIN_URL . 'assets/css/style.css',
            array(),
            SFB_VERSION
        );

        wp_register_script(
            'sfb-script',
            SFB_PLUGIN_URL . 'assets/js/script.js',
            array('jquery'),
            SFB_VERSION,
            true
        );
    }

    private function enqueue_assets() {
        wp_enqueue_style('sfb-style');
        wp_enqueue_script('sfb-script');
        wp_localize_script(
            'sfb-script',
            'SFBData',
            array(
                'ajaxUrl' => esc_url(admin_url('admin-ajax.php')),
                'nonce'   => wp_create_nonce('sfb_submit'),
                'strings' => array(
                    'success' => esc_html__('Thank you for your feedback!', 'simple-feedback-board')
                )
            )
        );
    }

    public function shortcode_render($atts = array(), $content = '') {
        $this->enqueue_assets();

        ob_start();
        $nonce_field = wp_create_nonce('sfb_submit');
        ?>
        <div class="sfb-wrap" aria-live="polite">
            <form id="sfb-form" class="sfb-form" method="post" novalidate>
                <div class="sfb-field">
                    <label for="sfb-name"><?php echo esc_html__('Name', 'simple-feedback-board'); ?></label>
                    <input type="text" id="sfb-name" name="name" required maxlength="120" />
                </div>
                <div class="sfb-field">
                    <label for="sfb-message"><?php echo esc_html__('Message', 'simple-feedback-board'); ?></label>
                    <textarea id="sfb-message" name="message" rows="5" required></textarea>
                    <div class="sfb-help"><?php echo esc_html__('Limit: 150 words', 'simple-feedback-board'); ?></div>
                </div>
                <input type="hidden" name="_sfb_nonce" value="<?php echo esc_attr($nonce_field); ?>" />
                <button type="submit" class="sfb-submit"><?php echo esc_html__('Send Feedback', 'simple-feedback-board'); ?></button>
                <div class="sfb-alert" id="sfb-alert" role="alert" aria-live="assertive" aria-atomic="true"></div>
            </form>

            <div class="sfb-list" id="sfb-list">
                <?php echo wp_kses_post($this->get_feedback_list_markup()); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function get_feedback_list_markup() {
        $args = array(
            'post_type'      => self::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );
        $q = new WP_Query($args);

        ob_start();
        if ($q->have_posts()) {
            echo '<ul class="sfb-items">';
            while ($q->have_posts()) {
                $q->the_post();
                $pid = get_the_ID();
                $name = get_the_title($pid);
                $message = get_post_field('post_content', $pid);
                echo '<li class="sfb-item">';
                echo '<div class="sfb-item-name">' . esc_html($name) . '</div>';
                echo '<div class="sfb-item-message">' . nl2br(esc_html($message)) . '</div>';
                echo '</li>';
            }
            echo '</ul>';
            wp_reset_postdata();
        } else {
            echo '<p class="sfb-empty">' . esc_html__('No feedback yet. Be the first to share!', 'simple-feedback-board') . '</p>';
        }

        return ob_get_clean();
    }

    public function handle_submit() {
        check_ajax_referer('sfb_submit', '_sfb_nonce');

        $name    = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $message = isset($_POST['message']) ? wp_kses_post(wp_unslash($_POST['message'])) : '';

        if ('' === $name) {
            wp_send_json_error(array(
                'message' => esc_html__('Please enter your name.', 'simple-feedback-board')
            ));
        }

        if ('' === trim(wp_strip_all_tags($message))) {
            wp_send_json_error(array(
                'message' => esc_html__('Please enter a message.', 'simple-feedback-board')
            ));
        }

        $word_count = str_word_count(wp_strip_all_tags($message));
        if ($word_count > 150) {
            /* translators: %d: maximum number of words allowed */
            $error = sprintf(esc_html__('Your message is too long. Maximum %d words.', 'simple-feedback-board'), 150);
            wp_send_json_error(array('message' => $error));
        }

        $postarr = array(
            'post_type'    => self::POST_TYPE,
            'post_status'  => 'publish',
            'post_title'   => $name,
            'post_content' => wp_kses_post($message),
        );

        $post_id = wp_insert_post($postarr, true);

        if (is_wp_error($post_id)) {
            /* translators: %s: error message */
            $error = sprintf(esc_html__('Submission failed: %s', 'simple-feedback-board'), $post_id->get_error_message());
            wp_send_json_error(array('message' => $error));
        }

        $item_markup  = '<li class="sfb-item">';
        $item_markup .= '<div class="sfb-item-name">' . esc_html($name) . '</div>';
        $item_markup .= '<div class="sfb-item-message">' . nl2br(esc_html(wp_strip_all_tags($message))) . '</div>';
        $item_markup .= '</li>';

        wp_send_json_success(array(
            'message' => esc_html__('Thank you for your feedback!', 'simple-feedback-board'),
            'item'    => $item_markup
        ));
    }
}
