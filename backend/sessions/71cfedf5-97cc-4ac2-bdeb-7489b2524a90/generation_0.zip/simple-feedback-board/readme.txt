=== Simple Feedback Board ===
Contributors: makeplugin
Tags: feedback, form, testimonials, comments, frontend submission, ajax
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

A minimal feedback form with a live list of all submissions.

== Description ==
Provide a clean, minimal form with two fields: Name and Message. Message is limited to 150 words; clear validation shows if exceeded. Anyone (no login required) can submit. Each submission is saved and immediately appears below the form in a simple list view that displays all past feedback. The list shows each entry’s Name and Message, with a straightforward, readable layout. Include clear success and error messages. The site owner can place this form-and-list section on any page via the [simple_feedback_board] shortcode. Styling is minimal, accessible, and user-friendly.

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/simple-feedback-board directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the shortcode [simple_feedback_board] to any page or post.

== Frequently Asked Questions ==
= How do I display the form and list? =
Use the shortcode [simple_feedback_board] on any page or post.

= Do users need to be logged in? =
No. Anyone can submit feedback.

= Can I change the styles? =
Yes. Minimal CSS is included. You can override styles in your theme.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
