<?php
/**
 * Plugin Name: Simple Feedback Board
 * Description: A minimal feedback form with a live list of all submissions.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: simple-feedback-board
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('SFB_VERSION')) {
    define('SFB_VERSION', '1.0.0');
}

if (!defined('SFB_TEXT_DOMAIN')) {
    define('SFB_TEXT_DOMAIN', 'simple-feedback-board');
}

if (!defined('SFB_PLUGIN_FILE')) {
    define('SFB_PLUGIN_FILE', __FILE__);
}

if (!defined('SFB_PLUGIN_DIR')) {
    define('SFB_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('SFB_PLUGIN_URL')) {
    define('SFB_PLUGIN_URL', plugin_dir_url(__FILE__));
}

function sfb_load_textdomain() {
    load_plugin_textdomain('simple-feedback-board', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'sfb_load_textdomain');

require_once SFB_PLUGIN_DIR . 'includes/class-sfb.php';

function sfb_init_plugin() {
    $GLOBALS['sfb_plugin'] = new SFB_Plugin();
}
add_action('init', 'sfb_init_plugin');
