(function($){
    function initCarousel($carousel){
        var $track = $carousel.find('.cats-carousel__track');
        var $slides = $track.find('.cats-carousel__slide');
        var total = $slides.length;
        if (!total) { return; }
        var index = 0;
        var interval = parseInt($carousel.attr('data-interval'), 10) || (window.CatsCarouselL10n && parseInt(CatsCarouselL10n.interval,10)) || 2000;
        var timer;

        function goTo(i){
            index = (i + total) % total;
            var x = -(index * 100);
            $track.css('transform', 'translateX(' + x + '%)');
        }
        function next(){ goTo(index + 1); }
        function prev(){ goTo(index - 1); }
        function start(){ stop(); timer = setInterval(next, interval); }
        function stop(){ if (timer) { clearInterval(timer); timer = null; } }

        $carousel.find('.cats-carousel__nav--next').on('click', function(e){ e.preventDefault(); next(); start(); });
        $carousel.find('.cats-carousel__nav--prev').on('click', function(e){ e.preventDefault(); prev(); start(); });

        $carousel.on('mouseenter focusin', stop).on('mouseleave focusout', start);

        goTo(0);
        start();
    }

    $(function(){
        $('.cats-carousel').each(function(){ initCarousel($(this)); });
    });
})(jQuery);
