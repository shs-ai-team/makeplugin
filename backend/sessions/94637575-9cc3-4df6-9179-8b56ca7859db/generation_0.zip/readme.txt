=== Cats Carousel ===
Contributors: makeplugin
Tags: carousel, slider, images, gallery, cats, responsive, shortcode
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Full-width auto-scrolling cat image carousel with admin-managed images and shortcode.

== Description ==
Cats Carousel adds a responsive, full-width image carousel featuring cats. It comes preloaded with a set of royalty-free cat illustrations so it works immediately after activation. Add more images from the Media Library and remove existing ones with a simple settings page. The carousel auto-advances every 2 seconds, loops continuously, and includes visible left/right buttons for manual navigation. Images scale across desktop and mobile while maintaining an edge-to-edge presentation. Place it anywhere using the [cats_carousel] shortcode or the cats_carousel_render() template tag.

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/cats-carousel directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to Settings → Cats Carousel to manage images.
4. Insert [cats_carousel] into any page or post to display the carousel.

== Frequently Asked Questions ==
= How do I add more images? =
Go to Settings → Cats Carousel and click "Select Images" to add from your Media Library.

= Can I place the carousel in a template? =
Yes, call cats_carousel_render() in your theme template.

== Changelog ==
= 1.0.0 =
* Initial release.

== Credits ==
Bundled cat illustrations are simple SVG shapes generated for demonstration and are royalty-free.
