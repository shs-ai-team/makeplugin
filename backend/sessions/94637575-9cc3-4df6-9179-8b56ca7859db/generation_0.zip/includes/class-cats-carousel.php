<?php
if (!defined('ABSPATH')) {
    exit;
}

class Cats_Carousel {
    private static $instance = null;
    private $option_key = 'cats_carousel_image_ids';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue'));
    }

    public function enqueue_assets() {
        wp_enqueue_style(
            'cats-carousel-style',
            CATS_CAROUSEL_PLUGIN_URL . 'assets/css/style.css',
            array(),
            CATS_CAROUSEL_VERSION
        );
        wp_enqueue_script(
            'cats-carousel-script',
            CATS_CAROUSEL_PLUGIN_URL . 'assets/js/carousel.js',
            array('jquery'),
            CATS_CAROUSEL_VERSION,
            true
        );
        wp_localize_script(
            'cats-carousel-script',
            'CatsCarouselL10n',
            array(
                'next' => esc_html__('Next', 'cats-carousel'),
                'prev' => esc_html__('Previous', 'cats-carousel'),
                'interval' => 2000,
            )
        );
    }

    public function admin_enqueue($hook) {
        if ('settings_page_cats-carousel' !== $hook) {
            return;
        }
        wp_enqueue_media();
    }

    public function register_settings() {
        register_setting(
            'cats_carousel_settings_group',
            $this->option_key,
            array(
                'sanitize_callback' => array($this, 'sanitize_ids')
            )
        );
    }

    public function sanitize_ids($value) {
        if (!is_array($value)) {
            return array();
        }
        $value = array_map('absint', $value);
        $value = array_filter($value);
        return array_values($value);
    }

    public function register_admin_menu() {
        add_options_page(
            esc_html__('Cats Carousel', 'cats-carousel'),
            esc_html__('Cats Carousel', 'cats-carousel'),
            'manage_options',
            'cats-carousel',
            array($this, 'admin_page')
        );
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'cats-carousel'));
        }

        $message = '';
        // Handle remove action
        if (isset($_POST['cats_carousel_remove_id'])) {
            check_admin_referer('cats_carousel_remove');
            $remove_id = absint(wp_unslash($_POST['cats_carousel_remove_id']));
            $ids = get_option($this->option_key, array());
            $new = array();
            foreach ($ids as $id) {
                if ((int) $id !== $remove_id) {
                    $new[] = (int) $id;
                }
            }
            update_option($this->option_key, $new);
            $message = esc_html__('Image removed.', 'cats-carousel');
        }

        // Handle add action via CSV field
        if (isset($_POST['cats_carousel_new_ids'])) {
            check_admin_referer('cats_carousel_add');
            $csv = sanitize_text_field(wp_unslash($_POST['cats_carousel_new_ids']));
            $add = array();
            if (!empty($csv)) {
                foreach (explode(',', $csv) as $part) {
                    $id = absint($part);
                    if ($id) {
                        $add[] = $id;
                    }
                }
            }
            if (!empty($add)) {
                $existing = get_option($this->option_key, array());
                foreach ($add as $id) {
                    if (!in_array($id, $existing, true)) {
                        $existing[] = $id; // append to keep newest at the end
                    }
                }
                update_option($this->option_key, array_map('absint', $existing));
                $message = esc_html__('Images added.', 'cats-carousel');
            }
        }

        $ids = get_option($this->option_key, array());
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Cats Carousel', 'cats-carousel'); ?></h1>
            <?php if (!empty($message)) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>

            <h2><?php echo esc_html__('Current Images', 'cats-carousel'); ?></h2>
            <p><?php echo esc_html__('These images appear in the carousel in the order shown (newest at the end).', 'cats-carousel'); ?></p>
            <div style="display:flex;flex-wrap:wrap;gap:16px;">
                <?php if (!empty($ids)) : ?>
                    <?php foreach ($ids as $id) : ?>
                        <?php $thumb = wp_get_attachment_image_src($id, 'thumbnail'); ?>
                        <div style="border:1px solid #ccd0d4;padding:8px;border-radius:4px;max-width:150px;">
                            <?php if ($thumb) : ?>
                                <img src="<?php echo esc_url($thumb[0]); ?>" alt="" style="width:100%;height:auto;display:block;" />
                            <?php else : ?>
                                <span><?php echo esc_html__('Image', 'cats-carousel'); ?></span>
                            <?php endif; ?>
                            <form method="post" style="margin-top:8px;">
                                <?php wp_nonce_field('cats_carousel_remove'); ?>
                                <input type="hidden" name="cats_carousel_remove_id" value="<?php echo esc_attr((string) absint($id)); ?>" />
                                <button type="submit" class="button button-secondary"><?php echo esc_html__('Remove', 'cats-carousel'); ?></button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p><?php echo esc_html__('No images yet. Use the button below to add images.', 'cats-carousel'); ?></p>
                <?php endif; ?>
            </div>

            <hr />
            <h2><?php echo esc_html__('Add Images', 'cats-carousel'); ?></h2>
            <p><?php echo esc_html__('Select images from the Media Library to append to the carousel.', 'cats-carousel'); ?></p>
            <form method="post">
                <?php wp_nonce_field('cats_carousel_add'); ?>
                <input type="hidden" id="cats_carousel_new_ids" name="cats_carousel_new_ids" value="" />
                <button type="button" class="button button-primary" id="cats-carousel-select"><?php echo esc_html__('Select Images', 'cats-carousel'); ?></button>
                <button type="submit" class="button"><?php echo esc_html__('Add to Carousel', 'cats-carousel'); ?></button>
            </form>

            <script>
            (function($){
                $(function(){
                    var frame;
                    $('#cats-carousel-select').on('click', function(e){
                        e.preventDefault();
                        if (frame) {
                            frame.open();
                            return;
                        }
                        frame = wp.media({
                            title: <?php echo wp_json_encode(esc_html__('Select Images', 'cats-carousel')); ?>,
                            button: { text: <?php echo wp_json_encode(esc_html__('Add', 'cats-carousel')); ?> },
                            multiple: true,
                            library: { type: 'image' }
                        });
                        frame.on('select', function(){
                            var ids = [];
                            frame.state().get('selection').each(function(attachment){
                                ids.push(attachment.get('id'));
                            });
                            $('#cats_carousel_new_ids').val(ids.join(','));
                        });
                        frame.open();
                    });
                });
            })(jQuery);
            </script>

            <hr />
            <h2><?php echo esc_html__('Usage', 'cats-carousel'); ?></h2>
            <p><?php echo esc_html__('Insert the carousel anywhere using the shortcode:', 'cats-carousel'); ?> <code>[cats_carousel]</code></p>
        </div>
        <?php
    }

    public function get_images() {
        $ids = get_option($this->option_key, array());
        $ids = array_map('absint', $ids);
        $ids = array_filter($ids);
        return $ids;
    }

    public function render() {
        $ids = $this->get_images();
        $unique = 'cats-carousel-' . uniqid('', true);
        $unique_attr = esc_attr($unique);
        echo '<div class="cats-carousel" id="' . $unique_attr . '" data-interval="2000">';
        echo '<button class="cats-carousel__nav cats-carousel__nav--prev" aria-label="' . esc_attr__('Previous', 'cats-carousel') . '">&#10094;</button>';
        echo '<div class="cats-carousel__track">';
        if (!empty($ids)) {
            foreach ($ids as $id) {
                $url = wp_get_attachment_image_url($id, 'full');
                if (!$url) {
                    continue;
                }
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $alt = is_string($alt) ? $alt : '';
                echo '<div class="cats-carousel__slide">';
                echo '<img src="' . esc_url($url) . '" alt="' . esc_attr($alt) . '" loading="lazy" />';
                echo '</div>';
            }
        }
        echo '</div>';
        echo '<button class="cats-carousel__nav cats-carousel__nav--next" aria-label="' . esc_attr__('Next', 'cats-carousel') . '">&#10095;</button>';
        echo '</div>';
    }
}

// Initialize
Cats_Carousel::get_instance();
