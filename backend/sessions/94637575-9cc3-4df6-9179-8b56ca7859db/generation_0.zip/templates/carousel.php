<?php
if (!defined('ABSPATH')) {
    exit;
}
// This template is currently unused but provided for potential theme overrides in future versions.
?>
