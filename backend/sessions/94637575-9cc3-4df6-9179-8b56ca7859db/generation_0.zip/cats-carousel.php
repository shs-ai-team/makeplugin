<?php
/**
 * Plugin Name: Cats Carousel
 * Description: Full-width auto-scrolling cat image carousel with admin-managed images, placeable anywhere.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: cats-carousel
 * Domain Path: /languages
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('CATS_CAROUSEL_VERSION')) {
    define('CATS_CAROUSEL_VERSION', '1.0.0');
}
if (!defined('CATS_CAROUSEL_PLUGIN_FILE')) {
    define('CATS_CAROUSEL_PLUGIN_FILE', __FILE__);
}
if (!defined('CATS_CAROUSEL_PLUGIN_DIR')) {
    define('CATS_CAROUSEL_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('CATS_CAROUSEL_PLUGIN_URL')) {
    define('CATS_CAROUSEL_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Load text domain
function cats_carousel_load_textdomain() {
    load_plugin_textdomain('cats-carousel', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'cats_carousel_load_textdomain');

// Include core class
require_once CATS_CAROUSEL_PLUGIN_DIR . 'includes/class-cats-carousel.php';

// Activation: import bundled images and set defaults
function cats_carousel_activate() {
    if (!function_exists('wp_generate_attachment_metadata')) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
    $option_key = 'cats_carousel_image_ids';
    $existing = get_option($option_key);
    if (!is_array($existing)) {
        $existing = array();
    }

    $bundled_dir = CATS_CAROUSEL_PLUGIN_DIR . 'assets/images/';
    $files = array(
        'cat1.svg',
        'cat2.svg',
        'cat3.svg',
        'cat4.svg',
        'cat5.svg',
        'cat6.svg',
        'cat7.svg',
        'cat8.svg',
    );

    foreach ($files as $file) {
        $path = $bundled_dir . $file;
        if (!file_exists($path)) {
            continue;
        }
        // Skip if an attachment with this original filename already imported (basic dedupe by meta)
        $already = get_posts(array(
            'post_type'   => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 1,
            'meta_key'    => '_cats_carousel_source',
            'meta_value'  => wp_basename($path),
            'fields'      => 'ids',
        ));
        if (!empty($already)) {
            $att_id = absint($already[0]);
            if ($att_id && !in_array($att_id, $existing, true)) {
                $existing[] = $att_id;
            }
            continue;
        }

        $contents = file_get_contents($path);
        if ($contents === false) {
            continue;
        }
        $upload = wp_upload_bits(wp_basename($path), null, $contents);
        if ($upload && empty($upload['error'])) {
            $filetype = wp_check_filetype(wp_basename($path), null);
            $attachment = array(
                'post_mime_type' => isset($filetype['type']) ? $filetype['type'] : 'image/svg+xml',
                'post_title'     => sanitize_text_field(wp_basename($path)),
                'post_content'   => '',
                'post_status'    => 'inherit',
            );
            $attach_id = wp_insert_attachment($attachment, $upload['file']);
            if ($attach_id) {
                // SVGs don't generate metadata like sizes, but call for consistency
                $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
                if (!is_wp_error($attach_data)) {
                    wp_update_attachment_metadata($attach_id, $attach_data);
                }
                update_post_meta($attach_id, '_cats_carousel_source', wp_basename($path));
                if (!in_array($attach_id, $existing, true)) {
                    $existing[] = $attach_id;
                }
            }
        }
    }

    update_option($option_key, array_map('absint', $existing));
}
register_activation_hook(__FILE__, 'cats_carousel_activate');

// Shortcode
function cats_carousel_register_shortcode() {
    add_shortcode('cats_carousel', 'cats_carousel_shortcode_cb');
}
add_action('init', 'cats_carousel_register_shortcode');

function cats_carousel_shortcode_cb($atts) {
    $atts = shortcode_atts(array(), $atts, 'cats_carousel');
    ob_start();
    // Render via class method
    Cats_Carousel::get_instance()->render();
    return ob_get_clean();
}

// Template tag
function cats_carousel_render() {
    Cats_Carousel::get_instance()->render();
}
