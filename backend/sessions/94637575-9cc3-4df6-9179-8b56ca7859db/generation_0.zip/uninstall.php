<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data
$option_key = 'cats_carousel_image_ids';
$ids = get_option($option_key, array());
if (is_array($ids)) {
    $ids = array_map('absint', $ids);
}
// Do not delete attachments themselves; only remove our option.
delete_option($option_key);
