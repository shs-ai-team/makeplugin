<?php
/**
 * Forecast template
 *
 * Expects $days (sanitized array) and $title (escaped string) from SWF_Forecast::render()
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="swf-forecast" aria-live="polite">
    <h2 class="swf-title"><?php echo esc_html($title); ?></h2>
    <div class="swf-grid">
        <?php foreach ($days as $d) : ?>
            <div class="swf-day" tabindex="0">
                <div class="swf-day-head">
                    <span class="swf-day-name"><?php echo esc_html($d['day']); ?></span>
                    <span class="swf-day-date"><?php echo esc_html($d['date']); ?></span>
                </div>
                <div class="swf-icon" aria-hidden="true"><?php echo wp_kses_post($d['icon']); ?></div>
                <div class="swf-label"><?php echo esc_html($d['label']); ?></div>
                <div class="swf-temps">
                    <?php /* translators: %s: temperature in Celsius */ ?>
                    <span class="swf-temp-high" title="<?php echo esc_attr(sprintf(esc_html__('High: %s°C', 'swiss-weather-forecast'), esc_html($d['max']))); ?>">
                        <?php echo esc_html(sprintf(esc_html__('%s°C', 'swiss-weather-forecast'), (null !== $d['max'] ? round($d['max']) : ''))); ?>
                    </span>
                    <?php /* translators: %s: temperature in Celsius */ ?>
                    <span class="swf-temp-low" title="<?php echo esc_attr(sprintf(esc_html__('Low: %s°C', 'swiss-weather-forecast'), esc_html($d['min']))); ?>">
                        <?php echo esc_html(sprintf(esc_html__('%s°C', 'swiss-weather-forecast'), (null !== $d['min'] ? round($d['min']) : ''))); ?>
                    </span>
                </div>
                <div class="swf-pop">
                    <?php /* translators: %d: chance of precipitation percentage */ ?>
                    <span><?php echo esc_html(sprintf(esc_html__('%d%% chance of precip.', 'swiss-weather-forecast'), (null !== $d['pop'] ? absint($d['pop']) : 0))); ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
