<?php
/**
 * Core forecast class for Swiss Weather Forecast
 *
 * @package SwissWeatherForecast
 */

if (!defined('ABSPATH')) {
    exit;
}

class SWF_Forecast {
    /**
     * Singleton instance
     * @var SWF_Forecast|null
     */
    private static $instance = null;

    /**
     * Get instance
     * @return SWF_Forecast
     */
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Fetch and format forecast data
     * @return array|WP_Error
     */
    public function get_forecast() {
        $cached = get_transient('swf_forecast_data');
        if ($cached && is_array($cached)) {
            return $cached;
        }

        $lat = '47.3769';
        $lon = '8.5417';
        $params = array(
            'latitude'  => $lat,
            'longitude' => $lon,
            'daily'     => 'temperature_2m_max,temperature_2m_min,precipitation_probability_mean,weathercode',
            'timezone'  => 'Europe/Zurich',
            'forecast_days' => 5,
        );

        $url = add_query_arg($params, 'https://api.open-meteo.com/v1/forecast');

        $response = wp_remote_get($url, array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ((int) $code !== 200) {
            return new WP_Error('swf_http_error', esc_html__('Unable to retrieve weather data at the moment.', 'swiss-weather-forecast'));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!is_array($data) || empty($data['daily'])) {
            return new WP_Error('swf_bad_data', esc_html__('Weather data is temporarily unavailable.', 'swiss-weather-forecast'));
        }

        $daily = $data['daily'];
        $days = array();

        $count = min(5, isset($daily['time']) ? count($daily['time']) : 0);
        for ($i = 0; $i < $count; $i++) {
            $date_str = isset($daily['time'][$i]) ? sanitize_text_field($daily['time'][$i]) : '';
            $max = isset($daily['temperature_2m_max'][$i]) ? floatval($daily['temperature_2m_max'][$i]) : null;
            $min = isset($daily['temperature_2m_min'][$i]) ? floatval($daily['temperature_2m_min'][$i]) : null;
            $pop = isset($daily['precipitation_probability_mean'][$i]) ? intval($daily['precipitation_probability_mean'][$i]) : null;
            $wcode = isset($daily['weathercode'][$i]) ? intval($daily['weathercode'][$i]) : null;

            $label = $this->weathercode_label($wcode);
            $icon_svg = $this->weathercode_icon_svg($wcode);

            $days[] = array(
                'date' => $date_str,
                'max'  => $max,
                'min'  => $min,
                'pop'  => $pop,
                'label'=> $label,
                'icon' => $icon_svg,
            );
        }

        // Cache for 30 minutes
        set_transient('swf_forecast_data', $days, 30 * MINUTE_IN_SECONDS);

        return $days;
    }

    /**
     * Render forecast HTML
     * @return string
     */
    public function render() {
        $forecast = $this->get_forecast();

        if (is_wp_error($forecast)) {
            $message = $forecast->get_error_message();
            if (empty($message)) {
                $message = esc_html__('Weather data is temporarily unavailable.', 'swiss-weather-forecast');
            }
            $out  = '<div class="swf-forecast swf-error">';
            $out .= '<p>' . esc_html($message) . '</p>';
            $out .= '</div>';
            return $out;
        }

        if (empty($forecast)) {
            $out  = '<div class="swf-forecast swf-error">';
            $out .= '<p>' . esc_html__('Weather data is temporarily unavailable.', 'swiss-weather-forecast') . '</p>';
            $out .= '</div>';
            return $out;
        }

        ob_start();
        $days = $this->sanitize_days($forecast);
        $title = esc_html__('Zurich 5‑day Forecast', 'swiss-weather-forecast');
        include SWF_PLUGIN_DIR . 'templates/forecast.php';
        $html = ob_get_clean();
        return $html;
    }

    /**
     * Sanitize days array for template
     * @param array $days
     * @return array
     */
    private function sanitize_days($days) {
        $out = array();
        foreach ($days as $d) {
            $date = isset($d['date']) ? sanitize_text_field($d['date']) : '';
            $timestamp = strtotime($date);
            $day_label = $timestamp ? date_i18n('D', $timestamp) : '';
            $date_disp = $timestamp ? date_i18n(get_option('date_format', 'M j'), $timestamp) : '';

            $max = isset($d['max']) ? floatval($d['max']) : null;
            $min = isset($d['min']) ? floatval($d['min']) : null;
            $pop = isset($d['pop']) ? absint($d['pop']) : null;
            $label = isset($d['label']) ? sanitize_text_field($d['label']) : '';
            $icon = isset($d['icon']) ? $this->sanitize_svg($d['icon']) : '';

            $out[] = array(
                'day'  => $day_label,
                'date' => $date_disp,
                'max'  => $max,
                'min'  => $min,
                'pop'  => $pop,
                'label'=> $label,
                'icon' => $icon,
            );
        }
        return $out;
    }

    /**
     * Map Open-Meteo WMO weather codes to labels
     * @param int|null $code
     * @return string
     */
    private function weathercode_label($code) {
        $map = array(
            0 => esc_html__('Clear', 'swiss-weather-forecast'),
            1 => esc_html__('Mainly clear', 'swiss-weather-forecast'),
            2 => esc_html__('Partly cloudy', 'swiss-weather-forecast'),
            3 => esc_html__('Overcast', 'swiss-weather-forecast'),
            45 => esc_html__('Fog', 'swiss-weather-forecast'),
            48 => esc_html__('Depositing rime fog', 'swiss-weather-forecast'),
            51 => esc_html__('Light drizzle', 'swiss-weather-forecast'),
            53 => esc_html__('Moderate drizzle', 'swiss-weather-forecast'),
            55 => esc_html__('Dense drizzle', 'swiss-weather-forecast'),
            56 => esc_html__('Light freezing drizzle', 'swiss-weather-forecast'),
            57 => esc_html__('Freezing drizzle', 'swiss-weather-forecast'),
            61 => esc_html__('Light rain', 'swiss-weather-forecast'),
            63 => esc_html__('Moderate rain', 'swiss-weather-forecast'),
            65 => esc_html__('Heavy rain', 'swiss-weather-forecast'),
            66 => esc_html__('Light freezing rain', 'swiss-weather-forecast'),
            67 => esc_html__('Freezing rain', 'swiss-weather-forecast'),
            71 => esc_html__('Light snow', 'swiss-weather-forecast'),
            73 => esc_html__('Snow', 'swiss-weather-forecast'),
            75 => esc_html__('Heavy snow', 'swiss-weather-forecast'),
            77 => esc_html__('Snow grains', 'swiss-weather-forecast'),
            80 => esc_html__('Light showers', 'swiss-weather-forecast'),
            81 => esc_html__('Showers', 'swiss-weather-forecast'),
            82 => esc_html__('Heavy showers', 'swiss-weather-forecast'),
            85 => esc_html__('Light snow showers', 'swiss-weather-forecast'),
            86 => esc_html__('Snow showers', 'swiss-weather-forecast'),
            95 => esc_html__('Thunderstorm', 'swiss-weather-forecast'),
            96 => esc_html__('Thunderstorm with hail', 'swiss-weather-forecast'),
            99 => esc_html__('Thunderstorm with heavy hail', 'swiss-weather-forecast'),
        );
        if ($code === null) {
            return esc_html__('Unknown', 'swiss-weather-forecast');
        }
        return isset($map[$code]) ? $map[$code] : esc_html__('Unknown', 'swiss-weather-forecast');
    }

    /**
     * Return simple SVG icon for given code
     * @param int|null $code
     * @return string SVG markup
     */
    private function weathercode_icon_svg($code) {
        $type = 'sun';
        if (is_int($code)) {
            if (in_array($code, array(0,1), true)) {
                $type = 'sun';
            } elseif (in_array($code, array(2,3,45,48), true)) {
                $type = 'cloud';
            } elseif (in_array($code, array(51,53,55,56,57,61,63,65,66,67,80,81,82), true)) {
                $type = 'rain';
            } elseif (in_array($code, array(71,73,75,77,85,86), true)) {
                $type = 'snow';
            } elseif (in_array($code, array(95,96,99), true)) {
                $type = 'storm';
            }
        }

        // Minimal inline SVGs with currentColor, accessible title
        /* translators: %s: weather icon type */
        $title = sprintf(esc_html__('%s icon', 'swiss-weather-forecast'), ucfirst($type));

        if ('cloud' === $type) {
            return '<svg class="swf-ico swf-ico-cloud" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr($title) . '" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M20 48h28a12 12 0 0 0 0-24 15 15 0 0 0-29-2 10 10 0 0 0 1 20z"/></svg>';
        }
        if ('rain' === $type) {
            return '<svg class="swf-ico swf-ico-rain" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr($title) . '" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M20 40h26a10 10 0 0 0 0-20 13 13 0 0 0-25-2 9 9 0 0 0-1 22z"/><g fill="currentColor"><path d="M22 48l-2 6"/><path d="M30 48l-2 6"/><path d="M38 48l-2 6"/><path d="M46 48l-2 6"/></g></svg>';
        }
        if ('snow' === $type) {
            return '<svg class="swf-ico swf-ico-snow" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr($title) . '" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M20 40h26a10 10 0 0 0 0-20 13 13 0 0 0-25-2 9 9 0 0 0-1 22z"/><g fill="currentColor"><circle cx="24" cy="50" r="2"/><circle cx="32" cy="50" r="2"/><circle cx="40" cy="50" r="2"/></g></svg>';
        }
        if ('storm' === $type) {
            return '<svg class="swf-ico swf-ico-storm" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr($title) . '" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M20 38h26a10 10 0 0 0 0-20 13 13 0 0 0-25-2 9 9 0 0 0-1 22z"/><path fill="currentColor" d="M32 40l-6 12h6l-2 10 10-14h-6l4-8z"/></svg>';
        }
        // sun
        return '<svg class="swf-ico swf-ico-sun" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr($title) . '" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="12" fill="currentColor"/><g stroke="currentColor" stroke-width="4"><line x1="32" y1="4" x2="32" y2="14"/><line x1="32" y1="50" x2="32" y2="60"/><line x1="4" y1="32" x2="14" y2="32"/><line x1="50" y1="32" x2="60" y2="32"/><line x1="12" y1="12" x2="18" y2="18"/><line x1="46" y1="46" x2="52" y2="52"/><line x1="12" y1="52" x2="18" y2="46"/><line x1="46" y1="18" x2="52" y2="12"/></g></svg>';
    }

    /**
     * Sanitize limited SVG subset
     * @param string $svg
     * @return string
     */
    private function sanitize_svg($svg) {
        $allowed = array(
            'svg' => array(
                'class' => true,
                'viewBox' => true,
                'role' => true,
                'aria-label' => true,
                'xmlns' => true,
                'width' => true,
                'height' => true,
            ),
            'path' => array(
                'fill' => true,
                'd' => true,
                'stroke' => true,
                'stroke-width' => true,
            ),
            'circle' => array(
                'cx' => true,
                'cy' => true,
                'r' => true,
                'fill' => true,
            ),
            'g' => array(
                'fill' => true,
                'stroke' => true,
                'stroke-width' => true,
            ),
            'line' => array(
                'x1' => true,
                'y1' => true,
                'x2' => true,
                'y2' => true,
                'stroke' => true,
                'stroke-width' => true,
            ),
        );
        return wp_kses($svg, $allowed);
    }
}
