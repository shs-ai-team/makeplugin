=== Swiss Weather Forecast ===
Contributors: makeplugin
Tags: weather, forecast, zurich, switzerland, climate, widget, homepage
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Shows a 5‑day Zurich weather forecast on the homepage.

== Description ==
Swiss Weather Forecast is a lightweight plugin that displays a clean, responsive 5‑day weather forecast for Zurich, Switzerland (English). It automatically appears in the main content area of your homepage, showing per‑day: high/low temperatures (°C), a weather icon, a short condition label, and chance of precipitation. Data is fetched from Open‑Meteo and cached to keep your site fast. If data is temporarily unavailable, a friendly message is shown.

== Installation ==
1. Upload the `swiss-weather-forecast` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Visit your homepage to see the forecast automatically appended to the main content.

== Frequently Asked Questions ==
= Do I need an API key? =
No. The plugin uses Open-Meteo, which does not require an API key.

= Can I change the city/location? =
This version is fixed to Zurich to keep things simple and fast.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
