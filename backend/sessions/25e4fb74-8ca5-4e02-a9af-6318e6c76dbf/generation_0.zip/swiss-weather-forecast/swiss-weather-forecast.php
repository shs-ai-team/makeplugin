<?php
/**
 * Plugin Name: Swiss Weather Forecast
 * Description: Shows a 5‑day Zurich weather forecast on the homepage.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: swiss-weather-forecast
 * License: GPLv2 or later
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('SWF_VERSION')) {
    define('SWF_VERSION', '1.0.0');
}
if (!defined('SWF_PLUGIN_FILE')) {
    define('SWF_PLUGIN_FILE', __FILE__);
}
if (!defined('SWF_PLUGIN_DIR')) {
    define('SWF_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('SWF_PLUGIN_URL')) {
    define('SWF_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Load textdomain
function swf_load_textdomain() {
    load_plugin_textdomain('swiss-weather-forecast', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'swf_load_textdomain');

// Include core class
require_once SWF_PLUGIN_DIR . 'includes/class-swf-forecast.php';

// Enqueue styles on front-end
function swf_enqueue_assets() {
    if (!is_admin() && is_front_page()) {
        wp_enqueue_style(
            'swf-style',
            SWF_PLUGIN_URL . 'assets/css/style.css',
            array(),
            SWF_VERSION
        );
    }
}
add_action('wp_enqueue_scripts', 'swf_enqueue_assets');

// Inject forecast into homepage content
function swf_inject_forecast_into_home($content) {
    if (!is_front_page() || is_admin()) {
        return $content;
    }

    static $did_inject = false;
    if ($did_inject) {
        return $content;
    }

    $did_inject = true;

    $forecast_html = SWF_Forecast::instance()->render();

    if (!empty($forecast_html)) {
        // Prepend forecast to the main content
        $content = $forecast_html . $content;
    }

    return $content;
}
add_filter('the_content', 'swf_inject_forecast_into_home', 20);
