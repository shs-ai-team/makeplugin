<?php
/**
 * Plugin Name: Cat Carousel
 * Description: Autoplaying cat image carousel on the homepage.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: cat-carousel
 * Domain Path: /languages
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('CAT_CAROUSEL_VERSION')) {
    define('CAT_CAROUSEL_VERSION', '1.0.0');
}

if (!defined('CAT_CAROUSEL_PATH')) {
    define('CAT_CAROUSEL_PATH', plugin_dir_path(__FILE__));
}

if (!defined('CAT_CAROUSEL_URL')) {
    define('CAT_CAROUSEL_URL', plugin_dir_url(__FILE__));
}

// Load text domain
function cat_carousel_load_textdomain() {
    load_plugin_textdomain('cat-carousel', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'cat_carousel_load_textdomain');

// Includes
require_once CAT_CAROUSEL_PATH . 'includes/helpers.php';
require_once CAT_CAROUSEL_PATH . 'includes/class-cat-carousel.php';
require_once CAT_CAROUSEL_PATH . 'includes/admin-settings.php';

// Enqueue front-end assets only on front page/home
function cat_carousel_enqueue_assets() {
    if (!(is_front_page() || is_home())) {
        return;
    }

    wp_enqueue_style(
        'cat-carousel-style',
        CAT_CAROUSEL_URL . 'assets/css/style.css',
        array(),
        CAT_CAROUSEL_VERSION
    );

    wp_enqueue_script(
        'cat-carousel-js',
        CAT_CAROUSEL_URL . 'assets/js/carousel.js',
        array('jquery'),
        CAT_CAROUSEL_VERSION,
        true
    );

    $settings = cat_carousel_get_settings();

    wp_localize_script(
        'cat-carousel-js',
        'CatCarouselSettings',
        array(
            'autoplay' => (bool) $settings['autoplay'],
            'speed' => (int) $settings['autoplay_speed'],
            'showArrows' => (bool) $settings['show_arrows'],
            'showDots' => (bool) $settings['show_dots']
        )
    );
}
add_action('wp_enqueue_scripts', 'cat_carousel_enqueue_assets');

// Render carousel at bottom of homepage (above footer)
function cat_carousel_render_on_home() {
    if (!(is_front_page() || is_home())) {
        return;
    }

    $carousel = new Cat_Carousel_Main();
    $images = $carousel->get_images();

    if (is_wp_error($images) || empty($images)) {
        return;
    }

    $settings = cat_carousel_get_settings();

    $data = array(
        'images' => $images,
        'settings' => $settings
    );

    // Template output
    $template = CAT_CAROUSEL_PATH . 'templates/carousel.php';
    if (file_exists($template)) {
        include $template;
    }
}
add_action('wp_footer', 'cat_carousel_render_on_home', 5);

// Settings link on plugins page
function cat_carousel_plugin_action_links($links) {
    $url = admin_url('options-general.php?page=cat-carousel');
    $settings_link = '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'cat-carousel') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'cat_carousel_plugin_action_links');
