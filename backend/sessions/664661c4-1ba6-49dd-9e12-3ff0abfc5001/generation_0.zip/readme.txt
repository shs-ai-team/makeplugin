=== Cat Carousel ===
Contributors: makeplugin
Tags: carousel, slider, images, cats, homepage, unsplash
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Autoplaying cat image carousel on the homepage.

== Description ==
Display a responsive, looping carousel of cat images automatically at the bottom of the homepage, just above the footer. Images are fetched from Unsplash (API optional) and show subtle attribution when available. The carousel autoplays by default (3s per slide), pauses on hover, and includes next/previous arrows and dots. Includes a settings screen to control image source/API key, number of images (default 10), autoplay on/off, autoplay speed, and toggles for arrows/dots. Does not affect other pages.

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/cat-carousel directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to Settings -> Cat Carousel to configure options.

== Frequently Asked Questions ==
= Do I need an Unsplash API key? =
No. By default, the plugin uses the Unsplash random image source. If you provide an Unsplash Access Key and choose the API source, the plugin will fetch images with detailed alt text and author attribution.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
