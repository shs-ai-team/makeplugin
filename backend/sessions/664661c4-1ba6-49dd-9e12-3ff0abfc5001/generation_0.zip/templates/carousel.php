<?php
if (!defined('ABSPATH')) {
    exit;
}
/** @var array $data */
$images = isset($data['images']) && is_array($data['images']) ? $data['images'] : array();
$settings = isset($data['settings']) && is_array($data['settings']) ? $data['settings'] : cat_carousel_get_settings();
$show_arrows = !empty($settings['show_arrows']);
$show_dots = !empty($settings['show_dots']);
?>
<div class="cat-carousel-wrapper" aria-label="<?php echo esc_attr__('Cat Carousel', 'cat-carousel'); ?>">
    <div class="cat-carousel" role="region">
        <div class="cat-carousel-track" aria-live="polite">
            <?php foreach ($images as $img) :
                $url = isset($img['url']) ? $img['url'] : '';
                $alt = isset($img['alt']) ? $img['alt'] : '';
                $credit_name = isset($img['credit_name']) ? $img['credit_name'] : '';
                $credit_url = isset($img['credit_url']) ? $img['credit_url'] : '';
                $source = isset($img['source']) ? $img['source'] : '';
            ?>
            <div class="cat-carousel-slide">
                <img src="<?php echo esc_url($url); ?>" alt="<?php echo esc_attr($alt); ?>" loading="lazy" />
                <?php if (!empty($credit_name) || !empty($source)) : ?>
                    <div class="cat-carousel-credit">
                        <?php if (!empty($credit_name) && !empty($credit_url)) : ?>
                            <?php /* translators: 1: photographer name, 2: source name */ ?>
                            <a href="<?php echo esc_url($credit_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($credit_name); ?></a> · <?php echo esc_html($source); ?>
                        <?php else : ?>
                            <?php echo esc_html($source); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if ($show_arrows) : ?>
            <button class="cat-carousel-arrow prev" aria-label="<?php echo esc_attr__('Previous', 'cat-carousel'); ?>" type="button">&#10094;</button>
            <button class="cat-carousel-arrow next" aria-label="<?php echo esc_attr__('Next', 'cat-carousel'); ?>" type="button">&#10095;</button>
        <?php endif; ?>
    </div>
    <?php if ($show_dots) : ?>
        <div class="cat-carousel-dots" role="tablist">
            <?php foreach ($images as $i => $img) : ?>
                <button class="cat-carousel-dot<?php echo $i === 0 ? ' active' : ''; ?>" data-index="<?php echo esc_attr((string) $i); ?>" aria-label="<?php /* translators: %d: slide number */ printf(esc_attr__('Go to slide %d', 'cat-carousel'), (int) ($i + 1)); ?>" type="button"></button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
