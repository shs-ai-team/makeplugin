<?php
if (!defined('ABSPATH')) {
    exit;
}

function cat_carousel_default_settings() {
    return array(
        'image_source'   => 'unsplash_source', // unsplash_source | unsplash_api
        'unsplash_key'   => '',
        'image_count'    => 10,
        'autoplay'       => 1,
        'autoplay_speed' => 3000,
        'show_arrows'    => 1,
        'show_dots'      => 1,
    );
}

function cat_carousel_get_settings() {
    $defaults = cat_carousel_default_settings();
    $options = get_option('cat_carousel_settings', array());
    if (!is_array($options)) {
        $options = array();
    }
    $settings = wp_parse_args($options, $defaults);

    // Type cast and clamp values safely
    $settings['image_source'] = in_array($settings['image_source'], array('unsplash_source', 'unsplash_api'), true) ? $settings['image_source'] : 'unsplash_source';
    $settings['unsplash_key'] = is_string($settings['unsplash_key']) ? $settings['unsplash_key'] : '';
    $settings['image_count'] = max(1, min(30, absint($settings['image_count'])));
    $settings['autoplay'] = (int) (bool) $settings['autoplay'];
    $settings['autoplay_speed'] = max(1000, min(20000, absint($settings['autoplay_speed'])));
    $settings['show_arrows'] = (int) (bool) $settings['show_arrows'];
    $settings['show_dots'] = (int) (bool) $settings['show_dots'];

    return $settings;
}

function cat_carousel_build_transient_key($settings) {
    $key_data = array(
        'src' => $settings['image_source'],
        'cnt' => (int) $settings['image_count'],
        'key' => !empty($settings['unsplash_key']) ? '1' : '0',
        'v'   => CAT_CAROUSEL_VERSION,
    );
    return 'cat_carousel_images_' . md5(wp_json_encode($key_data));
}
