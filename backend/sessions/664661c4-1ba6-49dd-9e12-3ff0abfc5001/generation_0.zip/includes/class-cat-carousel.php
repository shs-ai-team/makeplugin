<?php
if (!defined('ABSPATH')) {
    exit;
}

class Cat_Carousel_Main {

    public function get_images() {
        $settings = cat_carousel_get_settings();
        $transient_key = cat_carousel_build_transient_key($settings);

        $cached = get_transient($transient_key);
        if ($cached && is_array($cached)) {
            return $cached;
        }

        if ($settings['image_source'] === 'unsplash_api' && !empty($settings['unsplash_key'])) {
            $images = $this->fetch_unsplash_api($settings);
        } else {
            $images = $this->generate_unsplash_source($settings);
        }

        if (is_wp_error($images)) {
            return $images;
        }

        if (!empty($images)) {
            set_transient($transient_key, $images, 6 * HOUR_IN_SECONDS);
        }

        return $images;
    }

    private function fetch_unsplash_api($settings) {
        $count = (int) $settings['image_count'];

        $endpoint = add_query_arg(
            array(
                'query' => 'cat',
                'per_page' => $count,
                'orientation' => 'landscape'
            ),
            'https://api.unsplash.com/search/photos'
        );

        $args = array(
            'headers' => array(
                'Authorization' => 'Client-ID ' . $settings['unsplash_key']
            ),
            'timeout' => 15
        );

        $response = wp_remote_get($endpoint, $args);
        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            /* translators: %d: HTTP status code */
            return new WP_Error('unsplash_api_error', sprintf(esc_html__('Unsplash API returned status %d.', 'cat-carousel'), (int) $code));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data) || !isset($data['results'])) {
            return new WP_Error('unsplash_api_invalid', esc_html__('Invalid response from Unsplash API.', 'cat-carousel'));
        }

        $images = array();
        foreach ($data['results'] as $item) {
            if (!is_array($item) || empty($item['urls']['regular'])) {
                continue;
            }
            $alt = '';
            if (!empty($item['alt_description'])) {
                $alt = wp_strip_all_tags((string) $item['alt_description']);
            } elseif (!empty($item['description'])) {
                $alt = wp_strip_all_tags((string) $item['description']);
            } else {
                $alt = esc_html__('Cat image from Unsplash', 'cat-carousel');
            }

            $author_name = '';
            $author_url = '';
            if (!empty($item['user']['name'])) {
                $author_name = (string) $item['user']['name'];
            }
            if (!empty($item['user']['links']['html'])) {
                $author_url = (string) $item['user']['links']['html'];
            }

            $images[] = array(
                'url' => esc_url_raw((string) $item['urls']['regular']),
                'alt' => $alt,
                'credit_name' => $author_name,
                'credit_url' => esc_url_raw($author_url),
                'source' => 'Unsplash'
            );
        }

        return $images;
    }

    private function generate_unsplash_source($settings) {
        $count = (int) $settings['image_count'];
        $images = array();
        for ($i = 0; $i < $count; $i++) {
            $url = add_query_arg(
                array(
                    'cat' => null,
                    'sig' => $i + 1
                ),
                'https://source.unsplash.com/featured/1200x800/?cat'
            );
            $images[] = array(
                'url' => esc_url_raw($url),
                'alt' => esc_html__('Random cat image', 'cat-carousel'),
                'credit_name' => '',
                'credit_url' => '',
                'source' => 'Unsplash'
            );
        }
        return $images;
    }
}
