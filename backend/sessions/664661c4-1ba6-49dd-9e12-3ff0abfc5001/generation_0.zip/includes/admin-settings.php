<?php
if (!defined('ABSPATH')) {
    exit;
}

function cat_carousel_register_settings() {
    register_setting(
        'cat_carousel_settings_group',
        'cat_carousel_settings',
        array(
            'type' => 'array',
            'sanitize_callback' => 'cat_carousel_sanitize_settings',
            'default' => cat_carousel_default_settings(),
        )
    );

    add_settings_section(
        'cat_carousel_main_section',
        esc_html__('Carousel Settings', 'cat-carousel'),
        function () {
            echo '<p>' . esc_html__('Configure the Cat Carousel displayed on the homepage.', 'cat-carousel') . '</p>';
        },
        'cat_carousel_settings_page'
    );

    add_settings_field(
        'image_source',
        esc_html__('Image Source', 'cat-carousel'),
        'cat_carousel_field_image_source',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'unsplash_key',
        esc_html__('Unsplash Access Key', 'cat-carousel'),
        'cat_carousel_field_unsplash_key',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'image_count',
        esc_html__('Number of Images', 'cat-carousel'),
        'cat_carousel_field_image_count',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'autoplay',
        esc_html__('Autoplay', 'cat-carousel'),
        'cat_carousel_field_autoplay',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'autoplay_speed',
        esc_html__('Autoplay Speed (ms)', 'cat-carousel'),
        'cat_carousel_field_autoplay_speed',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'show_arrows',
        esc_html__('Show Arrows', 'cat-carousel'),
        'cat_carousel_field_show_arrows',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );

    add_settings_field(
        'show_dots',
        esc_html__('Show Dots', 'cat-carousel'),
        'cat_carousel_field_show_dots',
        'cat_carousel_settings_page',
        'cat_carousel_main_section'
    );
}
add_action('admin_init', 'cat_carousel_register_settings');

function cat_carousel_add_settings_page() {
    add_options_page(
        esc_html__('Cat Carousel', 'cat-carousel'),
        esc_html__('Cat Carousel', 'cat-carousel'),
        'manage_options',
        'cat-carousel',
        'cat_carousel_render_settings_page'
    );
}
add_action('admin_menu', 'cat_carousel_add_settings_page');

function cat_carousel_render_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'cat-carousel'));
    }
    $settings = cat_carousel_get_settings();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Cat Carousel Settings', 'cat-carousel'); ?></h1>
        <form action="<?php echo esc_url(admin_url('options.php')); ?>" method="post">
            <?php
            settings_fields('cat_carousel_settings_group');
            do_settings_sections('cat_carousel_settings_page');
            submit_button(esc_html__('Save Changes', 'cat-carousel'));
            ?>
        </form>
        <p class="description">
            <?php echo esc_html__('Tip: For detailed credits and alt text, use the Unsplash API with an Access Key. Otherwise, the random source will be used without individual author credits.', 'cat-carousel'); ?>
        </p>
    </div>
    <?php
}

function cat_carousel_field_image_source() {
    $settings = cat_carousel_get_settings();
    ?>
    <select name="cat_carousel_settings[image_source]">
        <option value="unsplash_source" <?php selected($settings['image_source'], 'unsplash_source'); ?>><?php echo esc_html__('Unsplash Random (no key)', 'cat-carousel'); ?></option>
        <option value="unsplash_api" <?php selected($settings['image_source'], 'unsplash_api'); ?>><?php echo esc_html__('Unsplash API (requires key)', 'cat-carousel'); ?></option>
    </select>
    <?php
}

function cat_carousel_field_unsplash_key() {
    $settings = cat_carousel_get_settings();
    ?>
    <input type="text" class="regular-text" name="cat_carousel_settings[unsplash_key]" value="<?php echo esc_attr($settings['unsplash_key']); ?>" placeholder="<?php echo esc_attr__('Your Unsplash Access Key', 'cat-carousel'); ?>" />
    <p class="description"><?php echo esc_html__('Only required if using Unsplash API source.', 'cat-carousel'); ?></p>
    <?php
}

function cat_carousel_field_image_count() {
    $settings = cat_carousel_get_settings();
    ?>
    <input type="number" min="1" max="30" name="cat_carousel_settings[image_count]" value="<?php echo esc_attr((string) $settings['image_count']); ?>" />
    <?php
}

function cat_carousel_field_autoplay() {
    $settings = cat_carousel_get_settings();
    ?>
    <label>
        <input type="checkbox" name="cat_carousel_settings[autoplay]" value="1" <?php checked(1, (int) $settings['autoplay']); ?> />
        <?php echo esc_html__('Enable autoplay', 'cat-carousel'); ?>
    </label>
    <?php
}

function cat_carousel_field_autoplay_speed() {
    $settings = cat_carousel_get_settings();
    ?>
    <input type="number" min="1000" max="20000" step="100" name="cat_carousel_settings[autoplay_speed]" value="<?php echo esc_attr((string) $settings['autoplay_speed']); ?>" />
    <p class="description"><?php echo esc_html__('Milliseconds between slides (default 3000).', 'cat-carousel'); ?></p>
    <?php
}

function cat_carousel_field_show_arrows() {
    $settings = cat_carousel_get_settings();
    ?>
    <label>
        <input type="checkbox" name="cat_carousel_settings[show_arrows]" value="1" <?php checked(1, (int) $settings['show_arrows']); ?> />
        <?php echo esc_html__('Show next/previous arrows', 'cat-carousel'); ?>
    </label>
    <?php
}

function cat_carousel_field_show_dots() {
    $settings = cat_carousel_get_settings();
    ?>
    <label>
        <input type="checkbox" name="cat_carousel_settings[show_dots]" value="1" <?php checked(1, (int) $settings['show_dots']); ?> />
        <?php echo esc_html__('Show pagination dots', 'cat-carousel'); ?>
    </label>
    <?php
}

function cat_carousel_sanitize_settings($input) {
    $defaults = cat_carousel_default_settings();
    $output = array();

    // Image source
    $source = isset($input['image_source']) ? sanitize_text_field($input['image_source']) : $defaults['image_source'];
    $output['image_source'] = in_array($source, array('unsplash_source', 'unsplash_api'), true) ? $source : $defaults['image_source'];

    // Unsplash key
    $output['unsplash_key'] = isset($input['unsplash_key']) ? sanitize_text_field($input['unsplash_key']) : '';

    // Counts and numbers
    $output['image_count'] = isset($input['image_count']) ? max(1, min(30, absint($input['image_count']))) : $defaults['image_count'];
    $output['autoplay_speed'] = isset($input['autoplay_speed']) ? max(1000, min(20000, absint($input['autoplay_speed']))) : $defaults['autoplay_speed'];

    // Booleans
    $output['autoplay'] = !empty($input['autoplay']) ? 1 : 0;
    $output['show_arrows'] = !empty($input['show_arrows']) ? 1 : 0;
    $output['show_dots'] = !empty($input['show_dots']) ? 1 : 0;

    // Clear image cache transient on significant changes
    $settings_before = cat_carousel_get_settings();
    if (
        $settings_before['image_source'] !== $output['image_source'] ||
        $settings_before['unsplash_key'] !== $output['unsplash_key'] ||
        (int) $settings_before['image_count'] !== (int) $output['image_count']
    ) {
        // Attempt to delete any transients for image cache
        global $wpdb;
        $like = $wpdb->esc_like('cat_carousel_images_') . '%';
        $wpdb->query($wpdb->prepare('DELETE FROM ' . $wpdb->options . ' WHERE option_name LIKE %s OR option_name LIKE %s', '_transient_' . $like, '_transient_timeout_' . $like));
    }

    return $output;
}
