(function($){
    'use strict';

    function CatCarousel($el, options){
        this.$el = $el;
        this.$track = $el.find('.cat-carousel-track');
        this.$slides = $el.find('.cat-carousel-slide');
        this.$dots = $el.find('.cat-carousel-dots');
        this.index = 0;
        this.count = this.$slides.length;
        this.opts = $.extend({autoplay:true,speed:3000,showArrows:true,showDots:true}, options || {});
        this.timer = null;
        this.bind();
        this.update();
        if(this.opts.autoplay){ this.play(); }
    }

    CatCarousel.prototype.bind = function(){
        var self = this;
        this.$el.on('mouseenter', function(){ self.pause(); });
        this.$el.on('mouseleave', function(){ if(self.opts.autoplay){ self.play(); } });
        this.$el.find('.cat-carousel-arrow.prev').on('click', function(e){ e.preventDefault(); self.prev(); });
        this.$el.find('.cat-carousel-arrow.next').on('click', function(e){ e.preventDefault(); self.next(); });
        this.$dots.on('click', '.cat-carousel-dot', function(){
            var i = parseInt($(this).attr('data-index'), 10);
            if(!isNaN(i)){ self.go(i); }
        });
        $(window).on('resize', function(){ self.update(); });
    };

    CatCarousel.prototype.update = function(){
        var offset = -this.index * this.$el.width();
        this.$track.css('transform', 'translateX(' + offset + 'px)');
        this.$dots.find('.cat-carousel-dot').removeClass('active');
        this.$dots.find('.cat-carousel-dot[data-index="' + this.index + '"]').addClass('active');
    };

    CatCarousel.prototype.next = function(){
        this.index = (this.index + 1) % this.count;
        this.update();
    };

    CatCarousel.prototype.prev = function(){
        this.index = (this.index - 1 + this.count) % this.count;
        this.update();
    };

    CatCarousel.prototype.go = function(i){
        if(i >= 0 && i < this.count){
            this.index = i;
            this.update();
        }
    };

    CatCarousel.prototype.play = function(){
        var self = this;
        this.pause();
        this.timer = setInterval(function(){ self.next(); }, parseInt(this.opts.speed, 10) || 3000);
    };

    CatCarousel.prototype.pause = function(){
        if(this.timer){ clearInterval(this.timer); this.timer = null; }
    };

    $(function(){
        var settings = window.CatCarouselSettings || {autoplay:true,speed:3000,showArrows:true,showDots:true};
        $('.cat-carousel').each(function(){
            new CatCarousel($(this), settings);
        });
    });

})(jQuery);
