<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options
delete_option('cat_carousel_settings');

// Remove transients related to cat carousel
global $wpdb;
$like = $wpdb->esc_like('cat_carousel_images_') . '%';
$wpdb->query($wpdb->prepare('DELETE FROM ' . $wpdb->options . ' WHERE option_name LIKE %s OR option_name LIKE %s', '_transient_' . $like, '_transient_timeout_' . $like));
