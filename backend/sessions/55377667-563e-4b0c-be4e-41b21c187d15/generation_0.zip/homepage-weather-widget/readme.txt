=== Homepage Weather Widget ===
Contributors: makeplugin
Tags: weather, widget, homepage, zurich, temperature, forecast
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
Requires PHP: 7.4

Simple weather widget for the homepage.

== Description ==
Add a compact weather widget to the homepage that displays the current temperature, today’s high and low, a brief condition label, and a matching icon for Zurich, Switzerland. The widget uses Celsius only, updates roughly every 30 minutes, handles outages gracefully with a friendly fallback message, and loads quickly with minimal styling to blend into your theme. Use the built-in widget or the [homepage_weather_widget] shortcode.

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/homepage-weather-widget directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the \"Plugins\" screen in WordPress.
3. Add the \"Homepage Weather Widget\" to a widget area or use the [homepage_weather_widget] shortcode.

== Frequently Asked Questions ==
= Does this support changing the city or units? =
No. It is fixed to Zurich, Switzerland and uses Celsius only.

= How often is the weather updated? =
About every 30 minutes via WordPress transients.

== Changelog ==
= 1.0.0 =
* Initial release.
