<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data
// Delete transients
if (function_exists('delete_transient')) {
    delete_transient('hww_weather_data');
}
