<?php
if (!defined('ABSPATH')) {
    exit;
}

$has_error = !empty($context['error']);
?>
<div class="hww-widget" role="group" aria-label="<?php echo esc_attr__('Zurich weather', 'homepage-weather-widget'); ?>">
    <?php if ($has_error) : ?>
        <div class="hww-error"><?php echo esc_html(isset($context['message']) ? $context['message'] : esc_html__('Weather is currently unavailable for Zurich. Please try again later.', 'homepage-weather-widget')); ?></div>
    <?php else : ?>
        <img class="hww-icon" src="<?php echo esc_url(isset($context['icon_url']) ? $context['icon_url'] : ''); ?>" alt="<?php echo esc_attr(isset($context['label']) ? $context['label'] : ''); ?>" />
        <div class="hww-meta">
            <div class="hww-row">
                <span class="hww-temp"><?php echo esc_html(number_format_i18n(floatval($context['temperature']), 0)); ?></span>
                <span class="hww-unit"><?php echo esc_html__('°C', 'homepage-weather-widget'); ?></span>
                <span class="hww-label"><?php echo esc_html($context['label']); ?></span>
            </div>
            <div class="hww-row hww-range">
                <?php /* translators: %1$s: low temp, %2$s: high temp */ ?>
                <span><?php echo esc_html(sprintf(esc_html__('L %1$s° / H %2$s°', 'homepage-weather-widget'), number_format_i18n(floatval($context['low']), 0), number_format_i18n(floatval($context['high']), 0))); ?></span>
            </div>
        </div>
    <?php endif; ?>
</div>
