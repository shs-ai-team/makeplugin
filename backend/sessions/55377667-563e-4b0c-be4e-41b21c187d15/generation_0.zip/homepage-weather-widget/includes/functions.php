<?php
if (!defined('ABSPATH')) {
    exit;
}

function hww_get_widget_markup($context) {
    ob_start();
    include HWW_PLUGIN_DIR . 'templates/widget.php';
    $html = ob_get_clean();
    return $html;
}

// Shortcode: [homepage_weather_widget]
function hww_shortcode_render($atts) {
    $atts = shortcode_atts(array(), $atts, 'homepage_weather_widget');

    $service = new HWW_Weather_Service();
    $data = $service->get_weather();

    $context = array();
    if (is_wp_error($data)) {
        $context['error'] = true;
        $context['message'] = esc_html__('Weather is currently unavailable for Zurich. Please try again later.', 'homepage-weather-widget');
    } else {
        $context['error'] = false;
        $context['temperature'] = $data['temperature'];
        $context['high'] = $data['high'];
        $context['low'] = $data['low'];
        $context['label'] = $data['label'];
        $context['icon'] = $data['icon'];
        $context['icon_url'] = $data['icon_url'];
    }

    return hww_get_widget_markup($context);
}
add_shortcode('homepage_weather_widget', 'hww_shortcode_render');
