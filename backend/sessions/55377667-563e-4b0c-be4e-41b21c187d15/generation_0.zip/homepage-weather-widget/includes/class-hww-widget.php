<?php
if (!defined('ABSPATH')) {
    exit;
}

class HWW_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'hww_widget',
            esc_html__('Homepage Weather Widget', 'homepage-weather-widget'),
            array('description' => esc_html__('Compact weather for Zurich (Celsius).', 'homepage-weather-widget'))
        );
    }

    public function widget($args, $instance) {
        echo wp_kses_post($args['before_widget']);

        $title = isset($instance['title']) ? $instance['title'] : '';
        if (!empty($title)) {
            /* translators: %s: widget title */
            $safe_title = apply_filters('widget_title', $title, $instance, $this->id_base);
            echo wp_kses_post($args['before_title']);
            echo esc_html($safe_title);
            echo wp_kses_post($args['after_title']);
        }

        $service = new HWW_Weather_Service();
        $data = $service->get_weather();

        $context = array();
        if (is_wp_error($data)) {
            $context['error'] = true;
            $context['message'] = esc_html__('Weather is currently unavailable for Zurich. Please try again later.', 'homepage-weather-widget');
        } else {
            $context['error'] = false;
            $context['temperature'] = $data['temperature'];
            $context['high'] = $data['high'];
            $context['low'] = $data['low'];
            $context['label'] = $data['label'];
            $context['icon'] = $data['icon'];
            $context['icon_url'] = $data['icon_url'];
        }

        $markup = hww_get_widget_markup($context);
        echo wp_kses_post($markup);

        echo wp_kses_post($args['after_widget']);
    }

    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : '';
        $field_id = $this->get_field_id('title');
        $field_name = $this->get_field_name('title');
        ?>
        <p>
            <label for="<?php echo esc_attr($field_id); ?>"><?php echo esc_html__('Title:', 'homepage-weather-widget'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($field_id); ?>" name="<?php echo esc_attr($field_name); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = isset($new_instance['title']) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
}
