<?php
if (!defined('ABSPATH')) {
    exit;
}

class HWW_Weather_Service {
    private $lat = '47.3769'; // Zurich
    private $lon = '8.5417';  // Zurich
    private $timezone = 'Europe/Zurich';
    private $cache_key = 'hww_weather_data';
    private $cache_ttl = 1800; // 30 minutes

    public function get_weather() {
        $cached = get_transient($this->cache_key);
        if ($cached && is_array($cached)) {
            return $cached;
        }

        $endpoint = add_query_arg(
            array(
                'latitude' => $this->lat,
                'longitude' => $this->lon,
                'current_weather' => 'true',
                'daily' => 'temperature_2m_max,temperature_2m_min,weathercode',
                'timezone' => $this->timezone
            ),
            'https://api.open-meteo.com/v1/forecast'
        );

        $args = array(
            'timeout' => 8,
            'redirection' => 3,
            'user-agent' => 'Homepage-Weather-Widget/1.0 (+https://wordpress.org/)'
        );

        $response = wp_remote_get($endpoint, $args);
        if (is_wp_error($response)) {
            return new WP_Error('hww_api_error', esc_html__('Weather service is temporarily unavailable.', 'homepage-weather-widget'));
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('hww_bad_status', esc_html__('Unable to fetch weather data.', 'homepage-weather-widget'));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (!is_array($data)) {
            return new WP_Error('hww_bad_json', esc_html__('Received invalid weather data.', 'homepage-weather-widget'));
        }

        if (empty($data['current_weather']) || empty($data['daily'])) {
            return new WP_Error('hww_missing_fields', esc_html__('Weather data incomplete.', 'homepage-weather-widget'));
        }

        $current_temp = isset($data['current_weather']['temperature']) ? floatval($data['current_weather']['temperature']) : null;
        $current_code = isset($data['current_weather']['weathercode']) ? intval($data['current_weather']['weathercode']) : null;

        $daily_max = isset($data['daily']['temperature_2m_max'][0]) ? floatval($data['daily']['temperature_2m_max'][0]) : null;
        $daily_min = isset($data['daily']['temperature_2m_min'][0]) ? floatval($data['daily']['temperature_2m_min'][0]) : null;

        $mapped = $this->map_weathercode($current_code);

        $result = array(
            'temperature' => $current_temp,
            'high' => $daily_max,
            'low' => $daily_min,
            'label' => $mapped['label'],
            'icon' => $mapped['icon'],
            'icon_url' => $this->get_icon_url($mapped['icon'])
        );

        set_transient($this->cache_key, $result, $this->cache_ttl);
        return $result;
    }

    private function get_icon_url($icon_slug) {
        $filename = sanitize_file_name($icon_slug) . '.svg';
        return esc_url_raw(trailingslashit(HWW_PLUGIN_URL . 'assets/icons') . $filename);
    }

    private function map_weathercode($code) {
        // Mapping based on Open-Meteo weather codes
        $label = esc_html__('Unknown', 'homepage-weather-widget');
        $icon = 'wind';

        $code = intval($code);
        if (in_array($code, array(0), true)) { // Clear sky
            /* translators: weather condition label */
            $label = esc_html__('Clear', 'homepage-weather-widget');
            $icon = 'clear-day';
        } elseif (in_array($code, array(1, 2), true)) { // Mainly clear, Partly cloudy
            /* translators: weather condition label */
            $label = esc_html__('Partly cloudy', 'homepage-weather-widget');
            $icon = 'partly-cloudy';
        } elseif (in_array($code, array(3), true)) { // Overcast
            /* translators: weather condition label */
            $label = esc_html__('Cloudy', 'homepage-weather-widget');
            $icon = 'cloudy';
        } elseif (in_array($code, array(45, 48), true)) { // Fog
            /* translators: weather condition label */
            $label = esc_html__('Fog', 'homepage-weather-widget');
            $icon = 'fog';
        } elseif (in_array($code, array(51, 53, 55, 56, 57), true)) { // Drizzle
            /* translators: weather condition label */
            $label = esc_html__('Drizzle', 'homepage-weather-widget');
            $icon = 'rain';
        } elseif (in_array($code, array(61, 63, 65, 66, 67), true)) { // Rain
            /* translators: weather condition label */
            $label = esc_html__('Rain', 'homepage-weather-widget');
            $icon = 'rain';
        } elseif (in_array($code, array(71, 73, 75, 77), true)) { // Snow
            /* translators: weather condition label */
            $label = esc_html__('Snow', 'homepage-weather-widget');
            $icon = 'snow';
        } elseif (in_array($code, array(80, 81, 82), true)) { // Rain showers
            /* translators: weather condition label */
            $label = esc_html__('Showers', 'homepage-weather-widget');
            $icon = 'rain';
        } elseif (in_array($code, array(85, 86), true)) { // Snow showers
            /* translators: weather condition label */
            $label = esc_html__('Snow showers', 'homepage-weather-widget');
            $icon = 'snow';
        } elseif (in_array($code, array(95, 96, 99), true)) { // Thunderstorm
            /* translators: weather condition label */
            $label = esc_html__('Thunderstorm', 'homepage-weather-widget');
            $icon = 'thunderstorm';
        }

        return array(
            'label' => $label,
            'icon' => $icon,
        );
    }
}
