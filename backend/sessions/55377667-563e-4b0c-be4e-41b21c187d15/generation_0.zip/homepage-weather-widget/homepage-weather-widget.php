<?php
/**
 * Plugin Name: Homepage Weather Widget
 * Description: Simple weather widget for the homepage
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: homepage-weather-widget
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('HWW_PLUGIN_VERSION')) {
    define('HWW_PLUGIN_VERSION', '1.0.0');
}

if (!defined('HWW_PLUGIN_DIR')) {
    define('HWW_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('HWW_PLUGIN_URL')) {
    define('HWW_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Load text domain
function hww_load_textdomain() {
    load_plugin_textdomain('homepage-weather-widget', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'hww_load_textdomain');

// Includes
require_once HWW_PLUGIN_DIR . 'includes/class-hww-weather-service.php';
require_once HWW_PLUGIN_DIR . 'includes/class-hww-widget.php';
require_once HWW_PLUGIN_DIR . 'includes/functions.php';

// Register widget
function hww_register_widget() {
    register_widget('HWW_Widget');
}
add_action('widgets_init', 'hww_register_widget');

// Enqueue assets
function hww_enqueue_assets() {
    wp_enqueue_style(
        'hww-style',
        HWW_PLUGIN_URL . 'assets/style.css',
        array(),
        HWW_PLUGIN_VERSION
    );
}
add_action('wp_enqueue_scripts', 'hww_enqueue_assets');
