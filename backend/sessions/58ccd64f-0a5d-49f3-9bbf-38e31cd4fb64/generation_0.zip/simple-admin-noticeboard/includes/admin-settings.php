<?php
/**
 * Admin settings for Simple Admin Noticeboard
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add settings page under Settings menu.
 */
function sanb_add_settings_page() {
    add_options_page(
        esc_html__('Simple Admin Noticeboard', 'simple-admin-noticeboard'),
        esc_html__('Noticeboard', 'simple-admin-noticeboard'),
        'manage_options',
        'sanb-settings',
        'sanb_render_settings_page'
    );
}
add_action('admin_menu', 'sanb_add_settings_page');

/**
 * Register setting, section, and field.
 */
function sanb_register_settings() {
    register_setting(
        'sanb_settings_group',
        'sanb_notice_message',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default'           => '',
        )
    );

    add_settings_section(
        'sanb_section_main',
        esc_html__('Notice Settings', 'simple-admin-noticeboard'),
        'sanb_section_main_cb',
        'sanb-settings'
    );

    add_settings_field(
        'sanb_notice_message',
        esc_html__('Notice message', 'simple-admin-noticeboard'),
        'sanb_field_notice_message_cb',
        'sanb-settings',
        'sanb_section_main'
    );
}
add_action('admin_init', 'sanb_register_settings');

/**
 * Section callback.
 */
function sanb_section_main_cb() {
    echo '<p>' . esc_html__('Set the site-wide notice message that will be displayed where the [noticeboard] tag is placed.', 'simple-admin-noticeboard') . '</p>';
}

/**
 * Field callback for notice message.
 */
function sanb_field_notice_message_cb() {
    $value = get_option('sanb_notice_message', '');
    $field_id = 'sanb_notice_message';
    $field_name = 'sanb_notice_message';

    echo '<textarea id="' . esc_attr($field_id) . '" name="' . esc_attr($field_name) . '" rows="5" cols="60" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">' . esc_html__('You can include basic HTML. The notice will be visible to all visitors.', 'simple-admin-noticeboard') . '</p>';
}

/**
 * Render settings page content.
 */
function sanb_render_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'simple-admin-noticeboard'));
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Simple Admin Noticeboard', 'simple-admin-noticeboard'); ?></h1>
        <form action="<?php echo esc_url(admin_url('options.php')); ?>" method="post">
            <?php
            settings_fields('sanb_settings_group');
            do_settings_sections('sanb-settings');
            submit_button(esc_html__('Save Changes', 'simple-admin-noticeboard'));
            ?>
        </form>
        <hr />
        <p>
            <?php
            /* translators: %s: the shortcode tag name */
            echo esc_html(sprintf(__('Use the %s tag in your content to display the notice.', 'simple-admin-noticeboard'), '[noticeboard]'));
            ?>
        </p>
    </div>
    <?php
}
