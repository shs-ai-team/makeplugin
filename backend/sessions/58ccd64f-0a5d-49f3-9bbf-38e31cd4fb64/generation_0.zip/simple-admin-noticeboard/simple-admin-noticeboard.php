<?php
/**
 * Plugin Name: Simple Admin Noticeboard
 * Description: Single admin-set notice, placeable via a small tag.
 * Version: 1.0.0
 * Author: makeplugin
 * Text Domain: simple-admin-noticeboard
 * License: GPLv2 or later
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('SANB_VERSION')) {
    define('SANB_VERSION', '1.0.0');
}

if (!defined('SANB_PLUGIN_FILE')) {
    define('SANB_PLUGIN_FILE', __FILE__);
}

if (!defined('SANB_PLUGIN_DIR')) {
    define('SANB_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('SANB_PLUGIN_URL')) {
    define('SANB_PLUGIN_URL', plugin_dir_url(__FILE__));
}

/**
 * Load plugin textdomain.
 */
function sanb_load_textdomain() {
    load_plugin_textdomain('simple-admin-noticeboard', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'sanb_load_textdomain');

/**
 * Include admin settings.
 */
require_once SANB_PLUGIN_DIR . 'includes/admin-settings.php';

/**
 * Register shortcode [noticeboard].
 *
 * @return string
 */
function sanb_shortcode_noticeboard() {
    $message = get_option('sanb_notice_message', '');

    if (empty($message)) {
        return '';
    }

    // Enqueue frontend style when shortcode is used.
    wp_enqueue_style(
        'sanb-style',
        SANB_PLUGIN_URL . 'assets/css/style.css',
        array(),
        SANB_VERSION
    );

    $aria_label = esc_attr__('Site notice', 'simple-admin-noticeboard');

    ob_start();
    ?>
    <div class="sanb-noticeboard noticeboard-box" role="note" aria-label="<?php echo esc_attr($aria_label); ?>">
        <div class="sanb-noticeboard__content"><?php echo wp_kses_post($message); ?></div>
    </div>
    <?php
    $output = ob_get_clean();

    return $output;
}
add_shortcode('noticeboard', 'sanb_shortcode_noticeboard');
