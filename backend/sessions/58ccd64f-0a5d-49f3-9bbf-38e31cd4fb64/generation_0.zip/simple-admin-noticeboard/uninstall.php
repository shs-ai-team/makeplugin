<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin data
delete_option('sanb_notice_message');
