=== Simple Admin Noticeboard ===
Contributors: makeplugin
Tags: notice, shortcode, admin, message, sitewide, announcement, banner
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Single admin-set notice, placeable via a small tag.

== Description ==
Provide a single site-wide notice that only administrators can set in a small settings screen with one required field: the notice message. The notice is displayed wherever the site owner places a small tag in page or post content using the [noticeboard] shortcode. The output shows a simple, neutral-styled box containing the message, visible to everyone (logged-in or not). The notice is not dismissible and does not alter permissions. Styling is minimal and includes predictable classes so themes can style it as desired.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/simple-admin-noticeboard` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to Settings -> Noticeboard and set your notice message.
4. Add the `[noticeboard]` shortcode anywhere in your content to display the notice.

== Frequently Asked Questions ==
= Who can set the notice? =
Only administrators (users with the `manage_options` capability).

= Can I use HTML in the notice? =
Yes, basic HTML is allowed and will be sanitized.

== Screenshots ==
1. Settings screen with the notice message field.
2. Front-end example of the notice box.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
